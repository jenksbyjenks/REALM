<?php

if ( is_admin() ) return;

add_action('wp_head', 'za_styling_css');

if ( !function_exists( 'za_styling_css' ) ) {
	
	function za_styling_css() {
	
		$custom_css ='';	
		global $zoomarts_options;
		
		if ( $zoomarts_options['custom_styling'] != '1' ) return;


		// Boxed CSS

		if ( isset($zoomarts_options['main-layout-style']) && $zoomarts_options['main-layout-style'] == 'boxed-layout' ) {
			if ( isset($zoomarts_options['boxed-bg']) && isset($zoomarts_options['boxed-bg-preset']) && $zoomarts_options['boxed-bg'] == 'preset' && $zoomarts_options['boxed-bg'] != '' ) {
				$custom_css .= 'body { background: repeat url('.get_template_directory_uri().'/images/patterns/'.$zoomarts_options['boxed-bg-preset'] .'.jpg); }';
			}
		}


		// Primary Color

		if ( isset($zoomarts_options['primary-color']) && $zoomarts_options['primary-color'] != '' ) {
			$custom_css .= '.projects-carousel.nav-true.nav-light .owl-prev:hover, .projects-carousel.nav-true.nav-light .owl-next:hover, .projects-carousel.nav-true.nav-dark .owl-prev:hover, .projects-carousel.nav-true.nav-dark .owl-next:hover, .products-carousel.nav-true.nav-light .owl-prev:hover, .products-carousel.nav-true.nav-light .owl-next:hover, .products-carousel.nav-true.nav-dark .owl-prev:hover, .products-carousel.nav-true.nav-dark .owl-next:hover, .wpb_tabs.style-1 .wpb_tabs_nav li.ui-tabs-active a, .wpb_tabs.style-3 .wpb_tabs_nav li.ui-tabs-active a, .wpb_tour.style-1 .wpb_tabs_nav li.ui-tabs-active a, .wpb_tour.style-3 .wpb_tabs_nav li.ui-tabs-active a, .wpb_accordion .ui-icon:before, .wpb_accordion.style-2 .wpb_accordion_header.ui-state-active a, .team-member.default-style .member-social a:hover, .testimonials-slider.arrows-nav-dark .owl-nav div:hover, .tweets-slider.arrows-nav-dark .owl-nav div:hover, .testimonials-slider.arrows-nav-light .owl-nav div:hover, .tweets-slider.arrows-nav-light .owl-nav div:hover, .za-gallery.style-1 .gallery-item .overlay h6, .search-box .close-btn:hover, .project-head a.prev:hover, .project-head a.next:hover, .post-head .post-title a:hover, .post-meta a:hover, #wp-calendar tbody td#today, #wp-calendar tbody td a, #wp-calendar tfoot td#prev a:hover, #wp-calendar tfoot td#next a:hover, .error-msg h1, .wc-cart-icon .woocommerce a:hover, .wc-cart-icon .woocommerce a:hover, .woocommerce div.product_meta a:hover, .woocommerce table.cart a.remove, .woocommerce #content table.cart a.remove, .woocommerce-page table.cart a.remove, .woocommerce-page #content table.cart a.remove, #header .nav-menu ul ul li a span.label.primary-color, #header .search-box .close-btn:hover { color: '.$zoomarts_options['primary-color'].'; }';

			$custom_css .= 'a.main-button:hover, blockquote, .wpb_tabs.style-2 .wpb_tabs_nav li.ui-tabs-active, .wpb_tour.style-2 .wpb_tabs_nav li.ui-tabs-active, .team-member.default-style .member-social a:hover, .custom-slider  .owl-controls .owl-dots .owl-dot.active span, .swiper-container .swiper-pagination .swiper-pagination-bullet-active, .widget .tagcloud a:hover, #wp-calendar tbody td#today, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .mobile-nav .close-mobile-nav:hover, #header .nav-menu ul ul li a span.label.primary-color { border-color: '.$zoomarts_options['primary-color'].'; }';

			$custom_css .= 'a.main-button:hover, input[type="submit"], .progress-bar, .wpb_tabs.style-2 .wpb_tabs_nav li.ui-tabs-active, .wpb_tour.style-2 .wpb_tabs_nav li.ui-tabs-active, .pricing-table-column.special-price-table .pricing-table-head, .pricing-table-column.special-price-table .pricing-table-content, .post-thumb .thumb-overlay, .custom-slider  .owl-controls .owl-dots .owl-dot.active span, .swiper-container .swiper-pagination .swiper-pagination-bullet-active, .post-link, .post-quote, .widget .tagcloud a:hover, .related-posts .post-thumb:hover, .related-posts .post-thumb .overlay, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, a.shipping-calculator-button, .woocommerce ul.products li.product .onsale, .woocommerce-page ul.products li.product .onsale, .woocommerce span.onsale, .woocommerce-page span.onsale, .latest-products span.onsale, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce .woocommerce-message, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .mobile-nav .close-mobile-nav:hover, .search-results .search-item .result-type { background-color: '.$zoomarts_options['primary-color'].'; }';
		}


		// Header CSS

		if ( isset($zoomarts_options['header-height']) && $zoomarts_options['header-height'] != '' ) {
			$custom_css .= '.nav-menu > ul > li > a, #header .show-search { height: '.$zoomarts_options['header-height'].'px; line-height: '.$zoomarts_options['header-height'].'px; }';
			$custom_css .= '#header #logo, .wc-cart-icon, #header .show-menu { height: '.$zoomarts_options['header-height'].'px; }';
		}

		if ( isset($zoomarts_options['header-bg']) && $zoomarts_options['header-bg'] != '' ) {
			$custom_css .= '#header { background-color: '.$zoomarts_options['header-bg'].'; }';
		}

		if ( isset($zoomarts_options['menu-color']['regular']) && $zoomarts_options['menu-color']['regular'] != '' ) {
			$custom_css .= '#header .nav-menu > ul > li > a { color:'.$zoomarts_options['menu-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['menu-color']['hover']) && $zoomarts_options['menu-color']['hover'] != '' ) {
			$custom_css .= '#header .nav-menu > ul > li:hover > a { color:'.$zoomarts_options['menu-color']['hover'].'; }';
			$custom_css .= '#header .nav-menu > ul > li > a:hover:after { background-color:'.$zoomarts_options['menu-color']['hover'].'; }';
		}

		if ( isset($zoomarts_options['menu-color']['active']) && $zoomarts_options['menu-color']['active'] != '' ) {
			$custom_css .= '#header .nav-menu > ul > li.current-menu-item > a { color:'.$zoomarts_options['menu-color']['active'].'; }';
			$custom_css .= '#header .nav-menu > ul > li.current-menu-item > a:after { background-color:'.$zoomarts_options['menu-color']['active'].'; }';
		}

		if ( isset($zoomarts_options['menu-dropdown-color']['regular']) && $zoomarts_options['menu-dropdown-color']['regular'] != '' ) {
			$custom_css .= '#header .nav-menu ul ul li a { color:'.$zoomarts_options['menu-dropdown-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['menu-dropdown-color']['hover']) && $zoomarts_options['menu-dropdown-color']['hover'] != '' ) {
			$custom_css .= '#header .nav-menu ul ul li a:hover { color:'.$zoomarts_options['menu-dropdown-color']['hover'].'; }';
		}

		if ( isset($zoomarts_options['menu-dropdown-color']['active']) && $zoomarts_options['menu-dropdown-color']['active'] != '' ) {
			$custom_css .= '#header .nav-menu ul ul li.active > a, #header .nav-menu ul ul li.current-menu-item > a { color:'.$zoomarts_options['menu-dropdown-color']['active'].'; }';
		}

		if ( isset($zoomarts_options['dropdown-background-color']) && $zoomarts_options['dropdown-background-color'] != '' ) {
			$custom_css .= '#header .nav-menu li.mega-menu .second-lvl, #header .nav-menu ul ul li a { background-color:'.$zoomarts_options['dropdown-background-color'].'; }';
		}

		if ( isset($zoomarts_options['dropdown-borders-color']['rgba']) && $zoomarts_options['dropdown-borders-color']['rgba'] != '' ) {
			$custom_css .= '#header .nav-menu ul ul li a, #header .nav-menu li.mega-menu .second-lvl ul li a { border-color:'.$zoomarts_options['dropdown-borders-color']['rgba'].'; }';
			$custom_css .= '#header .nav-menu li.mega-menu .second-lvl ul li a:before { background-color:'.$zoomarts_options['dropdown-borders-color']['rgba'].'; }';
		}

		if ( isset($zoomarts_options['megamenu-subtitle-color']['regular']) && $zoomarts_options['megamenu-subtitle-color']['regular'] != '' ) {
			$custom_css .= '#header .nav-menu ul li.menu-title > a { color:'.$zoomarts_options['megamenu-subtitle-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['megamenu-subtitle-color']['hover']) && $zoomarts_options['megamenu-subtitle-color']['hover'] != '' ) {
			$custom_css .= '#header .nav-menu ul li.menu-title > a:hover { color:'.$zoomarts_options['megamenu-subtitle-color']['hover'].'; }';
		}

		if ( isset($zoomarts_options['search-icon-color']['regular']) && $zoomarts_options['search-icon-color']['regular'] != '' ) {
			$custom_css .= '#header .show-search { color:'.$zoomarts_options['search-icon-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['search-icon-color']['hover']) && $zoomarts_options['search-icon-color']['hover'] != '' ) {
			$custom_css .= '#header .show-search:hover { color:'.$zoomarts_options['search-icon-color']['hover'].'; }';
		}

		if ( isset($zoomarts_options['search-box-close-icon']['regular']) && $zoomarts_options['search-box-close-icon']['regular'] != '' ) {
			$custom_css .= '#header .search-box .close-btn { color:'.$zoomarts_options['search-box-close-icon']['regular'].'; }';
			$custom_css .= '#header .search-box .close-btn { border-color:'.$zoomarts_options['search-box-close-icon']['regular'].'; }';
		}

		if ( isset($zoomarts_options['search-box-close-icon']['hover']) && $zoomarts_options['search-box-close-icon']['hover'] != '' ) {
			$custom_css .= '#header .search-box .close-btn:hover { color:'.$zoomarts_options['search-box-close-icon']['hover'].'; }';
			$custom_css .= '#header .search-box .close-btn:hover { border-color:'.$zoomarts_options['search-box-close-icon']['hover'].'; }';
		}

		if ( isset($zoomarts_options['cart-icon-color']['regular']) && $zoomarts_options['cart-icon-color']['regular'] != '' ) {
			$custom_css .= '.wc-cart-icon .woo-cart-icon { color:'.$zoomarts_options['cart-icon-color']['regular'].'; }';
			$custom_css .= '.wc-cart-icon .woo-cart-icon span { background-color:'.$zoomarts_options['cart-icon-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['cart-icon-color']['hover']) && $zoomarts_options['cart-icon-color']['hover'] != '' ) {
			$custom_css .= '.wc-cart-icon .woo-cart-icon:hover { color:'.$zoomarts_options['cart-icon-color']['hover'].'; }';
			$custom_css .= '.wc-cart-icon .woo-cart-icon:hover span { background-color:'.$zoomarts_options['cart-icon-color']['hover'].'; }';
		}


		// Mobile Menu CSS

		if ( isset($zoomarts_options['mobile-menu-icon-color']['regular']) && $zoomarts_options['mobile-menu-icon-color']['regular'] != '' ) {
			$custom_css .= '#header .show-menu i { background-color:'.$zoomarts_options['mobile-menu-icon-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['mobile-menu-icon-color']['hover']) && $zoomarts_options['mobile-menu-icon-color']['hover'] != '' ) {
			$custom_css .= '#header .show-menu:hover i { background-color:'.$zoomarts_options['mobile-menu-icon-color']['hover'].'; }';
		}

		if ( isset($zoomarts_options['mobile-menu-bg']['background-color']) && $zoomarts_options['mobile-menu-bg']['background-color'] != '' ) {
			$custom_css .= '.mobile-nav .close-mobile-nav { background-color:'.$zoomarts_options['mobile-menu-bg']['background-color'].'; }';
			$custom_css .= '.mobile-nav .close-mobile-nav:hover { color:'.$zoomarts_options['mobile-menu-bg']['background-color'].'; }';
		}

		if ( isset($zoomarts_options['mobile-menu-links-color']['regular']) && $zoomarts_options['mobile-menu-links-color']['regular'] != '' ) {
			$custom_css .= '.mobile-nav .mobile-menu > ul > li > a { color:'.$zoomarts_options['mobile-menu-links-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['mobile-menu-links-color']['hover']) && $zoomarts_options['mobile-menu-links-color']['hover'] != '' ) {
			$custom_css .= '.mobile-nav .mobile-menu > ul > li:hover > a, .mobile-nav .mobile-menu > ul > li:hover > a:hover { color:'.$zoomarts_options['mobile-menu-links-color']['hover'].'; }';
		}

		if ( isset($zoomarts_options['mobile-menu-links-color']['active']) && $zoomarts_options['mobile-menu-links-color']['active'] != '' ) {
			$custom_css .= '.mobile-nav .mobile-menu > ul > li.current-menu-item > a, .mobile-nav .mobile-menu > ul > li.current-menu-item:hover > a, .mobile-nav .mobile-menu > ul > li.current-menu-item:hover > a:hover { color:'.$zoomarts_options['mobile-menu-links-color']['active'].'!important; }';
		}

		if ( isset($zoomarts_options['mobile-menu-dropdown-color']['regular']) && $zoomarts_options['mobile-menu-dropdown-color']['regular'] != '' ) {
			$custom_css .= '.mobile-nav .mobile-menu ul ul > li > a { color:'.$zoomarts_options['mobile-menu-dropdown-color']['regular'].'; }';
		}

		if ( isset($zoomarts_options['mobile-menu-dropdown-color']['hover']) && $zoomarts_options['mobile-menu-dropdown-color']['hover'] != '' ) {
			$custom_css .= '.mobile-nav .mobile-menu ul ul > li:hover > a, .mobile-nav .mobile-menu ul ul > li:hover > a:hover { color:'.$zoomarts_options['mobile-menu-dropdown-color']['hover'].'; }';
		}

		if ( isset($zoomarts_options['mobile-menu-dropdown-color']['active']) && $zoomarts_options['mobile-menu-dropdown-color']['active'] != '' ) {
			$custom_css .= '.mobile-nav .mobile-menu ul ul > li.current-menu-item > a, .mobile-nav .mobile-menu ul ul > li.current-menu-item:hover > a, .mobile-nav .mobile-menu ul ul > li.current-menu-item:hover > a:hover { color:'.$zoomarts_options['mobile-menu-dropdown-color']['active'].'!important; }';
		}


		// Footer CSS
		
		if ( isset($zoomarts_options['footer-bg']['background-color']) && $zoomarts_options['footer-bg']['background-color'] != '' ) {
			$custom_css .= '.footer .widget h3.widget-title span:after { background-color:'.$zoomarts_options['footer-bg']['background-color'].'; }';
		}

		if ( isset($zoomarts_options['footer-widgets-borders']) && $zoomarts_options['footer-widgets-borders'] != '' ) {
			$custom_css .= '.footer .widget h3.widget-title { border-color:'.$zoomarts_options['footer-widgets-borders'].'; }';
		}


		// trim white space for faster page loading
		$custom_css_trimmed =  preg_replace( '/\s+/', ' ', $custom_css );
		
		// output css on front end
		$css_output = "<!-- Custom CSS -->\n<style type=\"text/css\">\n" . $custom_css_trimmed . "\n</style>";
		if( !empty($custom_css) ) {
			echo ($css_output);
		}

		
	}
	
}

?>