<div class="sidebar">
	<div class="sidebar-inner">
	
		<?php

			$custom_sidebar = null;

			if ( !is_search() && !is_category() || !is_404() ) {

				if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
					if ( is_shop() || is_product_category() || is_product_tag() ) {
						$post_id = get_option( 'woocommerce_shop_page_id' );
					} elseif ( is_cart() ) {
		        		$post_id = get_option( 'woocommerce_cart_page_id' );
		        	} elseif ( is_checkout() ) {
		        		$post_id = get_option( 'woocommerce_checkout_page_id' );
		        	} elseif ( is_account_page() ) {
		        		$post_id = get_option( 'woocommerce_myaccount_page_id' );
		        	} elseif ( is_product() ) {
		        		$post_id = get_queried_object_id();
		        	} else {
		        		$post_id = get_option( 'woocommerce_shop_page_id' );
		        	}
				} else {
					$post_id = get_queried_object_id();
				}

				$custom_sidebar = get_post_meta( $post_id, 'za_custom_sidebar', true);

			}

			if ( $custom_sidebar != null ) {
				if ( is_active_sidebar($custom_sidebar) ) {
					dynamic_sidebar( $custom_sidebar );
				}
			} else {
				if ( is_single() ) {
					if ( is_active_sidebar('single-sidebar') ) {
						dynamic_sidebar( 'single-sidebar' );
					}
				} else {
					if ( is_active_sidebar('main-sidebar') ) {
						dynamic_sidebar( 'main-sidebar' );
					}
				}
			}

		?>
		
	</div>
</div>