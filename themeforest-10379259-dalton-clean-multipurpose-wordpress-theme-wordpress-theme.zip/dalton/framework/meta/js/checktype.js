jQuery(document).ready(function($){
	
 
	/*----------------------------------------------------------------------------------*/
	/*	Display post format meta boxes as needed
	/*----------------------------------------------------------------------------------*/
		
	$('#post-formats-select input').change(checkFormat);
	$('.wp-post-format-ui .post-format-options > a').click(checkFormat);

	$('select[name=page_template]').change(checkPageTmpl);
		 
	function checkFormat(){
		var format = $('#post-formats-select input:checked').attr('value');
		if( typeof format != 'undefined'){
			$('#post-body div[id^=metabox-post-]').hide();
			$('#post-body #metabox-post-'+format+'').stop(true,true).fadeIn(500);		
		}
	}

	function checkPageTmpl(){
		var page_tmpl = $('select[name=page_template]').val();
		if( page_tmpl != 'template-builder.php'){
			$('#metabox-one-page-options').hide();	
			$('#metabox-layout-options').fadeIn(500);
		} else {
			$('#metabox-one-page-options').fadeIn(500);
			$('#metabox-layout-options').hide();
		}
	}
		 
	$(window).load( function(){
		checkFormat();
		checkPageTmpl();
	})


	/*----------------------------------------------------------------------------------*/
	/*	Display One-Page Options
	/*----------------------------------------------------------------------------------*/

    
});


