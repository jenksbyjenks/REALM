<?php
	
	/*template name: Portfolio*/

	get_header();
	za_page_header();

	global $zoomarts_options;

	$portfolio_style 	   = $zoomarts_options['portfolio-style'];
	$portfolio_layout 	   = $zoomarts_options['portfolio-layout'];
	$portfolio_cols 	   = $zoomarts_options['portfolio-cols'];
	$portfolio_spaces 	   = $zoomarts_options['portfolio-spaces'];
	$hover_style 		   = $zoomarts_options['projects-hover-style'];
	$portfolio_pagination  = $zoomarts_options['portfolio-pagination'];
	$portfolio_filters  = $zoomarts_options['portfolio-filters'];
	$portfolio_filters_orderby = (isset($zoomarts_options['portfolio-filters-orderby']) && $zoomarts_options['portfolio-filters-orderby'] != '' ? $zoomarts_options['portfolio-filters-orderby'] : 'name');
	$portfolio_filters_order  = (isset($zoomarts_options['portfolio-filters-order']) && $zoomarts_options['portfolio-filters-order'] != '' ? $zoomarts_options['portfolio-filters-order'] : 'ASC');

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="main-content">

    		<?php if ( $portfolio_filters == '0' ) {
    			echo '<div class="filters-gap"></div>';
    		} ?>

			<!-- Start Posts Container -->
			<div class="projects-wrap <?php echo ( $portfolio_spaces ); ?>">

				<?php if ( $portfolio_filters != '0' || !isset($portfolio_filters) ) : ?>
					<div id="filters">
						<?php if( $zoomarts_options['portfolio-cats-filter'] == 'same' ) : ?>
							<ul class="filters-list clearfix" data-option-key="filter">
								<li><span data-filter="*" class="active"><?php echo _e('All', 'zoomarts'); ?></span></li>
								<?php wp_list_categories(array('title_li' => '', 'orderby' => $portfolio_filters_orderby, 'order' => $portfolio_filters_order, 'taxonomy' => 'project-type', 'show_option_none'   => '', 'walker' => new Walker_Portfolio_Filter())); ?>
							</ul>
						<?php else : ?>
							<ul class="filters-list clearfix">
								<li class="current-cat"><a href="<?php echo ( get_portfolio_page(get_the_ID()) ); ?>"><?php echo _e('All', 'zoomarts'); ?></a></li>
								<?php wp_list_categories(array('title_li' => '', 'orderby' => $portfolio_filters_orderby, 'order' => $portfolio_filters_order, 'taxonomy' => 'project-type', 'show_option_none' => '', )); ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<div class="<?php echo ( $portfolio_layout ); ?>">
					
				<div class="projects-list <?php echo ( $portfolio_style ); ?> projects-style-1 <?php echo ( $portfolio_spaces ); ?> projects-cols-<?php echo ( $portfolio_cols ); ?>" data-projects-cols="<?php echo ( $portfolio_cols ); ?>">

					<div class="projects-loader">
						<div class="spinner">
							<div class="double-bounce1"></div>
							<div class="double-bounce2"></div>
						</div>
					</div>

					<div class="grid-sizer"></div>

					<?php

					if ( $portfolio_pagination == 'standard' || $portfolio_pagination == 'next-prev' ) {
						$posts_per_page = $zoomarts_options['projects-per-page'];
					} else {
						$posts_per_page = '-1';
					}

					$paged = 1;
					if ( is_front_page() ) {
						if ( get_query_var( 'page' ) ) {
							$paged = get_query_var( 'page' );
						}
					} else {
						if ( get_query_var( 'paged') ) {
							$paged = get_query_var( 'paged');
						}
					}
								
					$portfolio = array(
						'post_status' 			=> 'publish',
						'post_type' 			=> 'portfolio',
						'posts_per_page' 		=> $posts_per_page,
						'paged'					=> $paged,
						'orderby' 				=> 'date',
						'order' 				=> 'desc'
					);
								
					$wp_query = new WP_Query($portfolio);
								
					if ( $wp_query->have_posts()) : while ( $wp_query->have_posts()) : $wp_query->the_post();

					global $post;
					$project_cats = '';
					$terms = get_the_terms($post->id,"project-type");
					$project_size_meta = get_post_meta( $post->ID, 'za_project-masonry-size', true );
					$project_lightbox_images = get_post_meta( $post->ID, 'za_project_lightbox_image', true );
					$project_lightbox_video = get_post_meta( $post->ID, 'za_project_lightbox_video', true );
					$default_lightbox_image = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
					$project_custom_link = get_post_meta( $post->ID, 'za_project_custom_link', true );

					if ( !empty($terms) ){
						foreach ( $terms as $term ) {
							$project_cats .= strtolower($term->slug) . ' ';
						}
					}

					if ( $portfolio_style == 'grid-layout' ) {
						$thumb_size = 'grid-thumb';
					} elseif ( $portfolio_style == 'masonry-layout' ) {
						$thumb_size = 'full';
					} elseif ( $portfolio_style == 'masonry-multisize-layout' ) {
						if ( !empty($project_size_meta) ) {
							$thumb_size = get_post_meta( $post->ID, 'za_project-masonry-size', true );
							$project_size = get_post_meta( $post->ID, 'za_project-masonry-size', true );
						} else {
							$thumb_size = 'masonry-small';
							$project_size = 'masonry-small';
						}
					} ?>
							
					<div class="project-item <?php echo ($project_size).' '. ($hover_style); ?> <?php echo ($project_cats); ?>">
						<figure>
							<?php echo ( get_the_post_thumbnail( $post->ID, $thumb_size, array('title' => '') ) ); ?>
							<figcaption>
								<a class="touch-open-project" href="<?php echo ( get_permalink() ); ?>"></a>
								<div class="project-info">
									<h4><a href="<?php echo ( get_permalink() ); ?>"><?php echo ( get_the_title() ); ?></a></h4>
									<?php if( isset($zoomarts_options['portfolio_show_cats']) && $zoomarts_options['portfolio_show_cats'] == '1' || ( !isset($zoomarts_options['portfolio_show_cats']) ) ) : ?>
									<div class="project-categories">
									<?php if ( !empty($terms) ){
										foreach ( $terms as $term ) {
											$term_link = get_term_link( $term );
											if ( is_wp_error( $term_link ) ) {
												continue;
											}
											echo '<a href="'.$term_link.'">'. $term->name .'</a> ';
										}
									} ?>
									</div>
									<?php endif; ?>
								</div>
								<div class="project-links">
									<?php if ( !empty($project_custom_link) ) :
										echo '<a href="'.$project_custom_link.'" class="project-custom-link" title="'.get_the_title().'"><i class="icon-link8"></i></a>';
									endif; ?>
									<?php if ( !empty($project_lightbox_video) ) {
										echo '<a href="'.$project_lightbox_video.'" class="open-image lightbox" title="'.get_the_title().'"><i class="icon-expand4"></i></a>';
									} else if ( !empty($project_lightbox_images) ) {
										echo '<a href="'.$default_lightbox_image.'" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'" title="'.get_the_title().'" class="open-image lightbox"><i class="icon-expand4"></i></a>';
										foreach ( $project_lightbox_images as $project_lightbox_image ) {
											echo '<a href="'.$project_lightbox_image.'" class="open-image hidden lightbox" title="'.get_the_title().'" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'"><i class="icon-expand4"></i></a>';
										}
									} else {
										echo '<a href="'.$default_lightbox_image.'" class="open-image lightbox"><i class="icon-expand4"></i></a>';
									} ?>
									<a title="<?php echo ( get_the_title() ); ?>" href="<?php echo ( get_permalink() ); ?>" class="open-post"><i class="icon-arrow-right4"></i></a>
								</div>
								<div class="project-border-1"></div>
								<div class="project-border-2"></div>
								<div class="project-border-3"></div>
								<div class="project-border-4"></div>
							</figcaption>
						</figure>
					</div>

					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
					<?php endif; ?>

				</div>

			</div>

			<?php if ( $portfolio_pagination == 'standard' ) : ?>
				<div class="container portfolio-pagination"><?php za_pagination(); ?></div>
			<?php elseif ( $portfolio_pagination == 'next-prev' ) : ?>
				<div class="container portfolio-pagination">
					<div class="page-navigation clearfix">
						<div class="nav-next"><?php next_posts_link('&#8594;') ?></div>
						<div class="nav-previous"><?php previous_posts_link('&#8592;') ?></div>
					</div>
				</div>
			<?php endif; ?>
					
		</div>
		<!-- End Posts Container -->

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>