<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category Dalton Wordpress Theme
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/webdevstudios/Custom-Metaboxes-and-Fields-for-WordPress
 */


add_filter( 'cmb_meta_boxes', 'za_theme_metaboxes' );
function za_theme_metaboxes() {

	$prefix = 'za_';


	// Menus List Function
	function za_display_menus() {
		$custom_menus = array();
		$menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );

		if ( is_array( $menus ) ) {
			foreach ( $menus as $single_menu ) {
				$custom_menus[$single_menu->term_id] = $single_menu->name;
			}
		}
		return $custom_menus;
	}

	// Sidebars List Function
	function za_display_sidebars() {
		global $zoomarts_options;
		$sidebars =  array( '' => '');
		if( !empty($zoomarts_options['custom_sidebars']) && isset($zoomarts_options['custom_sidebars']) && sizeof($zoomarts_options['custom_sidebars']) > 0) {
			foreach( $zoomarts_options['custom_sidebars'] as $sidebar ) {
				$sidebars[$sidebar] = $sidebar;
			}
		} else {
			$sidebars = null;
		}
		return $sidebars;
	}


	/**
	 * Custom Options
	 */
	$meta_boxes['metabox-custom-options'] = array(
		'id'			=> 'metabox-custom-options',
		'title'      	=> __( 'Custom Options', 'zoomarts' ),
		'pages'      	=> array( 'page', 'post', 'product', 'portfolio' ),
		'context'    	=> 'side',
		'priority'   	=> 'default',
		'show_names' 	=> true,
		'fields' 		=> array(
			array(
				'name'    => __( 'Custom Background Color', 'zoomarts' ),
				'desc'    => __( 'Select your preferred background color for this page.', 'zoomarts' ),
				'id'      => $prefix . 'custom_bg_color',
				'type'    => 'colorpicker',
			),
        )
	);


	/**
	 * One Page Options
	 */
	$meta_boxes['metabox-one-page-options'] = array(
		'id'			=> 'metabox-one-page-options',
		'title'      	=> __( 'One Page Options', 'zoomarts' ),
		'pages'      	=> array( 'page' ),
		'context'    	=> 'side',
		'priority'   	=> 'default',
		'show_names' 	=> true,
		'fields' 		=> array(
			array(
				'name'		=> __( 'One-Page?', 'zoomarts' ),
				'id'      	=> $prefix . 'check_onepage',
				'type'    	=> 'radio_inline',
				'options' 	=> array(
					'disabled' 		=> __( 'Disabled', 'zoomarts' ),
					'enabled'		=> __( 'Enabled', 'zoomarts' ),
				),
				'default' 	=> 'disabled'
			),
            array(
                'name'		=> 'One Page Menu',
                'desc' 		=> 'Select your one-page menu',
                'id' 		=> $prefix . 'onepage_menu_id',
                'type'    	=> 'select',
                'options' 	=> za_display_menus(),
            ),
        )
	);



	/**
	 * Default Templates Layout Options
	 */
	$meta_boxes['metabox-layout-options'] = array(
		'id'			=> 'metabox-layout-options',
		'title'      	=> __( 'Layout Options', 'zoomarts' ),
		'pages'      	=> array( 'page', 'post', 'product' ),
		'context'    	=> 'side',
		'priority'   	=> 'default',
		'show_names' 	=> true,
		'fields' 		=> array(
			array(
				'name'    => __( 'Page Layout', 'zoomarts' ),
				'desc'    => __( 'Select your preferred layout for this page.', 'zoomarts' ),
				'id'      => $prefix . 'page_layout',
				'type'    => 'select',
				'options' => array(
					'right-sidebar'   => __( 'Right Sidebar', 'zoomarts' ),
					'left-sidebar'     => __( 'Left Sidebar', 'zoomarts' ),
					'fullwidth' => __( 'Fullwidth', 'zoomarts' ),
				),
			),
            array(
                'name'		=> 'Custom Sidebar',
                'desc' 		=> 'Select your custom sidebar for this page.',
                'id' 		=> $prefix . 'custom_sidebar',
                'type'    	=> 'select',
                'options' 	=> za_display_sidebars(),
            ),
        )
	);





	/**
	 * Post Type Image
	 */
	$meta_boxes['metabox-post-image'] = array(
		'id'         => 'metabox-post-image',
		'title'      => __( 'Image Settings', 'zoomarts' ),
		'pages'      => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
            array(
				'name' => __( 'Image LightBox?', 'zoomarts' ),
				'desc' => __( 'Upload an image or enter a URL.', 'zoomarts' ),
				'id'   => $prefix . 'lightbox_image',
				'type' => 'file',
			),
		),
	);
	
	
	/**
	 * Post Type Gallery
	 */
	$meta_boxes['metabox-post-gallery'] = array(
		'id'         => 'metabox-post-gallery',
		'title'      => __( 'Gallery Settings', 'zoomarts' ),
		'pages'      => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name'         => __( 'Gallery Images', 'zoomarts' ),
				'desc'         => __( 'Upload Your Gallery images.', 'zoomarts' ),
				'id'           => $prefix . 'gallery_images',
				'type'         => 'file_list',
				'preview_size' => array( 100, 100 ),
			),
		),
	);
	
	
	/**
	 * Post Type Status
	 */
	$meta_boxes['metabox-post-status'] = array(
		'id'         => 'metabox-post-status',
		'title'      => __( 'Status Settings', 'zoomarts' ),
		'pages'      => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Embed Status', 'zoomarts' ),
				'desc' => __( 'Embed Status Here , Embed your tweet status heres.', 'zoomarts' ),
				'id'   => $prefix . 'embed_status',
				'type' => 'oembed',
			),
		),
	);
	
	
	/**
	 * Post Type Quote
	 */
	$meta_boxes['metabox-post-quote'] = array(
		'id'         => 'metabox-post-quote',
		'title'      => __( 'Quote Settings', 'zoomarts' ),
		'pages'      => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Quote', 'zoomarts' ),
				'desc' => __( 'Insert the Quote.', 'zoomarts' ),
				'id'   => $prefix . 'quote_text',
				'type' => 'textarea_small',
			),
			array(
				'name' => __( 'Quote Author', 'zoomarts' ),
				'desc' => __( 'Insert the Quote Author.', 'zoomarts' ),
				'id'   => $prefix . 'quote_author',
				'type' => 'text_medium',
			),
			array(
				'name'    => __( 'Show Content', 'zoomarts' ),
				'desc'    => __( 'Show The Post Content for Posts List Page.', 'zoomarts' ),
				'id'   => $prefix . 'quote_content',
				'type' => 'checkbox',
			),
		),
	);
	
	
	/**
	 * Post Type Link
	 */
	$meta_boxes['metabox-post-link'] = array(
		'id'         => 'metabox-post-link',
		'title'      => __( 'Link Settings', 'zoomarts' ),
		'pages'      => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' 		=> __( 'The Link', 'zoomarts' ),
				'desc' 		=> __( 'Insert your link URL, e.g. http://www.zoom-arts.com', 'zoomarts' ),
				'id'   		=> $prefix . 'link_url',
				'type' 		=> 'text_medium',
			),
		),
	);
	
	
	/**
	 * Post Type Video
	 */
	$meta_boxes['metabox-post-video'] = array(
		'id'         => 'metabox-post-video',
		'title'      => __( 'Video Settings', 'zoomarts' ),
		'pages'      => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Embedded Code', 'zoomarts' ),
				'desc' => __( 'If you are using something other than self hosted video such as Youtube or Vimeo, paste the video url here.<br/><strong>This field will override the above.</strong>', 'zoomarts' ),
				'id'   => $prefix . 'video_embed_code',
				'type' => 'oembed',
			),
		),
	);
	
	
	/**
	 * Post Type Audio
	 */
	$meta_boxes['metabox-post-audio'] = array(
		'id'         => 'metabox-post-audio',
		'title'      => __( 'Audio Settings', 'zoomarts' ),
		'pages'      => array( 'post' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => __( 'Embedded Code', 'zoomarts' ),
				'desc' => __( 'If you are using something other than self hosted audio such as Soundcloud, paste the audio url here.<br/><strong>This field will override the above.</strong>', 'zoomarts' ),
				'id'   => $prefix . 'audio_embed_code',
				'type' => 'oembed',
			),
		),
	);


	/**
	 * Project Options
	 */
	$meta_boxes['metabox-project-options'] = array(
		'id'         => 'metabox-project-options',
		'title'      => __( 'Project Options', 'zoomarts' ),
		'pages'      => array( 'portfolio' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => 'Portfolio Masonry Style',
				'type' => 'title',
				'id'   => $prefix . 'title_d',
			),
			array(
				'name'    => __( 'Project Size', 'zoomarts' ),
				'desc'    => __( 'Select your preferred size for this project. <strong>For Masonry Layout</strong>', 'zoomarts' ),
				'id'      => $prefix . 'project-masonry-size',
				'type'    => 'radio_inline',
				'default' => 'item-large',
				'options' => array(
					'masonry-large'   => __( 'Large', 'zoomarts' ),
					'masonry-small'   => __( 'Small', 'zoomarts' ),
					'masonry-high'    => __( 'High', 'zoomarts' ),
					'masonry-long'	  => __( 'Long', 'zoomarts' )
				)
			),
			array(
				'name' => 'Project Options',
				'type' => 'title',
				'id'   => $prefix . 'title_d',
			),
			array(
				'name'    => __( 'Project Layout', 'zoomarts' ),
				'desc'    => __( 'Select your preferred layout for this project.', 'zoomarts' ),
				'id'      => $prefix . 'project_layout',
				'type'    => 'radio_inline',
				'default' => 'wide-centered',
				'options' => array(
					'wide-centered'		=> __( 'One Column Wide', 'zoomarts' ),
					'mini-centered'   	=> __( 'One Column Mini', 'zoomarts' ),
					'two-columns-right'	=> __( 'Two Columns (Right Side Content)', 'zoomarts' ),
					'two-columns-left'	=> __( 'Two Columns (Left Side Content)', 'zoomarts' ),
					'page-builder'    	=> __( 'Page Builder', 'zoomarts' ),
				)
			),
			array(
				'name'    		=> __( 'Project Types', 'zoomarts' ),
			    'type'        	=> 'group',
			    'id'          	=> $prefix . 'project_thumb_content',
			    'description' 	=> __( 'Choose one of three types. <strong>Also You can add more rows', 'zoomarts' ),
			    'options'     	=> array(
			        'group_title'   	=> __( 'Row {#}', 'zoomarts' ), // since version 1.1.4, {#} gets replaced by row number
			        'add_button'    	=> __( 'Add Another Row', 'zoomarts' ),
			        'remove_button' 	=> __( 'Remove Row', 'zoomarts' ),
			        'sortable'      	=> true,
			    ),
			    'fields'      	=> array(
			    	array(
						'name' 			=> __( 'Image', 'zoomarts' ),
						'desc' 			=> __( 'Upload an image or enter a URL.', 'zoomarts' ),
						'id'   			=> 'project_thumb_image',
						'type'	 		=> 'file',
					),
			        array(
						'name'         	=> __( 'Slider', 'zoomarts' ),
						'desc'         	=> __( 'Upload images for slider.', 'zoomarts' ),
						'id'           	=> 'project_thumb_slider',
						'type'         	=> 'file_list',
						'preview_size' 	=> array( 50, 50 ),
					),
			        array(
						'name' 			=> __( 'Video', 'zoomarts' ),
						'desc' 			=> __( 'If you are video such as Youtube or Vimeo, paste the video url here.', 'zoomarts' ),
						'id'   			=> 'project_thumb_video',
						'type' 			=> 'oembed',
					),
			    ),
			),
			array(
				'name' => 'Project Options For Portfolio Page',
				'type' => 'title',
				'id'   => $prefix . 'title_a',
			),
			array(
				'name' => __( 'Custom Link', 'zoomarts' ),
				'desc' => __( 'Add custom link for this project. <strong>This link will appear beside the lightbox and project icons of this project in your portfolio.</strong>', 'zoomarts' ),
				'id'   => $prefix . 'project_custom_link',
				'type' => 'text',
			),
			array(
				'name'         => __( 'Custom LightBox Images', 'zoomarts' ),
				'desc'         => __( 'Upload an image for lightbox. <strong>Also you can upload one image</strong>', 'zoomarts' ),
				'id'           => $prefix . 'project_lightbox_image',
				'type'         => 'file_list',
				'preview_size' => array( 100, 100 ),
			),
			array(
				'name' => __( 'Custom LightBox Video', 'zoomarts' ),
				'desc' => __( 'If you are using video other than image such as Youtube or Vimeo, paste the video url here.<br/>Youtube Example: https://www.youtube.com/embed/uFQqf4wwc6M Vimeo Example: https://player.vimeo.com/video/155603994<br/><strong>This field will override the above.</strong>.', 'zoomarts' ),
				'id'   => $prefix . 'project_lightbox_video',
				'type' => 'oembed',
			),
			array(
				'name' => 'Page Header Options',
				'type' => 'title',
				'id'   => $prefix . 'title_a',
			),
			array(
				'name'    => __( 'Custom Header Layout', 'zoomarts' ),
				'id'      => $prefix . 'custom_header_layout',
				'desc'	  => __( 'Select your preferred header layout', 'zoomarts'),
				'type'    => 'radio_inline',
				'options' => array(
					'container' 		=> __( 'Container', 'zoomarts' ),
					'container-fluid'   => __( 'Full Width', 'zoomarts' ),
				),
				'default' => ''
			),
			array(
				'name'    => __( 'Custom Header Style', 'zoomarts' ),
				'id'      => $prefix . 'custom_header_style',
				'type'    => 'radio_inline',
				'options' => array(
					'default-bg' => __( 'Default', 'zoomarts' ),
					'transparent-light'   => __( 'Transparent Light', 'zoomarts' ),
					'transparent-dark'     => __( 'Transparent Dark', 'zoomarts' ),
				),
				'default' => 'default-bg'
			),
			array(
				'name'    => __( 'Display Top Bar', 'zoomarts' ),
				'id'      => $prefix . 'check_top_bar',
				'type'    => 'radio_inline',
				'options' => array(
					'on' => __( 'On', 'zoomarts' ),
					'off' => __( 'Off', 'zoomarts' ),
				),
				'default' => 'on'
			),
			array(
				'name' => 'Page Title Options',
				'type' => 'title',
				'id'   => $prefix . 'title_b',
			),
			array(
				'name'    => __( 'Display Page Title', 'zoomarts' ),
				'id'      => $prefix . 'check_page_title',
				'type'    => 'radio_inline',
				'options' => array(
					'enabled' => __( 'Enabled', 'zoomarts' ),
					'disabled' => __( 'Disabled', 'zoomarts' ),
				),
				'default' => 'enabled'
			),
			array(
				'name' => __( 'Title', 'zoomarts' ),
				'desc' => __( 'Enter your custom page title.', 'zoomarts' ),
				'id'   => $prefix . 'page_header_title',
				'type' => 'text',
			),
            array(
				'name' => __( 'Title Font Size', 'zoomarts' ),
				'desc' => __( 'Enter your page title font size in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'title_font_size',
				'type' => 'text_small',
                'default' => '24'
			),
            array(
				'name' => __( 'Title Line Height', 'zoomarts' ),
				'desc' => __( 'Enter your page title line height in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'title_line_height',
				'type' => 'text_small',
                'default' => '30'
			),
			array(
				'name' => __( 'Title Letter Spacing', 'zoomarts' ),
				'desc' => __( 'Enter your page title letter-spacing in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'title_letter_spacing',
				'type' => 'text_small',
			),
			array(
				'name'    => __( 'Title Text Transform', 'zoomarts' ),
				'id'      => $prefix . 'title_text_transform',
				'type'    => 'select',
				'options' => array(
					'none'    			=> __( 'None', 'zoomarts' ),
                    'capitalize'    	=> __( 'Capitalize', 'zoomarts' ),
                    'uppercase'    		=> __( 'Uppercase', 'zoomarts' ),
                    'lowercase'    		=> __( 'Lowercase', 'zoomarts' ),
				),
                'desc' => __( 'Select the text tansform for this page title.', 'zoomarts' ),
                'default' => 'none'
			),
            array(
				'name'    => __( 'Custom Font Family', 'zoomarts' ),
				'id'      => $prefix . 'title_font_family',
				'type'    => 'select',
				'options' => array(
                    ''    => '',
                    'custom-font-1'    => __( 'Custom Font 1', 'zoomarts' ),
                    'custom-font-2'    => __( 'Custom Font 2', 'zoomarts' ),
                    'custom-font-3'    => __( 'Custom Font 3', 'zoomarts' ),
                    'custom-font-4'    => __( 'Custom Font 4', 'zoomarts' ),
                    'custom-font-5'    => __( 'Custom Font 5', 'zoomarts' ),
                    'custom-font-6'    => __( 'Custom Font 6', 'zoomarts' ),
                    'custom-font-7'    => __( 'Custom Font 7', 'zoomarts' ),
                    'custom-font-8'    => __( 'Custom Font 8', 'zoomarts' ),
                    'custom-font-9'    => __( 'Custom Font 9', 'zoomarts' ),
                    'custom-font-10'    => __( 'Custom Font 10', 'zoomarts' ),
                    'custom-font-11'    => __( 'Custom Font 11', 'zoomarts' ),
                    'custom-font-12'    => __( 'Custom Font 12', 'zoomarts' ),
                    'custom-font-13'    => __( 'Custom Font 13', 'zoomarts' ),
                    'custom-font-14'    => __( 'Custom Font 14', 'zoomarts' ),
                    'custom-font-15'    => __( 'Custom Font 15', 'zoomarts' ),
				),
                'desc' => __( 'Choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
                'default' => ''
			),
			array(
				'name'    => __( 'Title Font Color', 'zoomarts' ),
				'desc'    => __( 'Select your preferred color for the page title font color.', 'zoomarts' ),
				'id'      => $prefix . 'title_font_color',
				'type'    => 'colorpicker',
			),
			array(
				'name' => __( 'Page Subtitle', 'zoomarts' ),
				'desc' => __( 'Enter your custom page subtitle.', 'zoomarts' ),
				'id'   => $prefix . 'page_header_subtitle',
				'type' => 'text',
			),
            array(
				'name' => __( 'Subtitle Font Size', 'zoomarts' ),
				'desc' => __( 'Enter your page subtitle font size in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'subtitle_font_size',
				'type' => 'text_small',
                'default' => '11'
			),
            array(
				'name' => __( 'Subtitle Line Height', 'zoomarts' ),
				'desc' => __( 'Enter your page subtitle line height in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'subtitle_line_height',
				'type' => 'text_small',
                'default' => '14'
			),
			array(
				'name' => __( 'Subtitle Letter Spacing', 'zoomarts' ),
				'desc' => __( 'Enter your page subtitle letter-spacing in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'subtitle_letter_spacing',
				'type' => 'text_small',
			),
			array(
				'name'    => __( 'Subtitle Text Transform', 'zoomarts' ),
				'id'      => $prefix . 'subtitle_text_transform',
				'type'    => 'select',
				'options' => array(
					'none'    			=> __( 'None', 'zoomarts' ),
                    'capitalize'    	=> __( 'Capitalize', 'zoomarts' ),
                    'uppercase'    		=> __( 'Uppercase', 'zoomarts' ),
                    'lowercase'    		=> __( 'Lowercase', 'zoomarts' ),
				),
                'desc' => __( 'Select the text tansform for this page subtitle.', 'zoomarts' ),
                'default' => 'none'
			),
            array(
				'name'    => __( 'Subtitle Custom Font Family', 'zoomarts' ),
				'id'      => $prefix . 'subtitle_font_family',
				'type'    => 'select',
				'options' => array(
                    ''    => '',
                    'custom-font-1'    => __( 'Custom Font 1', 'zoomarts' ),
                    'custom-font-2'    => __( 'Custom Font 2', 'zoomarts' ),
                    'custom-font-3'    => __( 'Custom Font 3', 'zoomarts' ),
                    'custom-font-4'    => __( 'Custom Font 4', 'zoomarts' ),
                    'custom-font-5'    => __( 'Custom Font 5', 'zoomarts' ),
                    'custom-font-6'    => __( 'Custom Font 6', 'zoomarts' ),
                    'custom-font-7'    => __( 'Custom Font 7', 'zoomarts' ),
                    'custom-font-8'    => __( 'Custom Font 8', 'zoomarts' ),
                    'custom-font-9'    => __( 'Custom Font 9', 'zoomarts' ),
                    'custom-font-10'    => __( 'Custom Font 10', 'zoomarts' ),
                    'custom-font-11'    => __( 'Custom Font 11', 'zoomarts' ),
                    'custom-font-12'    => __( 'Custom Font 12', 'zoomarts' ),
                    'custom-font-13'    => __( 'Custom Font 13', 'zoomarts' ),
                    'custom-font-14'    => __( 'Custom Font 14', 'zoomarts' ),
                    'custom-font-15'    => __( 'Custom Font 15', 'zoomarts' ),
                    
				),
                'desc' => __( 'Choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
                'default' => ''
			),
			array(
				'name'    => __( 'Subtitle Font Color', 'zoomarts' ),
				'desc'    => __( 'Select your preferred color for the page title font color.', 'zoomarts' ),
				'id'      => $prefix . 'subtitle_font_color',
				'type'    => 'colorpicker',
			),
            array(
				'name'    => __( 'Text Alignment', 'zoomarts' ),
				'id'      => $prefix . 'page_header_text_alignment',
				'type'    => 'radio_inline',
				'options' => array(
					'text-left' => __( 'Left', 'zoomarts' ),
					'text-right'   => __( 'Right', 'zoomarts' ),
					'text-center'     => __( 'Center', 'zoomarts' ),
				),
                'default' => 'text-left'
			),
			array(
				'name' => __( 'Page Title Top Padding', 'zoomarts' ),
				'desc' => __( "Don't include 'px' in the string. e.g. 50 .", 'zoomarts' ),
				'id'   => $prefix . 'page_header_top_padding',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'Page Title Bottom Padding', 'zoomarts' ),
				'desc' => __( "Don't include 'px' in the string. e.g. 50 .", 'zoomarts' ),
				'id'   => $prefix . 'page_header_bottom_padding',
				'type' => 'text_medium',
			),
			array(
				'name'    => __( 'Page Title Background Color', 'zoomarts' ),
				'desc'    => __( 'Select your preferred color for the page title background color.', 'zoomarts' ),
				'id'      => $prefix . 'page_header_background_color',
				'type'    => 'colorpicker',
			),
			array(
				'name' => __( 'Page Title Background Image', 'zoomarts' ),
				'desc' => __( 'Upload an image or enter a URL.', 'zoomarts' ),
				'id'   => $prefix . 'page_header_background_image',
				'type' => 'file',
			),
			array(
				'name'    => __( 'Page Title Parallax Effect', 'zoomarts' ),
				'desc'    => __( 'Select your preferred parallax effect for this page title.', 'zoomarts' ),
				'id'      => $prefix . 'page_haeder_parallax',
				'type'    => 'radio_inline',
				'options' => array(
					''   => __( 'None', 'zoomarts' ),
					'parallax_bg'     => __( 'Parallax Background', 'zoomarts' ),
					'parallax_content' => __( 'Parallax Content', 'zoomarts' ),
				),
			),
			array(
				'name' => 'Footer Options',
				'type' => 'title',
				'id'   => $prefix . 'title_b',
			),
			array(
				'name'    => __( 'Footer Widgets Area', 'zoomarts' ),
				'id'      => $prefix . 'check_widget_area',
				'type'    => 'radio_inline',
				'options' => array(
					'enabled' => __( 'Enabled', 'zoomarts' ),
					'disabled' => __( 'Disabled', 'zoomarts' ),
				),
				'default' => 'enabled'
			),
			array(
				'name'    => __( 'Footer Copyright Area', 'zoomarts' ),
				'id'      => $prefix . 'check_copyright_area',
				'type'    => 'radio_inline',
				'options' => array(
					'enabled' => __( 'Enabled', 'zoomarts' ),
					'disabled' => __( 'Disabled', 'zoomarts' ),
				),
				'default' => 'enabled'
			),
		),
	);
	
	
	/**
	 * Page Options
	 */
	$meta_boxes['metabox-page-options'] = array(
		'id'         => 'metabox-page-options',
		'title'      => __( 'Page Options', 'zoomarts' ),
		'pages'      => array( 'page', 'post', 'product' ),
		'context'    => 'normal',
		'priority'   => 'default',
		'show_names' => true,
		'fields'     => array(
			array(
				'name' => 'Page Header Options',
				'type' => 'title',
				'id'   => $prefix . 'title_a',
			),
			array(
				'name'    => __( 'Header Layout', 'zoomarts' ),
				'id'      => $prefix . 'custom_header_layout',
				'desc'	  => __( 'Select your preferred header layout', 'zoomarts'),
				'type'    => 'radio_inline',
				'options' => array(
					'container' 		=> __( 'Container', 'zoomarts' ),
					'container-fluid'   => __( 'Full Width', 'zoomarts' ),
				),
				'default' => ''
			),
			array(
				'name'    => __( 'Custom Header Style', 'zoomarts' ),
				'id'      => $prefix . 'custom_header_style',
				'type'    => 'radio_inline',
				'options' => array(
					'default-bg' => __( 'Default', 'zoomarts' ),
					'transparent-light'   => __( 'Transparent Light', 'zoomarts' ),
					'transparent-dark'     => __( 'Transparent Dark', 'zoomarts' ),
				),
				'default' => 'default-bg'
			),
			array(
				'name'    => __( 'Display Top Bar', 'zoomarts' ),
				'id'      => $prefix . 'check_top_bar',
				'type'    => 'radio_inline',
				'options' => array(
					'on' => __( 'On', 'zoomarts' ),
					'off' => __( 'Off', 'zoomarts' ),
				),
				'default' => 'on'
			),
			array(
				'name' => 'Page Title Options',
				'type' => 'title',
				'id'   => $prefix . 'title_b',
			),
			array(
				'name'    => __( 'Display Page Title', 'zoomarts' ),
				'id'      => $prefix . 'check_page_title',
				'type'    => 'radio_inline',
				'options' => array(
					'enabled' => __( 'Enabled', 'zoomarts' ),
					'disabled' => __( 'Disabled', 'zoomarts' ),
				),
				'default' => 'enabled'
			),
			array(
				'name' => __( 'Title', 'zoomarts' ),
				'desc' => __( 'Enter your custom page title.', 'zoomarts' ),
				'id'   => $prefix . 'page_header_title',
				'type' => 'text',
			),
            array(
				'name' => __( 'Title Font Size', 'zoomarts' ),
				'desc' => __( 'Enter your page title font size in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'title_font_size',
				'type' => 'text_small',
                'default' => '24'
			),
            array(
				'name' => __( 'Title Line Height', 'zoomarts' ),
				'desc' => __( 'Enter your page title line height in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'title_line_height',
				'type' => 'text_small',
                'default' => '30'
			),
			array(
				'name' => __( 'Title Letter Spacing', 'zoomarts' ),
				'desc' => __( 'Enter your page title letter-spacing in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'title_letter_spacing',
				'type' => 'text_small',
			),
			array(
				'name'    => __( 'Title Text Transform', 'zoomarts' ),
				'id'      => $prefix . 'title_text_transform',
				'type'    => 'select',
				'options' => array(
					'none'    			=> __( 'None', 'zoomarts' ),
                    'capitalize'    	=> __( 'Capitalize', 'zoomarts' ),
                    'uppercase'    		=> __( 'Uppercase', 'zoomarts' ),
                    'lowercase'    		=> __( 'Lowercase', 'zoomarts' ),
				),
                'desc' => __( 'Select the text tansform for this page title.', 'zoomarts' ),
                'default' => 'none'
			),
            array(
				'name'    => __( 'Custom Font Family', 'zoomarts' ),
				'id'      => $prefix . 'title_font_family',
				'type'    => 'select',
				'options' => array(
                    ''    => '',
                    'custom-font-1'    => __( 'Custom Font 1', 'zoomarts' ),
                    'custom-font-2'    => __( 'Custom Font 2', 'zoomarts' ),
                    'custom-font-3'    => __( 'Custom Font 3', 'zoomarts' ),
                    'custom-font-4'    => __( 'Custom Font 4', 'zoomarts' ),
                    'custom-font-5'    => __( 'Custom Font 5', 'zoomarts' ),
                    'custom-font-6'    => __( 'Custom Font 6', 'zoomarts' ),
                    'custom-font-7'    => __( 'Custom Font 7', 'zoomarts' ),
                    'custom-font-8'    => __( 'Custom Font 8', 'zoomarts' ),
                    'custom-font-9'    => __( 'Custom Font 9', 'zoomarts' ),
                    'custom-font-10'    => __( 'Custom Font 10', 'zoomarts' ),
                    'custom-font-11'    => __( 'Custom Font 11', 'zoomarts' ),
                    'custom-font-12'    => __( 'Custom Font 12', 'zoomarts' ),
                    'custom-font-13'    => __( 'Custom Font 13', 'zoomarts' ),
                    'custom-font-14'    => __( 'Custom Font 14', 'zoomarts' ),
                    'custom-font-15'    => __( 'Custom Font 15', 'zoomarts' ),
				),
                'desc' => __( 'Choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
                'default' => ''
			),
			array(
				'name'    => __( 'Title Font Color', 'zoomarts' ),
				'desc'    => __( 'Select your preferred color for the page title font color.', 'zoomarts' ),
				'id'      => $prefix . 'title_font_color',
				'type'    => 'colorpicker',
			),
			array(
				'name' => __( 'Page Subtitle', 'zoomarts' ),
				'desc' => __( 'Enter your custom page subtitle.', 'zoomarts' ),
				'id'   => $prefix . 'page_header_subtitle',
				'type' => 'text',
			),
            array(
				'name' => __( 'Subtitle Font Size', 'zoomarts' ),
				'desc' => __( 'Enter your page subtitle font size in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'subtitle_font_size',
				'type' => 'text_small',
                'default' => '11'
			),
            array(
				'name' => __( 'Subtitle Line Height', 'zoomarts' ),
				'desc' => __( 'Enter your page subtitle line height in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'subtitle_line_height',
				'type' => 'text_small',
                'default' => '14'
			),
			array(
				'name' => __( 'Subtitle Letter Spacing', 'zoomarts' ),
				'desc' => __( 'Enter your page subtitle letter-spacing in pixels.', 'zoomarts' ),
				'id'   => $prefix . 'subtitle_letter_spacing',
				'type' => 'text_small',
			),
			array(
				'name'    => __( 'Subtitle Text Transform', 'zoomarts' ),
				'id'      => $prefix . 'subtitle_text_transform',
				'type'    => 'select',
				'options' => array(
					'none'    			=> __( 'None', 'zoomarts' ),
                    'capitalize'    	=> __( 'Capitalize', 'zoomarts' ),
                    'uppercase'    		=> __( 'Uppercase', 'zoomarts' ),
                    'lowercase'    		=> __( 'Lowercase', 'zoomarts' ),
				),
                'desc' => __( 'Select the text tansform for this page subtitle.', 'zoomarts' ),
                'default' => 'none'
			),
            array(
				'name'    => __( 'Subtitle Custom Font Family', 'zoomarts' ),
				'id'      => $prefix . 'subtitle_font_family',
				'type'    => 'select',
				'options' => array(
                    ''    => '',
                    'custom-font-1'    => __( 'Custom Font 1', 'zoomarts' ),
                    'custom-font-2'    => __( 'Custom Font 2', 'zoomarts' ),
                    'custom-font-3'    => __( 'Custom Font 3', 'zoomarts' ),
                    'custom-font-4'    => __( 'Custom Font 4', 'zoomarts' ),
                    'custom-font-5'    => __( 'Custom Font 5', 'zoomarts' ),
                    'custom-font-6'    => __( 'Custom Font 6', 'zoomarts' ),
                    'custom-font-7'    => __( 'Custom Font 7', 'zoomarts' ),
                    'custom-font-8'    => __( 'Custom Font 8', 'zoomarts' ),
                    'custom-font-9'    => __( 'Custom Font 9', 'zoomarts' ),
                    'custom-font-10'    => __( 'Custom Font 10', 'zoomarts' ),
                    'custom-font-11'    => __( 'Custom Font 11', 'zoomarts' ),
                    'custom-font-12'    => __( 'Custom Font 12', 'zoomarts' ),
                    'custom-font-13'    => __( 'Custom Font 13', 'zoomarts' ),
                    'custom-font-14'    => __( 'Custom Font 14', 'zoomarts' ),
                    'custom-font-15'    => __( 'Custom Font 15', 'zoomarts' ),
				),
                'desc' => __( 'Choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
                'default' => ''
			),
			array(
				'name'    => __( 'Subtitle Font Color', 'zoomarts' ),
				'desc'    => __( 'Select your preferred color for the page title font color.', 'zoomarts' ),
				'id'      => $prefix . 'subtitle_font_color',
				'type'    => 'colorpicker',
			),
            array(
				'name'    => __( 'Text Alignment', 'zoomarts' ),
				'id'      => $prefix . 'page_header_text_alignment',
				'type'    => 'radio_inline',
				'options' => array(
					'text-left' => __( 'Left', 'zoomarts' ),
					'text-right'   => __( 'Right', 'zoomarts' ),
					'text-center'     => __( 'Center', 'zoomarts' ),
				),
                'default' => 'text-left'
			),
			array(
				'name' => __( 'Page Title Top Padding', 'zoomarts' ),
				'desc' => __( "Don't include 'px' in the string. e.g. 50 .", 'zoomarts' ),
				'id'   => $prefix . 'page_header_top_padding',
				'type' => 'text_medium',
			),
			array(
				'name' => __( 'Page Title Bottom Padding', 'zoomarts' ),
				'desc' => __( "Don't include 'px' in the string. e.g. 50 .", 'zoomarts' ),
				'id'   => $prefix . 'page_header_bottom_padding',
				'type' => 'text_medium',
			),
			array(
				'name'    => __( 'Page Title Background Color', 'zoomarts' ),
				'desc'    => __( 'Select your preferred color for the page title background color.', 'zoomarts' ),
				'id'      => $prefix . 'page_header_background_color',
				'type'    => 'colorpicker',
			),
			array(
				'name' => __( 'Page Title Background Image', 'zoomarts' ),
				'desc' => __( 'Upload an image or enter a URL.', 'zoomarts' ),
				'id'   => $prefix . 'page_header_background_image',
				'type' => 'file',
			),
			array(
				'name'    => __( 'Page Title Parallax Effect', 'zoomarts' ),
				'desc'    => __( 'Select your preferred parallax effect for this page title.', 'zoomarts' ),
				'id'      => $prefix . 'page_haeder_parallax',
				'type'    => 'radio_inline',
				'options' => array(
					''   => __( 'None', 'zoomarts' ),
					'parallax_bg'     => __( 'Parallax Background', 'zoomarts' ),
					'parallax_content' => __( 'Parallax Content', 'zoomarts' ),
				),
			),
			array(
				'name' => 'Footer Options',
				'type' => 'title',
				'id'   => $prefix . 'title_b',
			),
			array(
				'name'    => __( 'Footer Widgets Area', 'zoomarts' ),
				'id'      => $prefix . 'check_widget_area',
				'type'    => 'radio_inline',
				'options' => array(
					'enabled' => __( 'Enabled', 'zoomarts' ),
					'disabled' => __( 'Disabled', 'zoomarts' ),
				),
				'default' => 'enabled'
			),
			array(
				'name'    => __( 'Footer Copyright Area', 'zoomarts' ),
				'id'      => $prefix . 'check_copyright_area',
				'type'    => 'radio_inline',
				'options' => array(
					'enabled' => __( 'Enabled', 'zoomarts' ),
					'disabled' => __( 'Disabled', 'zoomarts' ),
				),
				'default' => 'enabled'
			),
		),
	);


	return $meta_boxes;
}


add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

}