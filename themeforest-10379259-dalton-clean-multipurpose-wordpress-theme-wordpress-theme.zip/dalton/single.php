<?php

	get_header();
	za_page_header();

	global $post;
	global $zoomarts_options;

	$cols_class	= 'with-sidebar';
	$default_layout = $zoomarts_options['single-post-layout'];
	$custom_layout = get_post_meta( $post->ID, 'za_page_layout', true );
	$sidebar_position = $custom_layout != '' ? $custom_layout : $default_layout;

	if ( $sidebar_position == 'fullwidth' ) {
		$cols_class = 'no-sidebar';
	}

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="main-content container <?php echo esc_attr( $sidebar_position ); ?>">
    
		<div class="page-inner clearfix">
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'left-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->

			<!-- Start Single Post Container -->
			<div class="post-wrap by-sidebar">
					
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					
					<!-- Start Post Item -->
					<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">

						<?php 
							$format = get_post_format();
							if( false === $format ) { $format = 'standard'; }
							get_template_part( 'includes/post-formats/content', $format );

							za_single_post_nav();

							if ( $zoomarts_options['post-author-bio'] == '1' ) {
								get_template_part( 'includes/author', 'info' );
							}

							if ( $zoomarts_options['post-related-posts'] == '1' ) {
								get_template_part( 'includes/related', 'posts' );
							}
							if ( comments_open() || get_comments_number() ) { comments_template('', true); }
						?>

					</div>
					<!-- End Post Item -->
					
				<?php endwhile; endif; ?>

			</div>
			<!-- End Single Post Container -->
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'right-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->
			
		</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>