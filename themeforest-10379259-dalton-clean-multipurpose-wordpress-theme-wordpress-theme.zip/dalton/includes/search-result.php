<?php

	global $post;
	global $zoomarts_options;

	if ( get_post_type($post->ID) == 'page' ) {
		$result_type = __('Page', 'zoomarts');
	} else if ( get_post_type($post->ID) == 'portfolio' ) {
		$result_type = __('Project', 'zoomarts');
	} else if ( get_post_type($post->ID) == 'product' ) {
		$result_type = __('Product', 'zoomarts');
	} else {
		$result_type = __('Other', 'zoomarts');
	}

?>

<?php if ( function_exists('has_post_thumbnail') && has_post_thumbnail() ) { ?>

    <div class="post-thumb">
		<div class="thumb-overlay"></div>
		<a class="post-url" title="<?php printf(__('Permanent Link to %s', 'zoomarts'), get_the_title()); ?>" href="<?php the_permalink(); ?>"><i class="icon-plus8"></i></a>
		<?php the_post_thumbnail('post-standard'); ?>
	</div>

<?php } ?>

<div class="post-side">
	<div class="post-head">
		<h2 class="post-title">
			<a class="post-url" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php printf(__('Permanent Link to %s', 'zoomarts'), get_the_title()); ?>"> <?php the_title(); ?></a>
			<span class="result-type"><?php echo ($result_type); ?></span>
		</h2>
		<?php get_template_part( 'includes/post', 'meta' ); ?>
	</div>

	<div class="content-area">
		<?php the_excerpt(); ?>
	</div>

	<div class="post-bottom clearfix">
		<a class="read-more main-button" href="<?php the_permalink(); ?>"><?php _e('Read More', 'zoomarts') ?> <i class="icon-arrow-right4"></i></a>
		<div class="views-likes">
			<span><?php if( function_exists('zoomarts_love') ) zoomarts_love(); ?></span>
			<?php if ( $zoomarts_options['post-views'] == '1' ) : ?>
				<span title="<?php _e('Post Views', 'zoomarts') ?>" ><i class="icon-eye7"></i> <?php echo za_get_post_views(get_the_ID()); ?></span>
			<?php endif; ?>
		</div>
	</div>
</div>

<div class="post-border"><span></span></div>
