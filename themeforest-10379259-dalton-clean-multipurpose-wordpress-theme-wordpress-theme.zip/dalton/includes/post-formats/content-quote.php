<?php 
	global $post;
	global $zoomarts_options;
	$quote_text = get_post_meta( $post->ID, 'za_quote_text', true );
	$quote_author = get_post_meta( $post->ID, 'za_quote_author', true );
	$quote_content = get_post_meta( $post->ID, 'za_quote_content', true );
?>

<div class="post-quote">
	<blockquote>
		<h4><?php echo esc_html( $quote_text ); ?></h4>
		<small><?php echo esc_html( $quote_author ); ?></small>
	</blockquote>
	<i class="icon-quote5"></i>
</div>

<?php if ( !is_singular() && $quote_content == 'on' || is_singular() ) : ?>
	<div class="post-side">
		<div class="post-head">
			<h2 class="post-title"><?php the_title(); ?></h2>
			<?php get_template_part( 'includes/post', 'meta' ); ?>
		</div>

		<div class="content-area">
			<?php if( !is_singular() ) : ?>
				<?php if ( $zoomarts_options['blog-excerpts'] == '1' ) {
					$za_excerpt_length = za_excerpt_length();
					za_excerpt( $za_excerpt_length );
				} else {
					the_content();
				} ?>
			<?php else: ?>
				<?php the_content(); ?>
			<?php endif; ?>
		</div>

		<div class="post-bottom clearfix">
			<?php if( !is_singular() ) : ?><a class="read-more main-button" href="<?php the_permalink(); ?>"><?php _e('Read More', 'zoomarts') ?> <i class="icon-arrow-right4"></i></a><?php endif; ?>
			<?php if( is_singular() ) : ?><div class="social-share"><span><?php echo __('Share:', 'zoomarts'); ?></span><?php za_social_share($post->ID); ?></div><?php endif; ?>
			<div class="views-likes">
				<?php if ( $zoomarts_options['post-likes'] == '1' ) : ?>
					<span><?php if( function_exists('zoomarts_love') ) zoomarts_love(); ?></span>
				<?php endif; ?>
				<?php if ( $zoomarts_options['post-views'] == '1' ) : ?>
					<span title="<?php _e('Post Views', 'zoomarts') ?>" ><i class="icon-eye7"></i> <?php echo za_get_post_views(get_the_ID()); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<?php if( is_singular() && has_tag() ) : ?><div class="post-tags"><span><?php _e('Tags', 'zoomarts') ?>:</span> <?php the_tags(' ', ''); ?></div><?php endif; ?>
	</div>
<?php endif; ?>

<?php if( !is_singular() ) : ?>
	<div class="post-border"><span></span></div>
<?php endif; ?>

<?php if( is_singular() ) { za_set_post_views(get_the_ID()); } ?>