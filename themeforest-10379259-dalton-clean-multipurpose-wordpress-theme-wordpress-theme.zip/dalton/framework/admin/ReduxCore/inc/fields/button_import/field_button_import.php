<?php

/**
 * Redux Framework is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * Redux Framework is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Redux Framework. If not, see <http://www.gnu.org/licenses/>.
 *
 * @package     Redux_Field
 * @subpackage  Button_Import
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Don't duplicate me!
if (!class_exists('ReduxFramework_button_import')) {

    /**
     * Main ReduxFramework_button_set class
     *
     * @since       1.0.0
     */
    class ReduxFramework_button_import {

        static $_properties = array(
            'id' => 'Identifier',
        );

        /**
         * Field Constructor.
         *
         * Required - must call the parent constructor, then assign field and value to vars, and obviously call the render field function
         *
         * @since       1.0.0
         * @access      public
         * @return      void
         */
        function __construct($field = array(), $value = '', $parent) {

            $this->parent   = $parent;
            $this->field    = $field;
            $this->value    = $value;
        }

        /**
         * Field Render Function.
         *
         * Takes the vars and outputs the HTML for the field in the settings
         *
         * @since       1.0.0
         * @access      public
         * @return      void
         */
        public function render() {
			$link =  "//$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$escaped_link = htmlspecialchars($link, ENT_QUOTES, 'UTF-8');
			echo '<div class="button-secondary button_data_import"><i class="steadysets-icon-download"></i>&nbsp;&nbsp;'. __("Import Demo Content", 'zoomarts') .'</div>';
			echo '<div class="importer-holder">';
            echo '</div>';
			echo '<div class="importer-result">';	
			echo '<div class="importer-result-success">'. __("All was done correctly! ", 'zoomarts');
			echo '<a href="'.  home_url() .'" target="_blank">';
			echo __("Have fun!", 'zoomarts');
			echo '</a><br>';
			
			echo '<em>'. __("Don't forget to", 'zoomarts');
			echo '<a href="'.  $escaped_link .'">';
			echo __(" refresh", 'zoomarts');
			echo '</a>';
			echo __(" your browser", 'zoomarts') .'</em>';
			echo '</div>';
			echo '<div class="importer-result-fail">';
			echo __("Sorry an error occur. Please try to import again or try with the standard Worpdress Importer plugin.", 'zoomarts');
			echo '</div>';
			echo '<div class="importer-result-warning">';
			echo __("WARNING! During import, one or more steps have been processed during more than 30s.", 'zoomarts') .'<br>';
			echo __("It can affect the demo content import.", 'zoomarts');
			echo '</div>';
			echo '</div>';
        }

        /**
         * Enqueue Function.
         *
         * If this field requires any scripts, or css define this function and register/enqueue the scripts/css
         *
         * @since       1.0.0
         * @access      public
         * @return      void
         */
        public function enqueue() {

        }
    }
}