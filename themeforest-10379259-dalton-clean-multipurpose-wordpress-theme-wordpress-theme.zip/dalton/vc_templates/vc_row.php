<?php
$output = $el_class = '';
extract(shortcode_atts(array(
	'el_class' 					=> '',
	'anchor' 					=> '',
	'fullheight_columns'		=> '',
	'row_type' 					=> 'fullwidth',
	'background_type' 			=> 'color_bg',
	'background_color' 			=> '',
	'background_image' 			=> '',
	'background_overlay_color' 	=> '',
	'background_position' 		=> '',
	'background_repeat' 		=> 'no-repeat',
	'cover_background' 			=> '',
	'background_attachment'		=> '',
	'background_effect' 		=> '',
	'background_animation'		=> 'animate-top',
	'crossfade_end_image' 		=> '',
	'video_type' 				=> 'youtube',
	'youtube_url' 				=> '',
	'video_webm' 				=> '',
	'video_mp4' 				=> '',
	'video_ogv' 				=> '',
	'video_poster' 				=> '',
	'text_color'				=> '',
	'fullscreen_section'		=> '',
	'css' 						=> ''
), $atts));

wp_enqueue_style( 'js_composer_front' );
wp_enqueue_script( 'wpb_composer_front_js' );
wp_enqueue_style('js_composer_custom_css');

$el_class = $this->getExtraClass($el_class);

$css_class =  apply_filters(VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'section '.get_row_css_class(). $el_class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base']);

$anchor_id = null;
$style = null;
$animate_style = null;
$cover_class = null;
$crossfade_start_image_attr = null;
$crossfade_end_image_attr = null;
$video_output = null;
$video_poster_output = $video_poster_src = $video_poster_src_output = null;
$background_effect_class = null;
$section_class = null;
$fullheight_class = null;
$background_parallax_speed = null;
$animate_block_output = null;
$fullscreen_section_class = null;

if ( $anchor != '' ) {
	$anchor_id = ' id="'.$anchor.'"';
}

if ( $fullheight_columns == 'true' ) {
	$fullheight_class = 'fullheight-columns';
}

if ( $background_type == 'color_bg' && $background_color != '' ) {
	$style .= 'background-color:'.$background_color.'; ';
}

if ( $background_type == 'image_bg' && $background_image != '' && $background_effect != 'crossfade' ) {
	if ( $background_effect == 'animation' ) {
		if( !preg_match('/^\d+$/',$background_image) ) {
			$animate_style .= 'background-image: url('. $background_image . '); ';
			$animate_style .= 'background-position: '. $background_position .'; ';
			$animate_style .= 'background-repeat: '. $background_repeat .'; ';
		} else {
			$bg_image_src = wp_get_attachment_image_src($background_image, 'full');
			$animate_style .= 'background-image: url('. $bg_image_src[0]. '); ';
			$animate_style .= 'background-position: '. $background_position .'; ';
			$animate_style .= 'background-repeat: '. $background_repeat .'; ';
		}
	} else {
		if( !preg_match('/^\d+$/',$background_image) ) {
			$style .= 'background-image: url('. $background_image . '); ';
			$style .= 'background-position: '. $background_position .'; ';
			$style .= 'background-repeat: '. $background_repeat .'; ';
		} else {
			$bg_image_src = wp_get_attachment_image_src($background_image, 'full');
			$style .= 'background-image: url('. $bg_image_src[0]. '); ';
			$style .= 'background-position: '. $background_position .'; ';
			$style .= 'background-repeat: '. $background_repeat .'; ';
		}
	}
}

if (  $background_type == 'video_bg' && $video_type == 'self-hosted' && $video_poster != '' ) {
	if( !preg_match('/^\d+$/',$video_poster) ) {
		$video_poster_output .= 'background-image: url('. $video_poster . '); ';
		$video_poster_src_output .= $video_poster;
	} else {
		$video_poster_src = wp_get_attachment_image_src($video_poster, 'full');
		$video_poster_output .= 'background-image: url('. $video_poster_src[0]. '); ';
		$video_poster_src_output .= $video_poster_src[0];
	}
}

if ( $background_type == 'video_bg' ) {
	if ( $video_type == 'youtube' ) {
		$video_data = "{videoURL:'".$youtube_url."',containment:'.yt-player-bg',autoPlay:true, mute:true, startAt:0, opacity:1}";
		$video_output .= '<div class="video-bg yt-player-bg" data-property="'.$video_data.'"></div>';
	} elseif ( $video_type == 'self-hosted' ) {
		$video_output .= '<div class="video-bg">';
		$video_output .= '<div class="mobile-video-image" style="'.$video_poster_output.'"></div>';
		$video_output .= '<video class="video" width="1920" height="800" poster="'.$video_poster_src_output.'" controls="controls" preload="auto" loop autoplay muted>';
		if ( !empty($video_webm) ) { $video_output .= '<source type="video/webm" src="'.$video_webm.'">'; }
		if ( !empty($video_mp4) ) { $video_output .= '<source type="video/mp4" src="'.$video_mp4.'">'; }
		if ( !empty($video_ogv) ) { $video_output .= '<source type="video/ogg" src="'. $video_ogv.'">'; }
		$video_output .='<object width="320" height="240" type="application/x-shockwave-flash" data="'.get_template_directory_uri().'/js/plugins/flashmediaelement.swf">
			<param name="movie" value="'.get_template_directory_uri().'/js/flashmediaelement.swf" />
			<param name="flashvars" value="controls=true&file='.$video_mp4.'" />
			<img src="'.$video_poster_src_output.'" width="1920" height="800" title="No video playback capabilities" alt="Video thumb" />
			</object>
			</video></div>';
	}
}

if ( $cover_background != '' ) {
	$cover_class .= ' cover-bg';
}

if ( $background_attachment != '' ) {
	$style .= ' background-attachment: fixed;';
}

if ( $background_type == 'image_bg' && $background_effect == 'parallax' ) {
	$background_effect_class .= ' parallax-bg';
	$background_parallax_speed .= ' data-stellar-background-ratio="0.4"';
} elseif ( $background_type == 'image_bg' && $background_effect == 'crossfade' ) {
	$background_effect_class .= ' crossfade';
	if(!preg_match('/^\d+$/',$background_image)) {
		$crossfade_start_image_attr .= 'data-crossfade-start="'.$background_image.'"';
	} else {
		$crossfade_start_image_src = wp_get_attachment_image_src($background_image, 'full');
		$crossfade_start_image_attr .= 'data-crossfade-start="'.$crossfade_start_image_src[0].'"';
	}
	if(!preg_match('/^\d+$/',$crossfade_end_image)) {
		$crossfade_end_image_attr .= 'data-crossfade-end="'.$crossfade_end_image.'"';
	} else {
		$crossfade_end_image_src = wp_get_attachment_image_src($crossfade_end_image, 'full');
		$crossfade_end_image_attr .= 'data-crossfade-end="'.$crossfade_end_image_src[0].'"';
	}
}

if ( $text_color != '' ) {
	$style .= ' color: '.$text_color.';';
}

if ( $fullscreen_section == 'true' ) {
	$fullscreen_section_class = 'fullscreen-section';
}

if ( $background_type == 'image_bg' && $background_effect == 'animation' ) {
	$animate_block_output = '<div class="bg-animation '.$cover_class.' '.$background_animation.' '.$background_position.' '.$background_repeat.'" style="'.$animate_style.'"></div>';
}


if ( $row_type == 'fullwidth' ){
	$output .= '<div style="'.$style.'" '.$anchor_id.' '.$crossfade_start_image_attr . $crossfade_end_image_attr .' '.$background_parallax_speed.' class="fullwidth '.$fullheight_class.' '.$fullscreen_section_class.' ' . $css_class . $cover_class . $background_effect_class . '">';
	$output .= $animate_block_output;
	$output .= $video_output;
	if ( $background_type != 'color_bg' && $background_overlay_color != '' ) {
		$output .= '<div class="section-overlay" style="background-color:'.$background_overlay_color.';"></div>';
	}
	if ( $background_type == 'image_bg' && $background_effect == 'crossfade' ) {
		$output .= '<div class="section-crossfade" '.$crossfade_start_image_attr . $crossfade_end_image_attr.'></div>';
	}
	if ( $fullscreen_section == 'true' ) {
		$output .= '<div class="centered-table"><div class="centered-table-cell">';
	}
	$output .= '<div class="container"><div class="row">';
}

elseif ( $row_type == 'fullwidth_content' ) {
	$output .= '<div style="'.$style.'" '.$anchor_id.' '.$crossfade_start_image_attr . $crossfade_end_image_attr .' '.$background_parallax_speed.' class="fullwidth_content '.$fullheight_class.' '.$fullscreen_section_class.' ' . $css_class . $cover_class . $background_effect_class . '">';
	$output .= $animate_block_output;
	$output .= $video_output;
	if ( $background_type != 'color_bg' && $background_overlay_color!= '' ) {
		$output .= '<div class="section-overlay" style="background-color:'.$background_overlay_color.';"></div>';
	}
	if ( $background_type == 'image_bg' && $background_effect == 'crossfade' ) {
		$output .= '<div class="section-crossfade" '.$crossfade_start_image_attr . $crossfade_end_image_attr.'></div>';
	}
}


// Display Content
$output .= wpb_js_remove_wpautop($content);

if ( $row_type == 'fullwidth' ) {
	$output .= '</div></div>';
}

if ( $fullscreen_section == 'true' ) {
	$output .= '</div></div>';
}

$output .= '</div>'.$this->endBlockComment('row');

echo ( $output );