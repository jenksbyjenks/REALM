<?php
//--------------------------- Dalton Theme Functions
 

/*-----------------------------------------------------------------------------------*/
/* Theme Name
/*-----------------------------------------------------------------------------------*/
define('ZA_THEME_NAME', 'dalton');
global $zoomarts_options;


/*-----------------------------------------------------------------------------------*/
/* Include Theme Functions
/*-----------------------------------------------------------------------------------*/
include_once( get_template_directory() . '/framework/functions/nav-menu/custom-menu.php');
require_once( get_template_directory() . '/framework/admin/redux-framework.php' );
require_once( get_template_directory() . '/framework/options/options.php' );
require_once( get_template_directory() . '/framework/meta/meta-config.php' );
require_once( get_template_directory() . '/framework/functions/excerpts.php' );
require_once( get_template_directory() . '/framework/functions/social-share.php' );
require_once( get_template_directory() . '/framework/functions/love/love-plugin.php' );
require_once( get_template_directory() . '/framework/functions/favicon-apple-icons.php' );
require_once( get_template_directory() . '/framework/functions/pages-header.php' );
require_once( get_template_directory() . '/framework/functions/custom-css.php' );
require_once( get_template_directory() . '/framework/functions/styling.php' );
require_once( get_template_directory() . '/framework/plugins/install-plugins.php' );
require_once( get_template_directory() . '/framework/shortcodes/shortcodes-generator.php');
require_once( get_template_directory() . '/framework/demo-importer/importer.php');
if ( class_exists( 'WooCommerce' ) ) {
	require_once( get_template_directory() . '/framework/functions/woo-commerce.php' );
}


/*-----------------------------------------------------------------------------------*/
/*	Load Widgets
/*-----------------------------------------------------------------------------------*/
require_once( get_template_directory() . '/framework/widgets/widget-posts-thumbnails.php' );
require_once( get_template_directory() . '/framework/widgets/widget-flickr.php' );
require_once( get_template_directory() . '/framework/widgets/widget-twitter.php' );
require_once( get_template_directory() . '/framework/widgets/widget-recent-comments.php' );


/*-----------------------------------------------------------------------------------*/
/*	Ajaxing Header Search
/*-----------------------------------------------------------------------------------*/
require_once( get_template_directory() . '/framework/functions/ajax-search/ajax-search.php' );


/*-----------------------------------------------------------------------------------*/
/*	Setup The Theme
/*-----------------------------------------------------------------------------------*/
if ( ! isset( $content_width ) ) $content_width = 1170;
if (!function_exists('zoomarts_setup')) {
    function zoomarts_setup() {
        add_editor_style();
		add_theme_support( 'post-thumbnails' );
        add_theme_support( 'automatic-feed-links' );
		register_nav_menus( array(
			'main_menu' => __( 'Header Menu', 'zoomarts' ),
			'responsive_menu' => __( 'Responsive Menu', 'zoomarts' ),
		) );
        load_theme_textdomain('zoomarts', get_template_directory() . '/languages');
		add_theme_support( 'post-formats', array( 'gallery', 'image', 'link', 'quote', 'video', 'audio', 'status', 'aside' ) );
    }
}
add_action('after_setup_theme', 'zoomarts_setup');


/*-----------------------------------------------------------------------------------*/
/* Register Sidebars */
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_sidebars_init' ) ) {

    function za_sidebars_init() {
		global $zoomarts_options;
		register_sidebar(array(
    		'name' 				=> __('Main Sidebar', 'zoomarts' ),
    		'id' 				=> 'main-sidebar',
    		'before_widget' 	=> '<div id="%1$s" class="widget %2$s">',
    		'after_widget' 		=> '</div>',
    		'before_title' 		=> '<h3 class="widget-title"><span>',
    		'after_title' 		=> '</span></h3>',
    	));
		register_sidebar(array(
    		'name' 				=> __('Single Sidebar', 'zoomarts' ),
    		'id' 				=> 'single-sidebar',
    		'before_widget' 	=> '<div id="%1$s" class="widget %2$s">',
    		'after_widget' 		=> '</div>',
    		'before_title' 		=> '<h3 class="widget-title"><span>',
    		'after_title' 		=> '</span></h3>',
    	));
		if ( isset($zoomarts_options['footer-cols']) && !empty($zoomarts_options['footer-cols']) ) {
			register_sidebar(array(
	    		'name' 				=> __('Footer First Column', 'zoomarts' ),
	    		'id' 				=> 'footer-widget-1',
	    		'before_widget' 	=> '<div id="%1$s" class="widget %2$s">',
	    		'after_widget' 		=> '</div>',
	    		'before_title' 		=> '<h3 class="widget-title"><span>',
	    		'after_title' 		=> '</span></h3>',
	    	));
	    	register_sidebar(array(
	    		'name' 				=> __('Footer Seconed Column', 'zoomarts' ),
	    		'id' 				=> 'footer-widget-2',
	    		'before_widget' 	=> '<div id="%1$s" class="widget %2$s">',
	    		'after_widget' 		=> '</div>',
	    		'before_title' 		=> '<h3 class="widget-title"><span>',
	    		'after_title' 		=> '</span></h3>',
	    	));
	    	if ( $zoomarts_options['footer-cols'] == '3-cols' || $zoomarts_options['footer-cols'] == '4-cols' ) {
		    	register_sidebar(array(
		    		'name' 				=> __('Footer Third Column', 'zoomarts' ),
		    		'id' 				=> 'footer-widget-3',
		    		'before_widget' 	=> '<div id="%1$s" class="widget %2$s">',
		    		'after_widget' 		=> '</div>',
		    		'before_title' 		=> '<h3 class="widget-title"><span>',
		    		'after_title' 		=> '</span></h3>',
		    	));
		    	if ( $zoomarts_options['footer-cols'] == '4-cols' ) {
			    	register_sidebar(array(
			    		'name' 				=> __('Footer Fourth Column', 'zoomarts' ),
			    		'id' 				=> 'footer-widget-4',
			    		'before_widget' 	=> '<div id="%1$s" class="widget %2$s">',
			    		'after_widget' 		=> '</div>',
			    		'before_title' 		=> '<h3 class="widget-title"><span>',
			    		'after_title' 		=> '</span></h3>',
			    	));
			    }
	    	}
		}
	}
	
}
add_action( 'widgets_init', 'za_sidebars_init' );


/*-----------------------------------------------------------------------------------*/
/*  Sidebars Generator
/*-----------------------------------------------------------------------------------*/
function za_custom_sidebars() {
	global $zoomarts_options;
	if( !empty($zoomarts_options['custom_sidebars']) && isset($zoomarts_options['custom_sidebars']) && sizeof($zoomarts_options['custom_sidebars']) > 0) {
		foreach( $zoomarts_options['custom_sidebars'] as $sidebar ) {
			if ( $sidebar != '' ) {
				register_sidebar( array(
					'name'              => $sidebar,
					'id'                => za_generateSlug($sidebar, 45),
					'before_widget'     => '<div id="%1$s" class="widget %2$s">',
					'after_widget'      => '</div>',
					'before_title'      => '<h3 class="widget-title"><span>',
					'after_title'       => '</span></h3>',
				) );
			}
		}
	}
}
function za_generateSlug($phrase, $maxLength) {
    $result = strtolower($phrase);
    $result = preg_replace("/[^a-z0-9\s-]/", "", $result);
    $result = trim(preg_replace("/[\s-]+/", " ", $result));
    $result = trim(substr($result, 0, $maxLength));
    $result = preg_replace("/\s/", "-", $result);
    return $result;
}
add_action( 'widgets_init', 'za_custom_sidebars' );


/*-----------------------------------------------------------------------------------*/
/*	Featured Images Sizes
/*-----------------------------------------------------------------------------------*/
add_image_size( 'post-standard', 	1080, 540, array( 'center', 'center' ) );
add_image_size( 'related-post', 	189, 120, array( 'center', 'center' ) );
add_image_size( 'widget-thumb', 	80, 80, array( 'center', 'center' ) );
add_image_size( 'masonry-small', 	450, 375, array( 'center', 'center' ) );
add_image_size( 'masonry-large', 	900, 750, array( 'center', 'center' ) );
add_image_size( 'masonry-high', 	450, 750, array( 'center', 'center' ) );
add_image_size( 'masonry-long', 	900, 375, array( 'center', 'center' ) );
add_image_size( 'grid-thumb', 		640, 520, array( 'center', 'center' ) );


/*-----------------------------------------------------------------------------------*/
/*	Load Jquery Files
/*-----------------------------------------------------------------------------------*/
function theme_scripts() {
	
	/* Register our scripts -----------------------------------------------------*/
	wp_register_script( 'modernizr', 			get_template_directory_uri() . '/js/modernizr.custom.js', 'jquery','2.6.2', false);
	wp_register_script( 'za-gmap-api', 			'https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=false', 'jquery','3.0', false);
	wp_register_script( 'easing', 				get_template_directory_uri() . '/js/plugins/jquery.easing.js', 'jquery','1.3', true);
	wp_register_script( 'bootstrap-js', 		get_template_directory_uri() . '/js/bootstrap.min.js', 'jquery','','3.0', true);
	wp_register_script( 'za-crossfade', 		get_template_directory_uri() . '/js/plugins/crossfade.jquery.js', 'jquery','1.0', true);
	wp_register_script( 'za-waypoints', 		get_template_directory_uri() . '/js/plugins/waypoints.min.js', 'jquery','','1.6.2', true);
	wp_register_script( 'za-fitvids', 			get_template_directory_uri() . '/js/plugins/jquery.fitvids.js', 'jquery','','1.1', true);
	wp_register_script( 'za-counter', 			get_template_directory_uri() . '/js/plugins/counter.min.js', 'jquery','','1.0', true);
	wp_register_script( 'za-YTPlayer', 			get_template_directory_uri() . '/js/plugins/jquery.mb.ytplayer.min.js', 'jquery','','1.0', true);
	wp_register_script( 'za-gmap', 				get_template_directory_uri() . '/js/gmap-script.php', 'jquery','','1.0', true);
	wp_register_script( 'za-pie-chart', 		get_template_directory_uri() . '/js/plugins/jquery.easypiechart.min.js', 'jquery','','2.1.6', true);
	wp_register_script( 'za-stellar', 			get_template_directory_uri() . '/js/plugins/jquery.stellar.min.js', 'jquery','0.6.2 ', true);
	wp_register_script( 'za-layers-parallax', 	get_template_directory_uri() . '/js/plugins/parallax.min.js', 'jquery','1.0', true);
	wp_register_script( 'za-lightcase', 		get_template_directory_uri() . '/js/plugins/lightcase.js', 'jquery','1.2.0', true);
	wp_register_script( 'za-pin', 				get_template_directory_uri() . '/js/plugins/jquery.pin.min.js', 'jquery','','1.2.43', true);
	wp_register_script( 'za-owl-carousel', 		get_template_directory_uri() . '/js/plugins/owl.carousel.min.js', 'jquery','','2.0', true);
	wp_register_script( 'za-swiper',			'http://idangero.us/swiper/dist/js/swiper.min.js', 'jquery', '3.3.1', true);
	wp_register_script( 'za-smooth-scroll', 	get_template_directory_uri() . '/js/plugins/smooth.scroll.js', 'jquery','1.2.1', true);
	wp_register_script( 'za-isotope-new', 		get_template_directory_uri() . '/js/plugins/isotope.pkgd.min.js', 'jquery', '2.1.0', true);
	wp_register_script( 'za-images-loaded', 	get_template_directory_uri() . '/js/plugins/imagesloaded.min.js', 'jquery','3.1.1', true);
	wp_register_script( 'za-mediaelement', 		get_template_directory_uri() . '/js/plugins/mediaelement-and-player.min.js', 'jquery', '2.16.4', true);
	wp_register_script( 'za-match-height', 		get_template_directory_uri() . '/js/plugins/jquery.matchHeight-min.js', 'jquery', '2.16.4', true);
	wp_register_script( 'za-flip-box',			get_template_directory_uri() . '/js/plugins/jquery.flip.min.js', 'jquery', '1.0.19', true);
	wp_register_script( 'za-min-plugins', 		get_template_directory_uri() . '/js/plugins/jquery-plugins-min.js', 'jquery', '1.0', true);
	wp_register_script( 'za-main', 				get_template_directory_uri() . '/js/main.js', 'jquery','','1.0', true);
	wp_register_script( 'za-loader', 			get_template_directory_uri() . '/js/loader.js', 'jquery','1.0', false);
		
	/* Enqueue our scripts ------------------------------------------------------*/
	global $zoomarts_options;

	wp_enqueue_script('jquery');
	wp_enqueue_script('modernizr');
	wp_enqueue_script('za-gmap-api');

	if( isset($zoomarts_options['minimzied-js']) && $zoomarts_options['minimzied-js'] == 1 ) {
		wp_enqueue_script('za-min-plugins');
	} else {
		wp_enqueue_script('easing');
		wp_enqueue_script('bootstrap-js');
		wp_enqueue_script('za-crossfade');
		wp_enqueue_script('za-stellar');
		wp_enqueue_script('za-layers-parallax');
		wp_enqueue_script('za-lightcase');
		wp_enqueue_script('za-waypoints');
		wp_enqueue_script('za-fitvids');
		wp_enqueue_script('za-counter');
		wp_enqueue_script('za-pie-chart');
		wp_enqueue_script('za-pin');
		wp_enqueue_script('za-owl-carousel');
		wp_enqueue_script('za-swiper');
		wp_enqueue_script('za-isotope-new');
		wp_enqueue_script('za-images-loaded');
		wp_enqueue_script('za-mediaelement');
		wp_enqueue_script('za-match-height');
		wp_enqueue_script('za-YTPlayer');
	}

	wp_enqueue_script('za-gmap');
	wp_enqueue_script('za-main');

	if( isset($zoomarts_options['loader']) && $zoomarts_options['loader'] == '1' ) wp_enqueue_script('za-loader');
	if( isset($zoomarts_options['smooth-scroll']) && $zoomarts_options['smooth-scroll'] == '1' ) wp_enqueue_script('za-smooth-scroll');
	
	// Load Comment Script
	if( is_singular() ) wp_enqueue_script('comment-reply');			
}
add_action( 'wp_enqueue_scripts', 'theme_scripts' );


/*-----------------------------------------------------------------------------------*/
/*	Load CSS Files
/*-----------------------------------------------------------------------------------*/
function theme_styles()  {  
	wp_enqueue_style( 'bootstrap', 			get_template_directory_uri() . '/css/bootstrap.min.css', array());
	wp_enqueue_style( 'bootstrap-theme', 	get_template_directory_uri() . '/css/bootstrap-theme.min.css', array());
	wp_enqueue_style( 'custom-icons', 		get_template_directory_uri() . '/css/icons.css', array());
	wp_enqueue_style( 'font-awesome', 		'https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css', array());
	wp_enqueue_style( 'plugins', 			get_template_directory_uri() . '/css/plugins.css', array());
	if ( class_exists( 'WooCommerce' ) ) {
		wp_enqueue_style( 'woo-commerce', 		get_template_directory_uri() . '/css/woo-commerce.css', array());
	}
	wp_enqueue_style( 'main-styles', 		get_template_directory_uri() . '/css/style.css', array());
	wp_enqueue_style( 'responsive', 		get_template_directory_uri() . '/css/responsive.css', array());	
}
add_action( 'wp_enqueue_scripts', 'theme_styles' );


/*-----------------------------------------------------------------------------------*/
/*	Post Views Count
/*-----------------------------------------------------------------------------------*/
function za_get_post_views($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0";
    }
    return $count;
}
function za_set_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}


/*-----------------------------------------------------------------------------------*/
/*	Add Excerpts for Pages
/*-----------------------------------------------------------------------------------*/
add_action( 'init', 'za_add_excerpts_to_pages' );
function za_add_excerpts_to_pages() {
	add_post_type_support( 'page', 'excerpt' );
}


/*-----------------------------------------------------------------------------------*/
/*	Comment Styling
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_comment' ) ) {
	function za_comment($comment, $args, $depth) {
	
        $GLOBALS['comment'] = $comment; ?>
        <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">

            <div id="comment-<?php comment_ID(); ?>" class="clearfix">
                <div class="avatar">
					<?php echo ( get_avatar($comment,$size='50') ); ?>
				</div>
				<div class="comment-right">
					<div class="comment-author">
						<?php printf('<cite class="fn">%s</cite>', get_comment_author_link()) ?>
					</div>
					<div class="comment-meta">
						<a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>"><?php printf(__('%1$s at %2$s', 'zoomarts'), get_comment_date(),  get_comment_time()) ?></a> -
						<?php edit_comment_link(__('Edit', 'zoomarts'),'  ','') ?> &middot; <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
					</div>
					<?php if ($comment->comment_approved == '0') { ?>
						<em class="moderation"><?php _e('Your comment is awaiting moderation.', 'zoomarts') ?></em>
						<br />
					<?php } ?>
					<div class="comment-body">
						<?php comment_text() ?>
					</div>
				</div>
            </div>
	<?php
	}
}


/*-----------------------------------------------------------------------------------*/
/*	Standard Pagination
/*-----------------------------------------------------------------------------------*/
function za_pagination() {
	
    global $wp_query;
    $pages = $wp_query->max_num_pages;
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	
    if (empty($pages)) { $pages = 1; }

    if (1 != $pages) {
		$big = 9999; // need an unlikely integer
        echo "<div class='page-pagination'>";
		$pagination = paginate_links(
			array(
				'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                'end_size' => 3,
                'mid_size' => 6,
                'format' => '?paged=%#%',
                'current' => max(1, get_query_var('paged')),
                'total' => $wp_query->max_num_pages,
                'type' => 'list',
                'prev_text' => '&#8592;',
                'next_text' => '&#8594;',
			)
		);
        echo ($pagination);
        echo "</div>";
    }
}


/*-----------------------------------------------------------------------------------*/
/*	Navigation For Single Pages
/*-----------------------------------------------------------------------------------*/
function za_single_post_nav() {
	$paged_page_nav = wp_link_pages( 
		array( 
			'before' =>'<div class="page-pagination"><ul>', 
			'after' => '</ul></div>', 
			'link_before' => '<span>', 
			'link_after' => '</span>', 
			'echo' => false 
		) 
	); 
	$paged_page_nav = str_replace( '<a', '<li><a', $paged_page_nav ); 
	$paged_page_nav = str_replace( '</span></a>', '</a></li>', $paged_page_nav );
	$paged_page_nav = str_replace( '"><span>', '">', $paged_page_nav ); 
    
	$paged_page_nav = str_replace( '<span>', '<li><span class="current">', $paged_page_nav ); 
	$paged_page_nav = str_replace( '</span>', '</span></li>', $paged_page_nav ); 
	echo ($paged_page_nav);
}


/*-----------------------------------------------------------------------------------*/
/*	limit Number of Tags Cloud Widget
/*-----------------------------------------------------------------------------------*/
add_filter('widget_tag_cloud_args', 'tag_widget_limit');
function tag_widget_limit($args){
	if(isset($args['taxonomy']) && $args['taxonomy'] == 'post_tag'){
		$args['number'] = 12;
	}
	return $args;
}


/*-----------------------------------------------------------------------------------*/
# New category walker for portfolio filter
/*-----------------------------------------------------------------------------------*/
class Walker_Portfolio_Filter extends Walker_Category {
	
   function start_el(&$output, $category, $depth = 0, $args = array(), $current_object_id = 0) {

      extract($args);
      $cat_slug = esc_attr( $category->slug );
      $cat_slug = apply_filters( 'portfolio-cats', $cat_slug, $category );
	  
      $link = '<li><span href="#" data-filter=".'.strtolower(preg_replace('/\s+/', '-', $cat_slug)).'">';
	  
	  $cat_name = esc_attr( $category->name );
      $cat_name = apply_filters( 'portfolio-cats', $cat_name, $category );
	  	
      $link .= $cat_name;
	  
      $link .= '</span></li>';
     
      $output .= $link;
       
   }
}


/*-----------------------------------------------------------------------------------*/
# Previous and Next Post in Same Taxonomy
/*-----------------------------------------------------------------------------------*/
function be_get_previous_post($in_same_cat = false, $excluded_categories = '', $taxonomy = 'category') {
	return be_get_adjacent_post($in_same_cat, $excluded_categories, true, $taxonomy);
}

function be_get_next_post($in_same_cat = false, $excluded_categories = '', $taxonomy = 'category') {
	return be_get_adjacent_post($in_same_cat, $excluded_categories, false, $taxonomy);
}

function be_get_adjacent_post( $in_same_cat = false, $excluded_categories = '', $previous = true, $taxonomy = 'category' ) {
	global $post, $wpdb;

	if ( empty( $post ) )
		return null;

	$current_post_date = $post->post_date;
	$join = '';
	$posts_in_ex_cats_sql = '';
	if ( $in_same_cat || ! empty( $excluded_categories ) ) {
		$join = " INNER JOIN $wpdb->term_relationships AS tr ON p.ID = tr.object_id INNER JOIN $wpdb->term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id";
		if ( $in_same_cat ) {
			$cat_array = wp_get_object_terms($post->ID, $taxonomy, array('fields' => 'ids'));
			$join .= " AND tt.taxonomy = '$taxonomy' AND tt.term_id IN (" . implode(',', $cat_array) . ")";
		}
		$posts_in_ex_cats_sql = "AND tt.taxonomy = '$taxonomy'";
		if ( ! empty( $excluded_categories ) ) {
			if ( ! is_array( $excluded_categories ) ) {
				// back-compat, $excluded_categories used to be IDs separated by " and "
				if ( strpos( $excluded_categories, ' and ' ) !== false ) {
					_deprecated_argument( __FUNCTION__, '3.3', sprintf( __( 'Use commas instead of %s to separate excluded categories.', 'zoomarts' ), "'and'" ) );
					$excluded_categories = explode( ' and ', $excluded_categories );
				} else {
					$excluded_categories = explode( ',', $excluded_categories );
				}
			}
			$excluded_categories = array_map( 'intval', $excluded_categories );
			if ( ! empty( $cat_array ) ) {
				$excluded_categories = array_diff($excluded_categories, $cat_array);
				$posts_in_ex_cats_sql = '';
			}
			if ( !empty($excluded_categories) ) {
				$posts_in_ex_cats_sql = " AND tt.taxonomy = '$taxonomy' AND tt.term_id NOT IN (" . implode($excluded_categories, ',') . ')';
			}
		}
	}

	$adjacent = $previous ? 'previous' : 'next';
	$op = $previous ? '<' : '>';
	$order = $previous ? 'DESC' : 'ASC';
	$join  = apply_filters( "get_{$adjacent}_post_join", $join, $in_same_cat, $excluded_categories );
	$where = apply_filters( "get_{$adjacent}_post_where", $wpdb->prepare("WHERE p.post_date $op %s AND p.post_type = %s AND p.post_status = 'publish' $posts_in_ex_cats_sql", $current_post_date, $post->post_type), $in_same_cat, $excluded_categories );
	$sort  = apply_filters( "get_{$adjacent}_post_sort", "ORDER BY p.post_date $order LIMIT 1" );
	$query = "SELECT p.* FROM $wpdb->posts AS p $join $where $sort";
	$query_key = 'adjacent_post_' . md5($query);
	$result = wp_cache_get($query_key, 'counts');
	if ( false !== $result )
		return $result;

	$result = $wpdb->get_row("SELECT p.* FROM $wpdb->posts AS p $join $where $sort");
	if ( null === $result )
		$result = '';

	wp_cache_set($query_key, $result, 'counts');
	return $result;
}

function be_previous_post_link($format='&laquo; %link', $link='%title', $in_same_cat = false, $excluded_categories = '', $taxonomy = 'category') {
	be_adjacent_post_link($format, $link, $in_same_cat, $excluded_categories, true, $taxonomy);
}

function be_next_post_link($format='%link &raquo;', $link='%title', $in_same_cat = false, $excluded_categories = '', $taxonomy = 'category') {
	be_adjacent_post_link($format, $link, $in_same_cat, $excluded_categories, false, $taxonomy);
}

function be_adjacent_post_link($format, $link, $in_same_cat = false, $excluded_categories = '', $previous = true, $taxonomy = 'category') {
	if ( $previous && is_attachment() )
		$post = & get_post($GLOBALS['post']->post_parent);
	else
		$post = be_get_adjacent_post($in_same_cat, $excluded_categories, $previous, $taxonomy);

	if ( !$post )
		return;

	$title = $post->post_title;

	if ( empty($post->post_title) )
		$title = $previous ? __('Previous Post', 'zoomarts') : __('Next Post', 'zoomarts');

	$title = apply_filters('the_title', $title, $post->ID);
	$date = mysql2date(get_option('date_format'), $post->post_date);
	$rel = $previous ? 'next' : 'prev';
	$string = '<a title="'.$title.'" href="'.get_permalink($post).'" rel="'.$rel.'" class="'.$rel.'">';
	$link = str_replace('%title', $title, $link);
	$link = str_replace('%date', $date, $link);
	$link = $string . $link . '</a>';
	$format = str_replace('%link', $link, $format);
	$adjacent = $previous ? 'previous' : 'next';
	echo apply_filters( "{$adjacent}_post_link", $format, $link );
}


/*-----------------------------------------------------------------------------------*/
/*  Get Portfolio Page
/*-----------------------------------------------------------------------------------*/
function get_portfolio_page($post_id) {
    global $wpdb;
	
    $results = $wpdb->get_results("SELECT post_id FROM $wpdb->postmeta
    WHERE meta_key='_wp_page_template' AND meta_value='template-portfolio.php'");
    
	//safety net
    $page_id = null;
	 
    foreach ($results as $result) 
    {
        $page_id = $result->post_id;
    }
	
    return get_page_link($page_id);
} 


/*-----------------------------------------------------------------------------------*/
/*  Customizing Redux Framework
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_customize_redux' ) ) {
	function za_customize_redux() {
		wp_register_style( 'redux-custom-icons', get_template_directory_uri() . '/css/icons.css', array(), time(), 'all' );
		wp_register_style( 'redux-custom-css', get_template_directory_uri() . '/css/redux-custom.css', array(), time(), 'all' );
		wp_enqueue_style('redux-custom-icons');
		wp_enqueue_style('redux-custom-css');
	}
}
add_action( 'redux/page/zoomarts_options/enqueue', 'za_customize_redux' );


/*-----------------------------------------------------------------------------------*/
/*  Header Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_display_header' ) ) {
    function za_display_header() {

        global $post;
        global $zoomarts_options;

        $check_sticky_top_bar = '0';
        $check_top_bar = $zoomarts_options['check-top-bar'];
        $header_height = $zoomarts_options['header-height'];
        $hidden_header_height = intval( intval($header_height));

        if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
        	if ( is_shop() || is_product_category() || is_product_tag() ) {
        		$post_id = get_option( 'woocommerce_shop_page_id' );
        	} elseif ( is_cart() ) {
        		$post_id = get_option( 'woocommerce_cart_page_id' );
        	} elseif ( is_checkout() ) {
        		$post_id = get_option( 'woocommerce_checkout_page_id' );
        	} elseif ( is_account_page() ) {
        		$post_id = get_option( 'woocommerce_myaccount_page_id' );
        	} elseif ( is_product() ) {
        		$post_id = $post->ID;
        	} else {
        		$post_id = get_option( 'woocommerce_shop_page_id' );
        	}
        } elseif (is_home() || is_archive()) {
            $post_id = get_option('page_for_posts');
        } elseif ( isset($post->ID) && !is_search() && !is_category() ) {
        	$post_id = $post->ID;
        }

        if ( isset($post->ID) && !is_search() && !is_category() ) {
        	$check_custom_top_bar = get_post_meta( $post_id, 'za_check_top_bar', true );
        	$check_custom_header_style = get_post_meta( $post_id, 'za_custom_header_style', true);
        	if ( $check_top_bar == '1' && ($check_custom_top_bar != 'off' || $check_custom_top_bar == 'on') ) {
	            $top_bar = '1';
	        } else {
	        	$top_bar = '0';
	        }
	        if ( $check_custom_header_style != '' ) {
	            $custom_header_style = get_post_meta( $post_id, 'za_custom_header_style', true );
	        } else {
	            $custom_header_style = 'default-bg';
	        }
        } else {
        	$custom_header_style = 'default-bg';
        	if ( $check_top_bar == '1' ) {
	            $top_bar = '1';
	        }
        }

        if ( isset($post->ID) && !is_search() && !is_category() ) {
        	$header_layout = get_post_meta( $post_id, 'za_custom_header_layout', true );
        } else {
        	$header_layout = $zoomarts_options['header-layout'];
        }
        
        if ( $header_layout == 'container-fluid' ) {
            $start_container_tb = '<div class="container-fluid">';
            $end_container_tb = '</div>';
        } else {
            $start_container_tb = '<div class="container">';
            $end_container_tb = '</div>';
        }

        if ( $zoomarts_options['sticky-top-bar'] == '1' && $top_bar == '1' ) {
        	$check_sticky_top_bar = '1';
        }

        include ( 'includes/headers/style-1.php' );

    }
}


/*-----------------------------------------------------------------------------------*/
/*  Top Bar Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_top_bar' ) ) {
    function za_top_bar() {
        
        global $zoomarts_options;
        global $post;

        $top_bar_class = null;

        if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
            if ( is_shop() || is_product_category() || is_product_tag() ) {
                $post_id = get_option( 'woocommerce_shop_page_id' );
            } elseif ( is_cart() ) {
                $post_id = get_option( 'woocommerce_cart_page_id' );
            } elseif ( is_checkout() ) {
                $post_id = get_option( 'woocommerce_checkout_page_id' );
            } elseif ( is_account_page() ) {
                $post_id = get_option( 'woocommerce_myaccount_page_id' );
            } elseif ( is_product() ) {
                $post_id = $post->ID;
            } else {
                $post_id = get_option( 'woocommerce_shop_page_id' );
            }
        } elseif (is_home() || is_archive()) {
            $post_id = get_option('page_for_posts');
        } elseif ( isset($post->ID) && !is_search() && !is_category() ) {
            $post_id = $post->ID;
        }

        if ( isset($zoomarts_options['top-bar-login-mob']) && $zoomarts_options['top-bar-login-mob'] == 1 ) {
		    $top_bar_class .= "login-mob ";
		}

		if ( isset($zoomarts_options['top-bar-lang-mob']) && $zoomarts_options['top-bar-lang-mob'] == 1 ) {
		    $top_bar_class .= "lang-mob ";
		}

		if ( isset($zoomarts_options['top-bar-email-mob']) && $zoomarts_options['top-bar-email-mob'] == 1 ) {
		    $top_bar_class .= "email-mob ";
		}

		if ( isset($zoomarts_options['top-bar-phone-mob']) && $zoomarts_options['top-bar-phone-mob'] == 1 ) {
		    $top_bar_class .= "phone-mob ";
		}

		if ( isset($zoomarts_options['top-bar-social-mob']) && $zoomarts_options['top-bar-social-mob'] == 1 ) {
		    $top_bar_class .= "social-icons-mob ";
		}

        if ( isset($post->ID) && !is_search() && !is_category() ) {
        	$top_bar_layout = get_post_meta( $post_id, 'za_custom_header_layout', true );
        } else {
        	$top_bar_layout = $zoomarts_options['top-bar-layout'];
        }
        
        if ( isset($top_bar_layout) && $top_bar_layout == 'container-fluid' ) {
            $start_container_tb = '<div class="container-fluid clearfix">';
            $end_container_tb = '</div>';
        } else {
            $start_container_tb = '<div class="container clearfix">';
            $end_container_tb = '</div>';
        }
        
        ?>
        
        <div id="top-bar" class="top-bar <?php echo $top_bar_class; ?>">
            <?php echo ($start_container_tb); ?>
                <div class="pull-right">
                    <?php if ( isset($zoomarts_options['top-bar-social-check']) && $zoomarts_options['top-bar-social-check'] == 'right-side' ) { ?>
                        <ul class="social-icons pull-right">
                            <?php foreach ( $zoomarts_options['top-bar-social'] as $key => $value ) { ?>
                            <?php if ( !empty($value) ) { ?>
                            	<?php if ( $key == 'xing' ) : ?>
                            		<li class="<?php echo esc_attr( $key ); ?>"><a href="<?php echo esc_url( $value ); ?>"><i class="fa fa-xing"></i></a></li>
                            	<?php else : ?>
                                	<li class="<?php echo esc_attr( $key ); ?>"><a href="<?php echo esc_url( $value ); ?>"><i class="icon-<?php echo esc_attr( $key ); ?>"></i></a></li>
                            	<?php endif; ?>
                            <?php }} ?>
                        </ul>
                    <?php } if ( isset($zoomarts_options['top-bar-lang']) && $zoomarts_options['top-bar-lang'] == 'right-side' ) { ?>
                        <div class="select-wrapper pull-right">
                            <?php if ( function_exists( 'icl_get_languages' ) ) { za_language_switcher(); } ?>
                        </div>
                    <?php } if ( isset($zoomarts_options['top-bar-phone']) && $zoomarts_options['top-bar-phone'] == 'right-side' ) { ?>
                        <div class="number-info pull-right"><span><i class="icon-telephone93"></i> <?php echo esc_html( $zoomarts_options['top-bar-phone-num'] ); ?></span></div>
                    <?php } if ( isset($zoomarts_options['top-bar-email']) && $zoomarts_options['top-bar-email'] == 'right-side' ) { ?>
                        <div class="email-info pull-right"><span><i class="icon-black218"></i></span> <?php echo esc_html( $zoomarts_options['top-bar-email-address'] ); ?></div>
                    <?php } if ( isset($zoomarts_options['top-bar-login']) && $zoomarts_options['top-bar-login'] == 'right-side' ) { ?>
                        <?php if (is_user_logged_in()) { ?>
                            <div class="user-login pull-right"><a href="<?php echo wp_logout_url( home_url() ); ?> "><span><i class="icon-user60"></i></span> <?php _e( 'User Logout', 'zoomarts' ); ?></a></div>
                        <?php } else { ?>
                            <div class="user-login pull-right"><a href="<?php echo wp_login_url( home_url() ); ?>"><span><i class="icon-user60"></i></span> <?php _e( 'User Login', 'zoomarts' ); ?></a></div>
                        <?php } ?>
                    <?php } ?>
                </div>
                <div class="pull-left">
                    <?php if ( isset($zoomarts_options['top-bar-social-check']) && $zoomarts_options['top-bar-social-check'] == 'left-side' ) { ?>
                        <ul class="social-icons pull-left">
                            <?php foreach ( $zoomarts_options['top-bar-social'] as $key => $value ) { ?>
                            <?php if ( !empty($value) ) { ?>
                                <?php if ( $key == 'xing' ) : ?>
                            		<li class="<?php echo esc_attr( $key ); ?>"><a href="<?php echo esc_url( $value ); ?>"><i class="fa fa-xing"></i></a></li>
                            	<?php else : ?>
                                	<li class="<?php echo esc_attr( $key ); ?>"><a href="<?php echo esc_url( $value ); ?>"><i class="icon-<?php echo esc_attr( $key ); ?>"></i></a></li>
                            	<?php endif; ?>
                            <?php }} ?>
                        </ul>
                    <?php } if ( isset($zoomarts_options['top-bar-lang']) && $zoomarts_options['top-bar-lang'] == 'left-side' ) { ?>
                        <div class="select-wrapper pull-right">
                            <?php if ( function_exists( 'icl_get_languages' ) ) { za_language_switcher(); } ?>
                        </div>
                    <?php } if ( isset($zoomarts_options['top-bar-phone']) && $zoomarts_options['top-bar-phone'] == 'left-side' ) { ?>
                        <div class="number-info pull-left"><span><i class="icon-telephone93"></i> <?php echo esc_html( $zoomarts_options['top-bar-phone-num'] ); ?></span></div>
                    <?php } if ( isset($zoomarts_options['top-bar-email']) && $zoomarts_options['top-bar-email'] == 'left-side' ) { ?>
                        <div class="email-info pull-left"><span><i class="icon-black218"></i> <?php echo esc_html( $zoomarts_options['top-bar-email-address'] ); ?></span></div>
                    <?php } if ( isset($zoomarts_options['top-bar-login']) && $zoomarts_options['top-bar-login'] == 'left-side' ) { ?>
                        <?php if (is_user_logged_in()) { ?>
                            <div class="user-login pull-left"><a href="<?php echo wp_logout_url( home_url() ); ?> "><span><i class="icon-user60"></i></span> <?php _e( 'User Logout', 'zoomarts' ); ?></a></div>
                        <?php } else { ?>
                            <div class="user-login pull-left"><a href="<?php echo wp_login_url( home_url() ); ?>"><span><i class="icon-user60"></i></span> <?php _e( 'User Login', 'zoomarts' ); ?></a></div>
                        <?php } ?>
                    <?php } ?>
                </div>
            <?php echo ($end_container_tb); ?>
        </div>
        
    <?php }
}


/*-----------------------------------------------------------------------------------*/
/*  WPML Langs Switcher Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_language_switcher' ) ) {
    function za_language_switcher() {
        $languages = icl_get_languages('skip_missing=0&orderby=code');
        echo '<div class="langs-list">';
        echo '<span><i class="icon-global28"></i> '.__( 'Select Language', 'zoomarts' ).' <i class="icon-chevron-small-down arrow"></i></span><ul>';
        foreach ($languages as $l) {
            echo '<li>';
            echo '<a href="' . $l['url'] . '">';
            echo '<img src="'.$l['country_flag_url'].'" height="8" alt="'.$l['language_code'].'" width="14" /> ';
            echo $l['translated_name'];
            echo '</a>';
            echo '</li>';
        }
        echo '</ul></div>';
    }
}


/*-----------------------------------------------------------------------------------*/
/*  Header WooCommerce Cart Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_header_checkout' ) ) {
    function za_header_checkout() {
        global $woocommerce;
        if ( !$woocommerce || is_cart() || is_checkout() ) { return false; }
        if ( class_exists( 'WooCommerce' ) ) {
            echo '<div class="wc-cart-icon">';
            echo '<a href="" class="woo-cart-icon"><i class="icon-shopping191"><span data-num="'.$woocommerce->cart->cart_contents_count.'">'.$woocommerce->cart->cart_contents_count.'</span></i></a>';
            echo '<div class="woo-cart-box">';
            the_widget( 'WC_Widget_Cart', 'title= ');
            echo '</div>';
            echo '</div>';
        }   
    }
}
add_action( 'header_checkout', 'za_header_checkout' );


/*-----------------------------------------------------------------------------------*/
/*  Adding Hover Class to Body for Products
/*-----------------------------------------------------------------------------------*/
if ( class_exists( 'WooCommerce' ) ) {
	function products_hover_class( $classes ) {
		global $zoomarts_options;
		if ( isset($zoomarts_options['products_hover']) && $zoomarts_options['products_hover'] == 0 ) {
			$classes[] = 'products-hover-disable';
		} else {
			$classes[] = 'products-hover-enable';
		}
		return $classes; 
	}
	add_filter( 'body_class','products_hover_class' );
}


/*-----------------------------------------------------------------------------------*/
/*  Custom Footer Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_footer_widgets' ) ) {
    function za_footer_widgets() {
        
        global $post;
        global $zoomarts_options;

        $check_widget_area = $check_copyright_area = null;

        if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
            if ( is_shop() || is_product_category() || is_product_tag() ) {
                $post_id = get_option( 'woocommerce_shop_page_id' );
            } elseif ( is_cart() ) {
                $post_id = get_option( 'woocommerce_cart_page_id' );
            } elseif ( is_checkout() ) {
                $post_id = get_option( 'woocommerce_checkout_page_id' );
            } elseif ( is_account_page() ) {
                $post_id = get_option( 'woocommerce_myaccount_page_id' );
            } elseif ( is_product() ) {
                $post_id = $post->ID;
            } else {
                $post_id = get_option( 'woocommerce_shop_page_id' );
            }
        } elseif (is_home() || is_archive()) {
            $post_id = get_option('page_for_posts');
        } elseif ( isset($post->ID) && !is_search() && !is_category() ) {
            $post_id = $post->ID;
        }

	    if ( isset($post->ID) && !is_search() && !is_category() ) {
	        $check_widget_area = get_post_meta( $post_id, 'za_check_widget_area', true );
	        $check_copyright_area = get_post_meta( $post_id, 'za_check_copyright_area', true );
    	}

        if ( $check_widget_area == 'disabled' ) {

    	} else { ?>

	        <!-- Start Footer -->
			<div id="footer" class="footer dark-footer">
				<div class="container">

					<!-- Go Top Links -->
					<a href="#" id="go-top"><i class="icon-chevron-up2"></i></a>

					<div class="row">

						<!-- First Column -->
						<?php if ( $zoomarts_options['footer-cols'] == '2-cols' ) : ?><div class="col-md-6"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '3-cols' ) : ?><div class="col-md-4"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '4-cols' ) : ?><div class="col-md-3"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '1-3-cols' ) : ?><div class="col-md-4"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '3-1-cols' ) : ?><div class="col-md-8"><?php endif; ?>
							<?php dynamic_sidebar('footer-widget-1'); ?>
						</div>

						<!-- Seconed Column -->
						<?php if ( $zoomarts_options['footer-cols'] == '2-cols' ) : ?><div class="col-md-6"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '3-cols' ) : ?><div class="col-md-4"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '4-cols' ) : ?><div class="col-md-3"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '1-3-cols' ) : ?><div class="col-md-8"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '3-1-cols' ) : ?><div class="col-md-4"><?php endif; ?>
							<?php dynamic_sidebar('footer-widget-2'); ?>
						</div>

						<!-- Third Column -->
						<?php if ( $zoomarts_options['footer-cols'] == '3-cols' || $zoomarts_options['footer-cols'] == '4-cols' ) : ?>
						<?php if ( $zoomarts_options['footer-cols'] == '3-cols' ) : ?><div class="col-md-4"><?php endif; ?>
						<?php if ( $zoomarts_options['footer-cols'] == '4-cols' ) : ?><div class="col-md-3"><?php endif; ?>
							<?php dynamic_sidebar('footer-widget-3'); ?>
						</div>
						<?php endif; ?>

						<!-- Fourth Column -->
						<?php if ( $zoomarts_options['footer-cols'] == '4-cols' ) : ?>
						<?php if ( $zoomarts_options['footer-cols'] == '4-cols' ) : ?><div class="col-md-3"><?php endif; ?>
							<?php dynamic_sidebar('footer-widget-4'); ?>
						</div>
						<?php endif; ?>

					</div>
				</div>
			</div>
			<!-- End Footer -->

        <?php };

        if ( $check_copyright_area == 'disabled' ) {

    	} else { ?>

    		<div id="copyright" class="copyright">
				<div class="container">
					<?php if ( isset($zoomarts_options['copyright-text']) && !empty($zoomarts_options['copyright-text']) ) { echo do_shortcode( $zoomarts_options['copyright-text'] ); } ?>
				</div>
			</div>

    	<?php };
        
    }
}


/*-----------------------------------------------------------------------------------*/
/*  Custom Footer Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_onepage_menu' ) ) {
	function za_onepage_menu() {
		global $post;

		$post_id = $post->ID;
		$check_onepage_menu = get_post_meta( $post_id, 'za_check_onepage', true );
		$onepage_menu_id = get_post_meta( $post_id, 'za_onepage_menu_id', true );

		if ( $check_onepage_menu == 'enabled' ) {
			wp_nav_menu( array( 'fallback_cb' => '', 'menu' => $onepage_menu_id, 'menu_id' => 'one-page-nav', 'menu_class' => 'one-page-nav', 'container' => false ) );
    	}

	}
}


/*-----------------------------------------------------------------------------------*/
/*  Set Title Output
/*-----------------------------------------------------------------------------------*/
function za_wp_title( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() )
		return $title;

	// Add the site name.
	$title .= get_bloginfo( 'name' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		$title = "$title $sep $site_description";

	// Add a page number if necessary.
	if ( $paged >= 2 || $page >= 2 )
		$title = "$title $sep " . sprintf( __( 'Page %s', 'zoomarts' ), max( $paged, $page ) );

	return $title;
}
add_filter( 'wp_title', 'za_wp_title', 10, 2 );


/*-----------------------------------------------------------------------------------*/
/*  Custom Background Color
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_custom_bg_color' ) ) {
	function za_custom_bg_color() {

		if(is_home()) {
			$post_id = get_queried_object_id();
		} else {
			$post_id = get_the_ID();
		}

		$custom_bg_color = get_post_meta( $post_id, 'za_custom_bg_color', true );

		if ( $custom_bg_color !== '' ) {
			$custom_bg_color = str_replace ( '&gt;' , '>' , $custom_bg_color );
			$output = "<style type=\"text/css\">\n body { background-color:".$custom_bg_color."; } \n</style>\n";
			echo $output;
		}

	}
}
add_action( 'wp_head', 'za_custom_bg_color' );


/*-----------------------------------------------------------------------------------*/
/*  Removing Redux Notices
/*-----------------------------------------------------------------------------------*/
function my_custom_fonts() {
  echo '<style>
    .redux-notice.notice {display: none!important;}
  </style>';
}
add_action('admin_head', 'my_custom_fonts');