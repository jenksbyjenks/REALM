//-------------- Loader Script --------------//
jQuery(window).load(function() {
	setTimeout(function() { jQuery("#loader").css({'top': '-100%'}); }, 100);
});