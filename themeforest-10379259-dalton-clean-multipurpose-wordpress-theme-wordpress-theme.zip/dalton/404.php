<?php

	get_header();

	global $zoomarts_options;

	$cols_class	= 'with-sidebar';
	$sidebar_position = $zoomarts_options['error-page-layout'];
	
	if ( $sidebar_position == 'fullwidth' ) { $cols_class = 'no-sidebar'; }

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="container <?php echo esc_attr( $sidebar_position ).' '.esc_attr( $cols_class ); ?>">
    
		<div class="page-inner clearfix">

			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'left-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->
			
			<!-- Start Error Msg Container -->
			<div class="by-sidebar error-msg">	

				<h1><?php _e('404', 'zoomarts') ?></h1>
				<h2><?php _e('Opps! Page Not Found', 'zoomarts') ?></h2>
				<p><?php _e("Sorry, but you are looking for something that isn't here.", 'zoomarts') ?></p>
				
			</div>
			<!-- End Error Msg Container -->
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'right-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->
			
		</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>