<?php
#-----------------------------------------------------------------#
# Woocommerce Functions
#-----------------------------------------------------------------#

global $zoomarts_options;
add_theme_support( 'woocommerce' );


//change the position of add to cart
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );

add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_add_to_cart', 60 );
add_action('woocommerce_before_shop_loop_item_title', 'product_thumbnail_with_cart', 10 );
add_action('woocommerce_before_shop_loop_item_title_close', 'product_thumbnail_with_cart_close', 10 );

function product_thumbnail_with_cart() {
	global $product;
	global $zoomarts_options;
	echo '<div class="product-wrap">';
		echo woocommerce_get_product_thumbnail();
		if ( isset($zoomarts_options['products_hover']) && $zoomarts_options['products_hover'] == 0 ) {
		} else {
		   	$attachment_ids = $product->get_gallery_attachment_ids();
		   	if ($attachment_ids) {
		   		$secondary_image_id = $attachment_ids['0'];
		   		echo wp_get_attachment_image( $secondary_image_id, 'shop_catalog', '', $attr = array('class' => 'secondary-thumb attachment-shop-catalog'));
		   	}
		}
}

function product_thumbnail_with_cart_close() {
	   	echo '<div class="product-overlay"><a class="product-link" href="'.get_permalink().'"></a></div>';
   	echo '<div class="loading"></div></div>';
}


// Removes the "shop" title on the main shop page
add_filter( 'woocommerce_show_page_title' , 'woo_hide_page_title' );
function woo_hide_page_title() {
	return false;
}


// Change Number of Products Per Page
add_filter( 'loop_shop_per_page', 'za_wc_product_perpage');
function za_wc_product_perpage() {
	global $zoomarts_options;
	return $zoomarts_options['products-num-page'];
}


// Change number or products per row to 3
add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
	function loop_columns() {
		global $zoomarts_options;
		$shop_columns = $zoomarts_options['shop-columns'];
		return $shop_columns;
	}
}


// Change number of related products on product page
if ( $zoomarts_options['related-products'] == '0' ) {
	function wc_remove_related_products( $args ) {
		return array();
	}
	add_filter('woocommerce_related_products_args','wc_remove_related_products', 10);
} else {
	function woo_related_products_limit() {
		global $product;
		global $zoomarts_options;
		$args['posts_per_page'] = $zoomarts_options['related-products-num'];
		return $args;
	}
	function za_related_products_args( $args ) {
		global $zoomarts_options;
		$args['posts_per_page'] = $zoomarts_options['related-products-num'];
		$args['columns'] = $zoomarts_options['related-products-num'];
		return $args;
	}
	add_filter( 'woocommerce_output_related_products_args', 'za_related_products_args' );
}


// Image sizes
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'za_woocommerce_image_dimensions', 1 );
// Define image sizes 
function za_woocommerce_image_dimensions() {
	$catalog = array(
		'width' => '300',	
		'height'	=> '360',	
		'crop'	=> 1 
	);
	$single = array(
		'width' => '580',	
		'height'	=> '620',	
		'crop'	=> 1 
	);
	$thumbnail = array(
		'width' => '130',	
		'height'	=> '130',	
		'crop'	=> 1 
	);
	update_option( 'shop_catalog_image_size', $catalog ); // Product category thumbs
	update_option( 'shop_single_image_size', $single ); // Single product image
	update_option( 'shop_thumbnail_image_size', $thumbnail ); // Image gallery thumbs
}


// Remove defaults woocommerce lightbox
add_action( 'wp_enqueue_scripts', 'za_manage_woocommerce_styles', 99 );
function za_manage_woocommerce_styles() {
	remove_action( 'wp_head', array( $GLOBALS['woocommerce'], 'generator' ) );
	wp_dequeue_style( 'woocommerce_fancybox_styles' );
	wp_dequeue_style( 'woocommerce_prettyPhoto_css' );
	wp_dequeue_script( 'prettyPhoto' );
	wp_dequeue_script( 'prettyPhoto-init' );
	wp_dequeue_script( 'fancybox' );
}


// Single featured product image
add_filter('woocommerce_single_product_image_html', 'za_single_product_image_html', 10, 2);
function za_single_product_image_html( $html, $post_id ) {$image_title 		= esc_attr( get_the_title( get_post_thumbnail_id() ) );
	$image_title = esc_attr(get_the_title(get_post_thumbnail_id($post_id)));
	$image_link  = esc_url(wp_get_attachment_url(get_post_thumbnail_id($post_id)));
	$image       = get_the_post_thumbnail( $post_id, apply_filters( 'single_product_large_thumbnail_size', 'shop_single' ), array('title' => $image_title, 'class' => 'small'));
	echo '<div class="inner-product-image">';
	echo '<div class="large" style="background: url('. esc_url(wp_get_attachment_url( get_post_thumbnail_id($post_id),'large')) .') no-repeat;"></div>';
	echo '<a class="lightbox" href="'.esc_url(wp_get_attachment_url( get_post_thumbnail_id($post_id),'large')).'" title="'.$image_title.'" data-lightbox-gallery="gallery-'.$post_id.'">';
	echo ( $image );
	echo '</a>';
	echo '</div>';
}


#-----------------------------------------------------------------#
# Wrap gallery single product for slider
#-----------------------------------------------------------------#

add_filter( 'woocommerce_single_product_image_thumbnail_html', 'za_single_prod_thumbnail', 15, 4 );
function za_single_prod_thumbnail( $html, $attachment_id, $post_ID, $image_class ) {
	
	global $first;
	
	if (empty($image_first) && isset($attachment_id) && $first != true) {
		$image_thumb       = wp_get_attachment_image_src(get_post_thumbnail_id($post_ID), 'shop_thumbnail');
		$image_thumb       = esc_url($image_thumb[0]);
		$image_first       = wp_get_attachment_image_src(get_post_thumbnail_id($post_ID), 'shop_single');
		$image_first       = esc_url($image_first[0]);
		$image_full        = esc_url(wp_get_attachment_url( get_post_thumbnail_id($post_ID), 'large'));
		$image_first_full  = esc_url(wp_get_attachment_url(get_post_thumbnail_id($post_ID)));
		$image_first_title = esc_attr(get_the_title(get_post_thumbnail_id($post_ID)));
		$image_first = '<div class="product-gallery first" data-gallery-full="'.$image_full.'" data-gallery-img="'.$image_first.'" data-img-title="'.$image_first_title.'"><img width="100" height="100" src="'.$image_thumb.'" class="attachment-shop_thumbnail" alt="'.$image_first_title.'"></div>';
		$first = true;
		echo ( $image_first );
	}
		
	$image_link  = wp_get_attachment_image_src( $attachment_id, 'shop_single');
	$image_link  = esc_url($image_link[0]);
	$image_full  = esc_url(wp_get_attachment_url($attachment_id));
	$image_title = esc_attr(get_the_title(get_post_thumbnail_id($attachment_id)));
    $content = '<div class="product-gallery" data-gallery-img="'.$image_link.'" data-gallery-full="'.$image_full.'" data-img-title="'.$image_title.'">'.preg_replace('#(<[/]?a.*>)#U', '', $html).'</div>';
    $content .= '<a class="hidden hidden-gallery" href="'.$image_full.'" data-lightbox-gallery="gallery-'.$post_ID.'"></a>';
    echo ( $content );
}


// Custom Banner for Products Categories
if ( ! class_exists( 'WCB_Category_Banner' ) ) :

	class WCB_Category_Banner {
		public function __construct() {
			global $woocommerce;
			global $wp_query;
			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts_and_styles' ) );
			add_action( 'product_cat_edit_form_fields', array( $this, 'wcb_product_cat_taxonomy_custom_fields' ), 10, 2 );  
			add_action( 'edited_product_cat', array( $this, 'wcb_product_cat_save_taxonomy_custom_fields'), 10, 2 );  
			add_action( 'woocommerce_show_category_banner', array( $this, 'wcb_show_category_banner'), 30 );
		}

		public function admin_scripts_and_styles() {
			$screen = get_current_screen();
			if ( $screen != null and $screen->id == "edit-product_cat" ) {
				wp_enqueue_media();
				wp_enqueue_script( 'wcb_admin_script', get_template_directory_uri() . '/framework/functions/assets/js/wcb-admin.js', array('jquery'), '1.0.0', true );
				wp_enqueue_style( 'wcb_admin_styles', 			get_template_directory_uri() . '/framework/functions/assets/css/wcb-admin.css', array());
			}
		}

		public function wcb_product_cat_taxonomy_custom_fields( $tag ) {
		    $t_id = $tag->term_id;
		    $term_meta = get_option( "taxonomy_term_$t_id" );

		    if ( isset( $term_meta['banner_url_id'] ) and $term_meta['banner_url_id'] != '' )
	    	    $banner_id = $term_meta['banner_url_id'];
		    else 
	    	    $banner_id = null;

	    	if ( isset( $term_meta['banner_link'] ) and $term_meta['banner_link'] != '' )
	    		$banner_link = $term_meta['banner_link'];
	    	else 
	    	    $banner_link = null;

		    ?>  
		    
			<tr class="form-field banner_url_form_field">  
			    <th scope="row" valign="top">  
			        <label for="banner_url"><?php _e('Banner Image'); ?></label>  
			    </th>  
			    <td>  
			    	<fieldset>
						<a class='wcb_upload_file_button button' uploader_title='Select File' uploader_button_text='Include File'>Upload File</a>
						<a class='wcb_remove_file button'>Remove File</a>
						<label class='banner_url_label' ><?php if ( $banner_id != null ) echo basename( wp_get_attachment_url( $banner_id ) ) ?></label>
			    	</fieldset>
			    	
			    	<fieldset>				
						<img class="cat_banner_img_admin" src="<?php if ( $banner_id != null ) echo wp_get_attachment_url( $banner_id ) ?>" />
			    	</fieldset>
			    	
					<input type="hidden" class='wcb_image' name='term_meta[banner_url_id]' value='<?php if ( $banner_id != null ) echo $banner_id; ?>' />
				</td>  
			</tr>  
			
			<tr class="form-field banner_link_form_field">  
			    <th scope="row" valign="top">  
			        <label for="banner_link"><?php _e('Banner Image Link'); ?></label>  
			    </th>  
			    <td>  
			    	<fieldset>	
						<input type="url" name='term_meta[banner_link]' value='<?php if ( $banner_link != null ) echo $banner_link ?>' />		
						<label class="banner_link_label" for="banner_link"><em>Where users will be directed if they click the banner.</em></label>		
			    	</fieldset>
				</td>  
			</tr> 
		<?php  
		}

		public function wcb_product_cat_save_taxonomy_custom_fields( $term_id ) {
		    if ( isset( $_POST['term_meta'] ) ) {  
		        $t_id = $term_id;  
		        $term_meta = get_option( "taxonomy_term_$t_id" );  
		        $posted_term_meta = $_POST['term_meta'];
		        $cat_keys = array_keys( $posted_term_meta );  
		        foreach ( $cat_keys as $key ){  
		            if ( isset( $posted_term_meta[$key] ) ){  
		                $term_meta[$key] = $posted_term_meta[$key];  
		            }  
		        }  
		        update_option( "taxonomy_term_$t_id", $term_meta );  
		    }
		}

		public function wcb_show_category_banner() {
			global $woocommerce;
			global $wp_query;

			if ( is_product_category() ) {
				$cat_id = $wp_query->queried_object->term_id;
				$term_options = get_option( "taxonomy_term_$cat_id" );

				if ( $term_options['banner_url_id'] != '' )
					$url = wp_get_attachment_url( $term_options['banner_url_id'] );

				if ( !isset( $url ) or $url == false )
					return;

				echo "<div class='woo-cat-banner'>";

				if ( $term_options['banner_link'] != '' )
					$link = $term_options['banner_link'];

				if ( isset( $link ) )
					echo "<a href='" . $link . "'>"; 
				
				if ( $url != false ) 
					echo "<img src='" . $url . "' class='category_banner_image' />";
				
				if ( isset( $link ) )
					echo "</a>";

				echo "</div>";
			}
		}
	}

endif;
$WCB_Category_Banner = new WCB_Category_Banner();

//Shortcode function for displaying banner.
function wcb_show_category_banner() {
	global $WCB_Category_Banner;
	$WCB_Category_Banner->wcb_show_category_banner();
}