<?php

	get_header();
	za_page_header();

	global $zoomarts_options;

	$cols_class	= 'with-sidebar';
	$container_class = 'container';
	$sidebar_position = $zoomarts_options['category-layout'];

	if ( $sidebar_position == 'fullwidth' || $zoomarts_options['blog-style'] == 'blog-masonry' ) {
		$cols_class = 'no-sidebar';
	}

	if ( $zoomarts_options['blog-style'] == 'blog-masonry' ) {
		$sidebar_position 	= 'fullwidth';
		$cols_class = 'no-sidebar';
		$blog_masonry_cols 	= $zoomarts_options['blog-masonry-cols'];
		if ( $blog_masonry_cols == 'blog-fullwidth-cols-4' || $blog_masonry_cols == 'blog-fullwidth-cols-5' ) {
			$container_class = 'container-fluid';
		}
	}

?>

	<!-- Start Main Container -->
    <div id="main-content" class="<?php echo esc_attr( $container_class ).' '.esc_attr( $sidebar_position ).' '.esc_attr( $cols_class ); ?>">

			<div class="page-inner clearfix">

				<!-- Start Sidebar -->
				<?php if ( $sidebar_position == 'left-sidebar' ) { get_sidebar(); } ?>
				<!-- End Sidebar -->

				<!-- Start Posts Container -->
				<div class="blog-items category-posts by-sidebar <?php echo esc_attr( $zoomarts_options['blog-style'] ).' '.esc_attr( $blog_masonry_cols ); ?>">
					
					<ul class="items-list isotope">
						<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
					
							<!-- Start Post Item -->
							<li <?php post_class(); ?> id="post-<?php the_ID(); ?>">

								<?php 
									$format = get_post_format();
									if ( false === $format ) { $format = 'standard'; }
								?>

								<?php get_template_part( 'includes/post-formats/content', $format ); ?>
								
							</li>
							<!-- End Post Item -->

						<?php endwhile; endif; ?>
					</ul>

					<?php if ( $zoomarts_options['blog-pagination-style'] == 'standard' ) : ?>
						<?php za_pagination(); ?>
					<?php else : ?>
						<div class="page-navigation clearfix">
							<div class="nav-next"><?php next_posts_link('&#8594;') ?></div>
							<div class="nav-previous"><?php previous_posts_link('&#8592;') ?></div>
						</div>
					<?php endif; ?>
					
				</div>
				<!-- End Posts Container -->
			
				<!-- Start Sidebar -->
				<?php if ( $sidebar_position == 'right-sidebar' ) { get_sidebar(); } ?>
				<!-- End Sidebar -->

			</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>