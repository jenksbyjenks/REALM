<?php

class zoomarts_recent_posts_thumb extends WP_Widget {
	
	/** constructor */
	function zoomarts_recent_posts_thumb() {
		parent::__construct(false, $name = __('Smart Recent Posts','zoomarts' ), array( 'description' => __( 'Shows a listing of your recent or random posts with their thumbnail for any chosen post type.', 'zoomarts' ) ) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance) {
		extract( $args );
		$title = $instance['title'];
		$number = $instance['number'];
		$style = isset($instance['style']) ? $instance['style'] : '';
		$order = $instance['order'];
		$date = isset( $instance['date'] ) ? $instance['date'] : '';
		$post_type = $instance['post_type'];
			echo ($before_widget);
				if ( $title )
						echo ($before_title) . ($title) . ($after_title); ?>
							<ul class="widget-recent-posts clearfix style-<?php echo ($style); ?>">
							<?php
								global $post;
								$args = array(
									'post_type'			=> $post_type,
									'numberposts'		=> $number,
									'orderby'			=> $order,
									'no_found_rows'		=> true,
									'suppress_filters'	=> false,
									'meta_key'			=> '_thumbnail_id',
								);
								$myposts = get_posts( $args );
								foreach( $myposts as $post ) : setup_postdata($post);
								$thumb_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'widget-thumb' );
								if( has_post_thumbnail() ) { ?>
									<li class="clearfix widget-recent-posts-li">
										<a class="widget-recent-posts-thumbnail za-tooltip" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" data-placement="bottom">
											<img src="<?php echo ($thumb_url[0]); ?>" alt="<?php the_title(); ?>" />
										</a>
										<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="widget-recent-posts-title"><?php the_title(); ?></a>
										<?php if ( $date !== '1' ) { ?>
											<div class="widget-post-date"><?php echo esc_html( get_the_date() ); ?></div>
										<?php } ?>
									</li>
							<?php
							} endforeach; wp_reset_postdata(); ?>
							</ul>
			<?php echo ($after_widget);
	}

	/** @see WP_Widget::update */
	function update($new_instance, $old_instance) {
	$instance = $old_instance;
	$instance['title'] = strip_tags($new_instance['title']);
	$instance['number'] = strip_tags($new_instance['number']);
	$instance['style'] = strip_tags($new_instance['style']);
	$instance['order'] = strip_tags($new_instance['order']);
	$instance['date'] = strip_tags($new_instance['date']);
	$instance['post_type'] = strip_tags($new_instance['post_type']);
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance) {
		$instance = wp_parse_args( (array) $instance, array(
			'title'			=> __('Recent Posts', 'zoomarts' ),
			'style'			=> 'default',
			'post_type'		=> 'post',
			'number'		=> '3',
			'order'			=> 'ASC',
			'date'			=> '',
		) );
		$title = $instance['title'];
		$number = esc_attr($instance['number']);
		$style = esc_attr($instance['style']);
		$order = esc_attr( $instance['order'] );
		$date = esc_attr( $instance['date'] );
		$post_type = esc_attr( $instance['post_type'] ); ?>
		
		
		<p>
		<label for="<?php echo ($this->get_field_id('title')); ?>"><?php _e( 'Title:', 'zoomarts' ); ?></label> 
		<input class="widefat" id="<?php echo ($this->get_field_id('title')); ?>" name="<?php echo ($this->get_field_name('title','zoomarts' )); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo ($this->get_field_id('style')); ?>"><?php _e( 'Style', 'zoomarts' ); ?></label>
			<br />
			<select class='zoomarts-select' name="<?php echo ($this->get_field_name('style')); ?>" id="<?php echo ($this->get_field_id('style')); ?>">
				<option value="default" <?php if($style == 'default') { ?>selected="selected"<?php } ?>><?php _e( 'Small Images', 'zoomarts' ); ?></option>
				<option value="grid" <?php if($style == 'grid-images') { ?>selected="selected"<?php } ?>><?php _e( 'Grid Style', 'zoomarts' ); ?></option>
			</select>
		</p>
		
		<p>
		<label for="<?php echo ($this->get_field_id('post_type')); ?>"><?php _e( 'Post Type?', 'zoomarts' ); ?></label> 
		<br />
		<select class='zoomarts-select' name="<?php echo ($this->get_field_name('post_type')); ?>" id="<?php echo ($this->get_field_id('post_type')); ?>">
			<option value="post" <?php if($post_type == 'post') { ?>selected="selected"<?php } ?>><?php _e( 'Post', 'zoomarts' ); ?></option>
			<?php
			//get post_typeonomies
			$args=array('public' => true,'_builtin' => false, 'exclude_from_search' => false); 
			$output = 'names'; // or objects
			$operator = 'and'; // 'and' or 'or'
			$get_post_types = get_post_types($args,$output,$operator);
			foreach ($get_post_types as $get_post_type ) {
				if( $get_post_type != 'post' && $get_post_type !== 'faq' ){ ?>
				<option value="<?php echo ($get_post_type); ?>" id="<?php $get_post_type; ?>" <?php if($post_type == $get_post_type) { ?>selected="selected"<?php } ?>><?php echo ucfirst( $get_post_type ); ?></option>
			<?php } } ?>
		</select>
		</p>
		
		<p>
		<label for="<?php echo ($this->get_field_id('order')); ?>"><?php _e( 'Random or Recent?', 'zoomarts' ); ?></label>
		<br />
		<select class='zoomarts-select' name="<?php echo ($this->get_field_name('order')); ?>" id="<?php echo ($this->get_field_id('order')); ?>">
			<option value="ASC" <?php if($order == 'ASC') { ?>selected="selected"<?php } ?>><?php _e( 'Recent', 'zoomarts' ); ?></option>
			<option value="rand" <?php if($order == 'rand') { ?>selected="selected"<?php } ?>><?php _e( 'Random', 'zoomarts' ); ?></option>
			<option value="comment_count" <?php if( $order == 'comment_count' ) { ?>selected="selected"<?php } ?>><?php _e( 'Most Comments', 'zoomarts' ); ?></option>
			<option value="modified" <?php if( $order == 'modified' ) { ?>selected="selected"<?php } ?>><?php _e( 'Last Modified', 'zoomarts' ); ?></option>
		</select>
		</p>
		
		<p>
		<label for="<?php echo ($this->get_field_id('number')); ?>"><?php _e( 'Number to Show', 'zoomarts' ); ?></label> 
		<input class="widefat" id="<?php echo ($this->get_field_id('number')); ?>" name="<?php echo ($this->get_field_name('number')); ?>" type="text" value="<?php echo ($number); ?>" />
		</p>

		<p>
			<input id="<?php echo ($this->get_field_id('date')); ?>" name="<?php echo ($this->get_field_name('date')); ?>" type="checkbox" value="1" <?php checked( '1', $date ); ?> />
			<label for="<?php echo ($this->get_field_id('date')); ?>"><?php _e( 'Disable Date?', 'zoomarts' ); ?></label>
		</p>
		
		<?php
	}


} // class zoomarts_recent_posts_thumb
// register Recent Posts widget
add_action('widgets_init', create_function('', 'return register_widget("zoomarts_recent_posts_thumb");')); ?>