<?php
	global $zoomarts_options;
?>

<ul class="post-meta">
	<li><?php echo esc_attr( get_the_date( 'M d, Y' ) ); ?></li>
	<li><?php echo __('By', 'zoomarts').' '; the_author_posts_link(); ?></li>
	<li><?php _e('In', 'zoomarts'); echo ' '; echo the_category(', '); ?></li>
	<?php if ( isset($zoomarts_options['post-comments-num']) && $zoomarts_options['post-comments-num'] == '1' ) : ?>
		<li><?php comments_popup_link(__('0 Comments', 'zoomarts'), __('1 Comment', 'zoomarts'), __('% Comments', 'zoomarts')); ?></li>
	<?php endif; ?>
</ul>