<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Za_Twitter' ) ) {

class Za_Twitter {

	var $cache_duration_hour = 2; // cache duration in hour (can be decimal e.g : 1.5)

	public function __construct() {

		// Require widget script
		include_once dirname( __FILE__ ) . '/twitter/za-twitter-widget.php';
		
		// shortcode
		add_shortcode( 'za_tweets_slider', array( $this, 'shortcode') );

	}


	/**
	 * Display an error
	 */
	public function twitter_error( $username, $list = false ) {

		$error_message = sprintf( __( 'Our Twitter feed is currently unavailable but you can visit our official twitter page  <a href="%1s" target="_blank">%2s</a>.', 'zoomarts' ), "http://twitter.com/$username", "@$username"  );
			
		if ( $list ) {

			$output = "<ul class=\"za-tweet-list\"><li>$error_message</li></ul>";

		} else {

			$output = "<div class=\"za-bigtweet-content\"><span class=\"za-tweet-text\" style=\"font-size:14px\">$error_message</span></div>";

		}

		return $output;

	}

	/**
	 * Get the Twitter feed 
	 */
	public function get_twitter_feed( $username ) {

		$trans_key = 'za_twitter_'.$username;
		// 
		$url = "http://twitter.wpwolf.com/username/$username";
		$cache_duration = ceil( $this->cache_duration_hour*3600 );
		if ( $cache_duration < 3600 )
			$cache_duration = 3600;

		if ( false === ( $cached_data = get_transient( $trans_key ) ) ) {

			if ( function_exists( 'curl_init') ) {
				$c = curl_init( $url);
				curl_setopt( $c, CURLOPT_RETURNTRANSFER, true );
				curl_setopt( $c, CURLOPT_HEADER, 0 );
				curl_setopt( $c, CURLOPT_TIMEOUT, 10 );
				$data = curl_exec( $c );
				curl_close( $c );
			} else {
				$data = file_get_contents( $url );
			}
			
			if ( $data ) {
				set_transient( $trans_key, $data, $cache_duration ); 
			}
		} else {

			$data = $cached_data;
		}
			
		return  json_decode( $data );
	} 
  
	/**
	 * Display tweets as list or single tweet 
	 */
	public function twitter( $username, $count = 3, $list = true,  $type, $arrows_nav, $arrows_nav_style, $dots_nav, $dots_nav_style, $animation_in, $animation_out, $font_family, $text_transform, $font_size, $line_height, $letter_spacing, $color ) {
		
		$tweet = '';
		$slider_class = $tweet_class = $tweet_style = $tweet_time_style = '';
		$data = $this->get_twitter_feed( $username );

		if ( $data && is_array( $data ) ) {
			/* Display as list */
			if ( $type == 'slider' ) {
				if ( isset( $data[0] ) ) {
					if ( $arrows_nav == "true" ) {
						$slider_class .= " arrows-".$arrows_nav_style." arrows-nav-".$arrows_nav;
					}
					if ( $dots_nav == 'true' ) {
						$slider_class .= " dots-".$dots_nav_style." dots-nav-".$dots_nav;
					}
					if ( $font_family != '' ) {
						$tweet_class = $font_family;
					}
					if ( $text_transform != '' ) {
						$tweet_style .= 'text-transform:'.$text_transform.'; ';
					}
					if ( $font_size != '' ) {
						$tweet_style .= 'font-size:'.$font_size.'; ';
					}
					if ( $line_height != '' ) {
						$tweet_style .= 'line-height:'.$line_height.'; ';
					}
					if ( $letter_spacing != '' ) {
						$tweet_style .= 'letter-spacing:'.$letter_spacing.'; ';
					}
					if ( $color != '' ) {
						$tweet_style .= 'color:'.$color.'; ';
						$tweet_time_style = 'style="color:'.$color.';"';
					}
					$tweet .= "<div class=\"tweets-slider custom-carousel ".$slider_class."\" data-carousel-nav=\"".$arrows_nav."\" data-carousel-pag=\"".$dots_nav."\" data-animate-in=\"".$animation_in."\" data-animate-out=\"".$animation_out."\" data-auto-height=\"true\" data-items-desktop=\"1\" data-items-tablet=\"1\" data-items-mobile=\"1\">"; 
					for ( $i=0; $i<$count; $i++ ) {
						if ( isset( $data[$i] ) ) {
							$content = $data[$i]->text;
							$created = $data[$i]->created_at;
							$id = $data[$i]->id_str;
							$tweet_link = "https://twitter.com/$username/statuses/$id";
							
							$tweet .= "<div class=\"tweet-item\">";
							$tweet .= "<div class=\"tweet-text ".$tweet_class."\" style=\"".$tweet_style."\">". $this->twitter_to_link( $content )."</div>";
							$tweet .= "<div class=\"tweet-time\" ".$tweet_time_style."><a href=\"$tweet_link\" target=\"_blank\">".__( 'about', 'zoomarts' )." ". $this->twitter_time_ago( $created )."</a> <span>|</span> <a href=\"http://twitter.com/$username/\" target=\"_blank\">@$username</a></div>";
							$tweet .= "</div>";
						}
					}
					$tweet .= "</div>";
				} else {
					$tweet = $this->twitter_error( $username, $list );
				}

			/* Display as single tweet */
			} else {
				if ( isset( $data[0] ) ) {
					$tweet .= "<ul class=\"za-tweet-list\">"; 
					for ( $i=0; $i<$count; $i++ ) {
						if ( isset( $data[$i] ) ) {
							$content = $data[$i]->text;
							$created = $data[$i]->created_at;
							$id = $data[$i]->id_str;
							$tweet_link = "https://twitter.com/$username/statuses/$id";
							
							$tweet .= "<li>";
							$tweet .= "<span class=\"za-tweet-time\"><a href=\"$tweet_link\" target=\"_blank\">".__( 'about', 'zoomarts' )." ". $this->twitter_time_ago( $created )."</a></span>";    
							$tweet .= "<span class=\"za-tweet-text\">".$this->twitter_to_link( $content )."</span>";
							$tweet .= "</li>";
						}
					}
					$tweet .= "</ul>";
				} else {
					$tweet = $this->twitter_error( $username, $list );
				}
			}

		} else {
			$tweet = $this->twitter_error( $username, $list );
		}
		
		return $tweet;
	}

	/**
	 * Find url strings, tags and username strings and make them as link
	 */
	public function  twitter_to_link( $text ) {
		
		// Match URLs
		$text = preg_replace( '/(^|[^=\"\/])\b((?:\w+:\/\/|www\.)[^\s<]+)((?:\W+|\b)(?:[\s<]|$))/m', '<a href="$0" target="_blank">$0</a>', $text);

		// Match @name
		$text = preg_replace( '/(@)([a-zA-ZÀ-ú0-9\_]+)/', '<a href="https://twitter.com/$2" target="_blank">@$2</a>', $text);

		// Match #hashtag
		$text = preg_replace( '/(#)([a-zA-ZÀ-ú0-9\_]+)/', '<a href="https://twitter.com/search/?q=$2" target="_blank">#$2</a>', $text);
		
		return $text;
	}

	/**
	 * Convert the twitter date to "X ago" type
	 */        
	public function twitter_time_ago( $date ) {
		return esc_html(
			sprintf(
				__( '%s ago', 'zoomarts' ), human_time_diff( strtotime( $date ), current_time( 'timestamp' ) )
			)
		);
	} 

	/**
	 * Shortcode
	 */ 
	public function shortcode( $atts, $content ) {

		extract( shortcode_atts( array(
			'username' => '',
			'type' => 'slider',
			'count' => 3,
			'arrows_nav' => '',
			'arrows_nav_style' => '',
			'dots_nav' => '',
			'dots_nav_style' => '',
			'animation_in' => '',
			'animation_out' => '',
			'font_family' => '',
			'text_transform' => '',
			'font_size' => '',
			'line_height' => '',
			'letter_spacing' => '',
			'color' => ''
		), $atts ) );

		$list = true;

		return $this->twitter( $username, $count, $list, $type, $arrows_nav, $arrows_nav_style, $dots_nav, $dots_nav_style, $animation_in, $animation_out, $font_family, $text_transform, $font_size, $line_height, $letter_spacing, $color );	
	}

} // end class

global $za_twitter;
$za_twitter = new Za_Twitter;

// Widget function
function za_twitter_widget( $username, $count ) {
	global $za_twitter;
	echo ($za_twitter->twitter( $username, $count , $list = true , $type, $arrows_nav, $arrows_nav_style, $dots_nav, $dots_nav_style, $animation_in, $animation_out, $font_family, $text_transform, $font_size, $line_height, $letter_spacing, $color ));
}

} // end class check