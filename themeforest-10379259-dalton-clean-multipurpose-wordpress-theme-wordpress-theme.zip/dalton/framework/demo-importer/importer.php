<?php
/*-----------------------------------------------------------------------------------*/
/* Theme Importer
/*-----------------------------------------------------------------------------------*/

defined('ABSPATH') or die('You cannot access!');

add_action('admin_init','za_demo_installer_init');
function za_demo_installer_init() {

	wp_register_script( 'za-importer-js', get_template_directory_uri() . '/framework/demo-importer/assets/importer.js', array('jquery'), '1.0', 1);  
	wp_localize_script( 'za-importer-js', 'wp_ajax', array('url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'ajax_nonce' )));
	wp_enqueue_script( 'za-importer-js' );

	wp_register_style('za-importer-css', get_template_directory_uri() . '/framework/demo-importer/assets/importer.css');
	wp_enqueue_style('za-importer-css');	

	add_action( 'wp_ajax_demo_installer', 'demo_installer' );
	add_action('wp_ajax_nopriv_demo_installer', '_demo_installer');
}


/*-----------------------------------------------------------------------------------*/
/* Demo Installer
/*-----------------------------------------------------------------------------------*/
function demo_installer(){
	
	global $add_post, $tt_post;
	
	$response 				= null;
	$error    				= null;
	$message  				= false;
	$tt_post  				= 0;
	$add_post 				= 0;
	$data_xml 				= $_POST['xml'];
	$importer 				= $_POST['importer'];
	$type     				= $_POST['type'];
	$data_xml 				= get_template_directory() . '/framework/demo-importer/data/' . $data_xml;
	$args     				= array('file' => $data_xml,'map_user_id' => 1);

	if ($importer == 'posts_import') {
		import_post_type($data_xml);
	} else if ($importer == 'update_options') {
		set_wp_options();
	} else if ($importer == 'menus_import') {
		add_menu($data_xml);
	} else if ($importer == 'widgets_import') {
		import_widgets($data_xml);
	} else if ($importer == 'options_import') {;
		import_theme_options($data_xml);
	} else if ($importer == 'revs_import') {
		import_revsliders();
	}

	$message = false;
	
	$response = array(
		"tt_post"  => $tt_post,
		"add_post" => $add_post,
		"message"  => $message,
		"error"    => $error
	);
	wp_send_json_success($response);
}


/*-----------------------------------------------------------------------------------*/
/* Set Reading Options and Menus
/*-----------------------------------------------------------------------------------*/
function set_wp_options(){
	global $wpdb;

	//Set Wordpress options	after pages added
	$page = get_page_by_title('Home - Business 1','','page');
	$blog = get_page_by_title('Blog Standard - Right Sidebar','','page');
	$shop = get_page_by_title('Shop','','page');
	$cart = get_page_by_title('Cart','','page');
	$checkout = get_page_by_title('Checkout','','page');
	$homeShop = get_page_by_title('Home - Shop','','page');

	update_option( 'page_on_front', $page->ID );
	update_option( 'show_on_front', 'page' );
	update_option( 'page_for_posts', $blog->ID );

	// Set WooCommerce pages
	if ( class_exists( 'WooCommerce' ) ) {
		update_option( 'woocommerce_shop_page_id', $shop->ID );
		update_option( 'woocommerce_cart_page_id', $cart->ID );
		update_option( 'woocommerce_checkout_page_id', $checkout->ID );
	} else {
		wp_delete_post( $shop->ID, true);
		wp_delete_post( $cart->ID, true);
		wp_delete_post( $checkout->ID, true);
		wp_delete_post( $homeShop->ID, true);
	}


	// Set imported menus to registered theme locations
	$locations = get_theme_mod( 'nav_menu_locations' );
	$menus = wp_get_nav_menus();
	
	if($menus) {
		foreach($menus as $menu) {
			if( $menu->name == 'Header Menu' ) {
				$locations['main_menu'] = $menu->term_id;
			} else if( $menu->name == 'Responsive Menu' ) {
				$locations['responsive_menu'] = $menu->term_id;
			}
		}
	}

	set_theme_mod( 'nav_menu_locations', $locations );


	// Replace Images Url For Meta
	$current_site_url = get_site_url();
	$dalton_url = 'http://zoomarts.works/dummy-data/dalton';
	$my_all_posts = get_posts( array( 'posts_per_page' => '-1', 'post_type' => array( 'post', 'page', 'portfolio', 'product' ) ) );

    foreach( $my_all_posts as $post ) { 
    	$postId = $post->ID;
        $page_header_old_src = get_post_meta( $postId, 'za_page_header_background_image', true );
        $post_lightbox_image_old_src = get_post_meta( $postId, 'za_lightbox_image', true );
        $project_lightbox_image_old_src = get_post_meta( $postId, 'za_project_lightbox_image', true );

        if ( !empty($page_header_old_src) ) {
        	$page_header_new_src = str_replace($dalton_url, $current_site_url, $page_header_old_src );
        	update_post_meta( $postId, 'za_page_header_background_image', $page_header_new_src );
        }

        if ( !empty($post_lightbox_image_old_src) ) {
        	$post_lightbox_image_new_src = str_replace($dalton_url, $current_site_url, $post_lightbox_image_old_src );
        	update_post_meta( $postId, 'za_lightbox_image', $post_lightbox_image_new_src );
        }

        if ( !empty($project_lightbox_image_old_src) ) {
        	$project_lightbox_image_new_src = str_replace($dalton_url, $current_site_url, $project_lightbox_image_old_src );
        	update_post_meta( $postId, 'za_project_lightbox_image', $project_lightbox_image_new_src );
        }
    }


    // Replace Images URL For Content
    $query = "UPDATE $wpdb->posts ";
    $query .= "SET post_content = ";
    $query .= "REPLACE(post_content, \"$dalton_url\", \"$current_site_url\") ";
    $wpdb->get_results($query);


    // Update WooCommerce Images  Dimensions
    $catalog = array(
		'width' => '300',	
		'height'	=> '360',	
		'crop'	=> 1 
	);
	$single = array(
		'width' => '580',	
		'height'	=> '620',	
		'crop'	=> 1 
	);
	$thumbnail = array(
		'width' => '130',	
		'height'	=> '130',	
		'crop'	=> 1 
	);

	if ( class_exists( 'WooCommerce' ) ) {
		update_option( 'shop_catalog_image_size', $catalog );
		update_option( 'shop_single_image_size', $single );
		update_option( 'shop_thumbnail_image_size', $thumbnail );
	}
    
}


/*-----------------------------------------------------------------------------------*/
/* Import Theme Options
/*-----------------------------------------------------------------------------------*/
function import_theme_options($file) {
	global $add_post, $tt_post;
	if (!file_exists($file)) {
		wp_die();
	}
	$file_contents = file_get_contents( $file );
	$options = json_decode($file_contents, true);
	$redux = ReduxFrameworkInstances::get_instance('zoomarts_options');
	$redux->set_options($options);
	$tt_post = $add_post = count($options);
}


/*-----------------------------------------------------------------------------------*/
/* Import Revolution Sliders
/*-----------------------------------------------------------------------------------*/
function import_revsliders() {
	global $wpdb;

	// Import Revslider
	if( class_exists('UniteFunctionsRev') ) { 
	    $rev_directory = get_template_directory() . '/framework/demo-importer/data/revsliders/';

	    foreach( glob( $rev_directory . '*.zip' ) as $filename ) {
	        $filename = basename($filename);
	        $rev_files[] = get_template_directory() . '/framework/demo-importer/data/revsliders/' . $filename ;
	    }

	    if(class_exists("ZipArchive")){
	        foreach( $rev_files as $rev_file ) {

	                $filepath = $rev_file;

	                $zip = new ZipArchive;
	                $importZip = $zip->open($filepath, ZIPARCHIVE::CREATE);

	                if($importZip === true){ //true or integer. If integer, its not a correct zip file

	                    //check if files all exist in zip
	                    $slider_export = $zip->getStream('slider_export.txt');
	                    $custom_animations = $zip->getStream('custom_animations.txt');
	                    $dynamic_captions = $zip->getStream('dynamic-captions.css');
	                    $static_captions = $zip->getStream('static-captions.css');

	                    $content = '';
	                    $animations = '';
	                    $dynamic = '';
	                    $static = '';

	                    while (!feof($slider_export)) $content .= fread($slider_export, 1024);
	                    if($custom_animations){ while (!feof($custom_animations)) $animations .= fread($custom_animations, 1024); }
	                    if($dynamic_captions){ while (!feof($dynamic_captions)) $dynamic .= fread($dynamic_captions, 1024); }
	                    if($static_captions){ while (!feof($static_captions)) $static .= fread($static_captions, 1024); }

	                    fclose($slider_export);
	                    if($custom_animations){ fclose($custom_animations); }
	                    if($dynamic_captions){ fclose($dynamic_captions); }
	                    if($static_captions){ fclose($static_captions); }

	                    //check for images!

	                }else{ //check if fallback
	                    //get content array
	                    $content = @file_get_contents($filepath);
	                }

	                if($importZip === true){ //we have a zip
	                    $db = new UniteDBRev();

	                    //update/insert custom animations
	                    $animations = @unserialize($animations);
	                    if(!empty($animations)){
	                        foreach($animations as $key => $animation){ //$animation['id'], $animation['handle'], $animation['params']
	                            $exist = $db->fetch(GlobalsRevSlider::$table_layer_anims, "handle = '".$animation['handle']."'");
	                            if(!empty($exist)){ //update the animation, get the ID
	                                if($updateAnim == "true"){ //overwrite animation if exists
	                                    $arrUpdate = array();
	                                    $arrUpdate['params'] = stripslashes(json_encode(str_replace("'", '"', $animation['params'])));
	                                    $db->update(GlobalsRevSlider::$table_layer_anims, $arrUpdate, array('handle' => $animation['handle']));

	                                    $id = $exist['0']['id'];
	                                }else{ //insert with new handle
	                                    $arrInsert = array();
	                                    $arrInsert["handle"] = 'copy_'.$animation['handle'];
	                                    $arrInsert["params"] = stripslashes(json_encode(str_replace("'", '"', $animation['params'])));

	                                    $id = $db->insert(GlobalsRevSlider::$table_layer_anims, $arrInsert);
	                                }
	                            }else{ //insert the animation, get the ID
	                                $arrInsert = array();
	                                $arrInsert["handle"] = $animation['handle'];
	                                $arrInsert["params"] = stripslashes(json_encode(str_replace("'", '"', $animation['params'])));

	                                $id = $db->insert(GlobalsRevSlider::$table_layer_anims, $arrInsert);
	                            }

	                            //and set the current customin-oldID and customout-oldID in slider params to new ID from $id
	                            $content = str_replace(array('customin-'.$animation['id'], 'customout-'.$animation['id']), array('customin-'.$id, 'customout-'.$id), $content);
	                        }
	                        //dmp(__("animations imported!",REVSLIDER_TEXTDOMAIN));
	                    }

	                    //overwrite/append static-captions.css
	                    if(!empty($static)){
	                        if($updateStatic == "true"){ //overwrite file
	                            RevOperations::updateStaticCss($static);
	                        }else{ //append
	                            $static_cur = RevOperations::getStaticCss();
	                            $static = $static_cur."\n".$static;
	                            RevOperations::updateStaticCss($static);
	                        }
	                    }
	                    //overwrite/create dynamic-captions.css
	                    //parse css to classes
	                    $dynamicCss = UniteCssParserRev::parseCssToArray($dynamic);

	                    if(is_array($dynamicCss) && $dynamicCss !== false && count($dynamicCss) > 0){
	                        foreach($dynamicCss as $class => $styles){
	                            //check if static style or dynamic style
	                            $class = trim($class);

	                            if((strpos($class, ':hover') === false && strpos($class, ':') !== false) || //before, after
	                                strpos($class," ") !== false || // .tp-caption.imageclass img or .tp-caption .imageclass or .tp-caption.imageclass .img
	                                strpos($class,".tp-caption") === false || // everything that is not tp-caption
	                                (strpos($class,".") === false || strpos($class,"#") !== false) || // no class -> #ID or img
	                                strpos($class,">") !== false){ //.tp-caption>.imageclass or .tp-caption.imageclass>img or .tp-caption.imageclass .img
	                                continue;
	                            }

	                            //is a dynamic style
	                            if(strpos($class, ':hover') !== false){
	                                $class = trim(str_replace(':hover', '', $class));
	                                $arrInsert = array();
	                                $arrInsert["hover"] = json_encode($styles);
	                                $arrInsert["settings"] = json_encode(array('hover' => 'true'));
	                            }else{
	                                $arrInsert = array();
	                                $arrInsert["params"] = json_encode($styles);
	                            }
	                            //check if class exists
	                            $result = $db->fetch(GlobalsRevSlider::$table_css, "handle = '".$class."'");

	                            if(!empty($result)){ //update
	                                $db->update(GlobalsRevSlider::$table_css, $arrInsert, array('handle' => $class));
	                            }else{ //insert
	                                $arrInsert["handle"] = $class;
	                                $db->insert(GlobalsRevSlider::$table_css, $arrInsert);
	                            }
	                        }
	                        //dmp(__("dynamic styles imported!",REVSLIDER_TEXTDOMAIN));
	                    }
	                }

	                $content = preg_replace('!s:(\d+):"(.*?)";!e', "'s:'.strlen('$2').':\"$2\";'", $content); //clear errors in string

	                $arrSlider = @unserialize($content);

	                //update slider params
	                $sliderParams = $arrSlider["params"];

	                if(isset($sliderParams["background_image"]))
	                    $sliderParams["background_image"] = UniteFunctionsWPRev::getImageUrlFromPath($sliderParams["background_image"]);

	                $json_params = json_encode($sliderParams);

	                //new slider
	                $arrInsert = array();
	                $arrInsert["params"] = $json_params;
	                $arrInsert["title"] = UniteFunctionsRev::getVal($sliderParams, "title","Slider1");
	                $arrInsert["alias"] = UniteFunctionsRev::getVal($sliderParams, "alias","slider1");
	                $sliderID = $wpdb->insert(GlobalsRevSlider::$table_sliders,$arrInsert);
	                $sliderID = $wpdb->insert_id;

	                //-------- Slides Handle -----------

	                //create all slides
	                $arrSlides = $arrSlider["slides"];

	                $alreadyImported = array();

	                foreach($arrSlides as $slide){

	                    $params = $slide["params"];
	                    $layers = $slide["layers"];

	                    //convert params images:
	                    if(isset($params["image"])){
	                        //import if exists in zip folder
	                        if(trim($params["image"]) !== ''){
	                            if($importZip === true){ //we have a zip, check if exists
	                                $image = $zip->getStream('images/'.$params["image"]);
	                                if(!$image){
	                                    echo ($params["image"]).' not found!<br>';
	                                }else{
	                                    if(!isset($alreadyImported['zip://'.$filepath."#".'images/'.$params["image"]])){
	                                        $importImage = UniteFunctionsWPRev::import_media('zip://'.$filepath."#".'images/'.$params["image"], $sliderParams["alias"].'/');

	                                        if($importImage !== false){
	                                            $alreadyImported['zip://'.$filepath."#".'images/'.$params["image"]] = $importImage['path'];

	                                            $params["image"] = $importImage['path'];
	                                        }
	                                    }else{
	                                        $params["image"] = $alreadyImported['zip://'.$filepath."#".'images/'.$params["image"]];
	                                    }
	                                }
	                            }
	                        }
	                        $params["image"] = UniteFunctionsWPRev::getImageUrlFromPath($params["image"]);
	                    }

	                    //convert layers images:
	                    foreach($layers as $key=>$layer){
	                        if(isset($layer["image_url"])){
	                            //import if exists in zip folder
	                            if(trim($layer["image_url"]) !== ''){
	                                if($importZip === true){ //we have a zip, check if exists
	                                    $image_url = $zip->getStream('images/'.$layer["image_url"]);
	                                    if(!$image_url){
	                                        echo ( $layer["image_url"] ).' not found!<br>';
	                                    }else{
	                                        if(!isset($alreadyImported['zip://'.$filepath."#".'images/'.$layer["image_url"]])){
	                                            $importImage = UniteFunctionsWPRev::import_media('zip://'.$filepath."#".'images/'.$layer["image_url"], $sliderParams["alias"].'/');

	                                            if($importImage !== false){
	                                                $alreadyImported['zip://'.$filepath."#".'images/'.$layer["image_url"]] = $importImage['path'];

	                                                $layer["image_url"] = $importImage['path'];
	                                            }
	                                        }else{
	                                            $layer["image_url"] = $alreadyImported['zip://'.$filepath."#".'images/'.$layer["image_url"]];
	                                        }
	                                    }
	                                }
	                            }
	                            $layer["image_url"] = UniteFunctionsWPRev::getImageUrlFromPath($layer["image_url"]);
	                            $layers[$key] = $layer;
	                        }
	                    }

	                    //create new slide
	                    $arrCreate = array();
	                    $arrCreate["slider_id"] = $sliderID;
	                    $arrCreate["slide_order"] = $slide["slide_order"];
	                    $arrCreate["layers"] = json_encode($layers);
	                    $arrCreate["params"] = json_encode($params);

	                    $wpdb->insert(GlobalsRevSlider::$table_slides,$arrCreate);
	                //}
	            }
	        }
	    }
	}

}


/*-----------------------------------------------------------------------------------*/
/* Import Post, Page, Porfolio, Products, Menus and Contact Forms
/*-----------------------------------------------------------------------------------*/
function import_post_type($data_xml){

	if ( ! class_exists( 'WP_Importer' ) ) {
		$wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
		include $wp_importer;
	}

	if ( ! class_exists('WP_Import') ) {
		$wp_import = get_template_directory() . '/framework/demo-importer/wordpress-importer.php';
		include $wp_import;
	}

	$importer = new WP_Import();
	$theme_xml = $data_xml;
	$importer->fetch_attachments = true;
	ob_start();
	$importer->import($theme_xml);
	ob_end_clean();

}


/*-----------------------------------------------------------------------------------*/
/* Import Widgets
/*-----------------------------------------------------------------------------------*/
function import_widgets($data) {
	
	if (!file_exists($data)) {
    	wp_die();
    }
	
	global $wp_registered_sidebars, $wp_registered_widget_controls, $add_post, $tt_post;;
	
	$widget_controls   = $wp_registered_widget_controls;
    $available_widgets = array();
	$widget_instances  = array();
	$results           = array();
	
	$data = file_get_contents($data);
    $data = json_decode($data);
    
    foreach ($widget_controls as $widget) {
    	if (!empty($widget['id_base']) && ! isset( $available_widgets[$widget['id_base']])) {
    		$available_widgets[$widget['id_base']]['id_base'] = $widget['id_base'];
    		$available_widgets[$widget['id_base']]['name'] = $widget['name'];
    	}
    }
	
    foreach ($available_widgets as $widget_data) {
    	$widget_instances[$widget_data['id_base']] = get_option('widget_' . $widget_data['id_base']);
    }

    foreach ($data as $sidebar_id => $widgets) {
    	if ('wp_inactive_widgets' == $sidebar_id) {
    		continue;
    	}
    	if (isset($wp_registered_sidebars[$sidebar_id])) {
    		$sidebar_available = true;
    		$use_sidebar_id = $sidebar_id;
    		$sidebar_message_type = 'success';
    		$sidebar_message = '';
    	} else {
    		$sidebar_available = false;
    		$use_sidebar_id = 'wp_inactive_widgets';
    		$sidebar_message_type = 'error';
    		$sidebar_message = __('Sidebar does not exist in theme (using Inactive)', 'zoomarts');
    	}

    	$results[$sidebar_id]['name'] = ! empty( $wp_registered_sidebars[$sidebar_id]['name']) ? $wp_registered_sidebars[$sidebar_id]['name'] : $sidebar_id;
    	$results[$sidebar_id]['message_type'] = $sidebar_message_type;
    	$results[$sidebar_id]['message'] = $sidebar_message;
    	$results[$sidebar_id]['widgets'] = array();

    	foreach ($widgets as $widget_instance_id => $widget) {
    		$fail = false;
    		$id_base = preg_replace( '/-[0-9]+$/', '', $widget_instance_id );
    		$instance_id_number = str_replace( $id_base . '-', '', $widget_instance_id );

    		if (!$fail && !isset( $available_widgets[$id_base])) {
    			$fail = true;
    			$widget_message_type = 'error';
    			$widget_message = __('Site does not support widget', 'zoomarts');
    		}

    		$widget = apply_filters('themeone_theme_import_widget_settings', $widget);

    		if (!$fail && isset($widget_instances[$id_base])) {
    			$sidebars_widgets = get_option( 'sidebars_widgets' );
    			$sidebar_widgets = isset( $sidebars_widgets[$use_sidebar_id] ) ? $sidebars_widgets[$use_sidebar_id] : array();
    			$single_widget_instances = ! empty( $widget_instances[$id_base] ) ? $widget_instances[$id_base] : array();
    			foreach ( $single_widget_instances as $check_id => $check_widget ) {
    				if ( in_array( "$id_base-$check_id", $sidebar_widgets ) && (array) $widget == $check_widget ) {
    					$fail = true;
    					$widget_message_type = 'warning';
    					$widget_message = __('Widget already exists', 'zoomarts');
    					break;
    				}
    			}
    		}

    		if (!$fail) {
    			$single_widget_instances = get_option( 'widget_' . $id_base );
    			$single_widget_instances = ! empty( $single_widget_instances ) ? $single_widget_instances : array( '_multiwidget' => 1 );
    			$single_widget_instances[] = (array) $widget;
    			end($single_widget_instances);
    			$new_instance_id_number = key( $single_widget_instances );
    			
				if ( '0' === strval( $new_instance_id_number ) ) {
    				$new_instance_id_number = 1;
    				$single_widget_instances[$new_instance_id_number] = $single_widget_instances[0];
    				unset( $single_widget_instances[0] );
    			}

    			if ( isset( $single_widget_instances['_multiwidget'] ) ) {
    				$multiwidget = $single_widget_instances['_multiwidget'];
    				unset( $single_widget_instances['_multiwidget'] );
    				$single_widget_instances['_multiwidget'] = $multiwidget;
    			}

    			update_option( 'widget_' . $id_base, $single_widget_instances );
    			$sidebars_widgets = get_option( 'sidebars_widgets' );
    			$new_instance_id = $id_base . '-' . $new_instance_id_number;
    			$sidebars_widgets[$use_sidebar_id][] = $new_instance_id;
    			update_option( 'sidebars_widgets', $sidebars_widgets );

    			if ( $sidebar_available ) {
    				$widget_message_type = 'success';
    				$widget_message = __('Imported', 'zoomarts');
    			} else {
    				$widget_message_type = 'warning';
    				$widget_message = __('Imported to Inactive', 'zoomarts');
    			}
				$add_post++;
    		}
    		$results[$sidebar_id]['widgets'][$widget_instance_id]['name'] = isset( $available_widgets[$id_base]['name'] ) ? $available_widgets[$id_base]['name'] : $id_base;
    		$results[$sidebar_id]['widgets'][$widget_instance_id]['title'] = $widget->title ? $widget->title : __( 'No Title', 'zoomarts');
    		$results[$sidebar_id]['widgets'][$widget_instance_id]['message_type'] = $widget_message_type;
    		$results[$sidebar_id]['widgets'][$widget_instance_id]['message'] = $widget_message;
			$tt_post++;
    	}
    }
}

?>