(function($) {
    "use strict";

if (typeof jQuery != 'undefined') {
	
	jQuery('document').ready(function($){
		$('.button_data_import').on('click', function() {
				
			var startTime;
			var endTime;
			var $bar_dom;
			var errori = false;
			var warning = false;
			
			var data;
			var ttpost = null;
			var addpost = null;
			var messages = null;
			var errors = null;
			var progress = 0;
			
			var action = 'demo_installer';
			var type = 'POST';
			var demo_config = [
				{ 'importer':'options_import',		'type':'theme options',			'xml':'theme-options.json' },
				{ 'importer':'posts_import',		'type':'contact forms',			'xml':'contact-forms.xml.gz' },
				{ 'importer':'widgets_import',		'type':'widgets',				'xml':'widgets.json' },
				{ 'importer':'posts_import',		'type':'posts',					'xml':'posts.xml.gz' },
				{ 'importer':'posts_import',		'type':'portfolio items',		'xml':'portfolio.xml.gz' },
				{ 'importer':'posts_import',		'type':'products',				'xml':'products.xml.gz' },
				{ 'importer':'posts_import',		'type':'pages',					'xml':'pages.xml.gz' },
				{ 'importer':'posts_import',		'type':'menus',					'xml':'menus.xml.gz' },
				{ 'importer':'revs_import',			'type':'revolution sliders',	'xml':'' },
				{ 'importer':'update_options',		'type':'set options',			'xml':'' },
				{ 'importer':'posts_import',		'type':'pages images (1)',		'xml':'pages-images-1.xml.gz' },
				{ 'importer':'posts_import',		'type':'pages images (2)',		'xml':'pages-images-2.xml.gz' },
				{ 'importer':'posts_import',		'type':'pages images (3)',		'xml':'pages-images-3.xml.gz' },
				{ 'importer':'posts_import',		'type':'pages images (4)',		'xml':'pages-images-4.xml.gz' },
			];
			
			var loop_length = demo_config.length;
			var loop_count = 0;
			
			$('.importer-holder').html('');
			$('.importer-result div').css('opacity',0);
			var response;
			demo_importer();
			function demo_importer() {
				$.ajax({
					type: type,
					url: ajaxurl,
					dataType: "JSON",
					data: {  
						action: action,
						ajax_nonce: wp_ajax.nonce,
						importer: demo_config[loop_count].importer,
						type: demo_config[loop_count].type,
						post_type: demo_config[loop_count].post_type,
						xml: demo_config[loop_count].xml
					},
					beforeSend : function(){
						startTime = new Date().getTime();
						append_bar()
					},
					success : function(data) {
						progress_bar(data);
						auto_loop();
					},
					error : function(jqXHR, textStatus, errorThrown) {
						errori = true;
						$('.importer-holder .import-'+ loop_count +' span').text('Sorry, an error occurred!').css({"color":"#e74c3c"})
						$('.importer-holder .import-'+ loop_count +' .progress-importer').css({"-webkit-transform":"translateX(100%)"})
							.css({"-o-transform":"translateX(100%)"})
							.css({"-ms-transform":"translateX(100%)"})
							.css({"transform":"translateX(100%)"})
							.addClass('error-bar');
						auto_loop();
					}
				});
			}
			
			function auto_loop() {
				$('.importer-holder .import-'+ loop_count +' span').removeClass('loading-animation');
				loop_count++;
				if (loop_count < loop_length) {
					demo_importer();
				} else {
					if (errori === false) {
						$('.importer-result-success').css('opacity',1);
					} else if (errori === true) {
						$('.importer-result-fail').css('opacity',1);
					}
					if (warning === true) {
						$('.importer-result-warning').css('opacity',1);
					}
				}
			}
			
			function append_bar() {
				$bar_dom = $('<div class="importer-bar import-'+ loop_count +'">'+
							 	'<div class="importer-bar-inner">'+
							 		'<div class="progress-importer"></div>'+
							 	'</div>'+
							 	'<span>Loading - '+  demo_config[loop_count].type +'</span>'+
							 '</div>');
				$('.importer-holder').append($bar_dom);
				$('.importer-holder .import-'+ loop_count).css('opacity',1);
				$('.importer-holder .import-'+ loop_count +' span').addClass('loading-animation');
			}
			
			function progress_bar(data) {
				if (typeof data == 'undefined' || !data) {
					data = {};
					data['success'] = true;
					data['data'] = {'tt_post': 1, 'add_post': 1, 'message': 'correctly imported but an error occured!', 'error': true};
				}
				ttpost   = (typeof data['data'].tt_post != 'undefined') ? data['data'].tt_post : '1';
				addpost  = (typeof data['data'].add_post != 'undefined' || typeof data['data'].add_post == 0) ? data['data'].add_post : '1';
				messages = (typeof data['data'].message != 'undefined') ? data['data'].message : '';
				errors   = (typeof data['data'].error != 'undefined') ? data['data'].error : '';
				progress = ttpost/addpost*100;
				endTime  = (new Date().getTime() - startTime)/1000;
				if (endTime >= 30 && addpost != 0 && messages == false || errors == true) {
					warning = true;
					$('.importer-holder .import-'+ loop_count +' span').css({"color":"#e74c3c"});
				}

				if (addpost != 0 && messages == false) {
					progress = addpost/ttpost*100;
					$('.importer-holder .import-'+ loop_count +' span').text(addpost +'/'+ ttpost +' '+ demo_config[loop_count].type +' - Loaded!');
				} else if (addpost == 0 && messages == false) {
					progress = 100;
					$('.importer-holder .import-'+ loop_count +' span').text(demo_config[loop_count].type +' - Imported!');
				} else if (messages != false) {
					progress = 100;
					$('.importer-holder .import-'+ loop_count +' span').text(demo_config[loop_count].post_type +' '+ messages);
					$('.importer-holder .import-'+ loop_count +' .progress-importer').addClass('message-error');
				}
				$('.importer-holder .import-'+ loop_count +' .progress-importer')
							.css({"-webkit-transform":"translateX("+progress+"%)"})
							.css({"-o-transform":"translateX("+progress+"%)"})
							.css({"-ms-transform":"translateX("+progress+"%)"})
							.css({"transform":"translateX("+progress+"%)"});
			}		
	
		});
	});	
}
})(jQuery);