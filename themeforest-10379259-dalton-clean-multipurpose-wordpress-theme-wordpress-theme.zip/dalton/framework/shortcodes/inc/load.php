<?php

/*

class Shortcodes_Ultimate {

	public static function register() {
		$prefix = za_cmpt();
		foreach ( ( array ) Za_Data::shortcodes() as $id => $data ) {
			if ( isset( $data['function'] ) && is_callable( $data['function'] ) ) $func = $data['function'];
			elseif ( is_callable( array( 'Za_Shortcodes', $id ) ) ) $func = array( 'Za_Shortcodes', $id );
			elseif ( is_callable( array( 'Za_Shortcodes', 'za_' . $id ) ) ) $func = array( 'Za_Shortcodes', 'za_' . $id );
			else continue;
			add_shortcode( $prefix . $id, $func );
		}
		add_shortcode( $prefix . 'media', array( 'Za_Shortcodes', 'media' ) );
	}

	public static function timestamp() {
		if ( !get_option( 'za_installed' ) ) update_option( 'za_installed', time() );
	}

	public static function skins_dir() {
		$upload_dir = wp_upload_dir();
		$path = trailingslashit( path_join( $upload_dir['basedir'], 'shortcodes' ) );
		if ( !file_exists( $path ) ) mkdir( $path, 0755 );
	}

}

function shortcodes_ultimate() {
	return true;
}

new Shortcodes_Ultimate;

*/

?>