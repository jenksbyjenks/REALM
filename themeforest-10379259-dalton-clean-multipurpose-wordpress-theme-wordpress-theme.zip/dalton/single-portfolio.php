<?php

	get_header();
	za_page_header();

	global $post;
	global $zoomarts_options;

	if ( get_post_meta( $post->ID, 'za_project_layout', true ) == 'mini-centered'  ) {
		$cols_class = 'col-md-10 col-md-offset-1';
	} elseif ( get_post_meta( $post->ID, 'za_project_layout', true ) == 'page-builder'  ) {
		$cols_class = '';
	} else {
		$cols_class = 'col-md-12';
	}

	if ( get_post_meta( $post->ID, 'za_project_layout', true ) == 'page-builder'  ) {
		$container_class = 'project-page-builder';
	} else {
		$container_class = 'container';
	}

	$project_nav_cat = ($zoomarts_options['project-next-prev-category'] == '1') ? true : false;

?>

    <div class="project-head clearfix">
    	<div class="container">
			<?php

				if( isset($zoomarts_options['project-next-prev']) && $zoomarts_options['project-next-prev'] == '1' ) {
					be_next_post_link('%link','<i class="icon-chevron-thin-left"></i><span>%title</span>',$project_nav_cat, null,'project-type');
				}

				if( isset($zoomarts_options['check_back_to_portfolio']) && $zoomarts_options['check_back_to_portfolio'] == '1' ) {
					if( isset($zoomarts_options['portfolio_custom_link']) && $zoomarts_options['portfolio_custom_link'] != '' ) {
						echo '<a title="'.__( 'Back to Portfolio', 'zoomarts' ).'" href="'.$zoomarts_options['portfolio_custom_link'].'"><i class="icon-grid6"></i></a>';
					} else {
						echo '<a title="'.__( 'Back to Portfolio', 'zoomarts' ).'" href="'.( get_portfolio_page(get_the_ID()) ).'"><i class="icon-grid6"></i></a>';
					}
				}

				if( isset($zoomarts_options['project-next-prev']) && $zoomarts_options['project-next-prev'] == '1' ) {
					be_previous_post_link('%link','<span>%title</span><i class="icon-chevron-thin-right"></i>',$project_nav_cat, null, 'project-type');
				}

			?>
		</div>
	</div>

	<!-- Start Main Container -->
    <div id="main-content" class="main-content <?php echo esc_attr( $container_class ); ?>">
    
		<?php if ( get_post_meta( $post->ID, 'za_project_layout', true ) !== 'page-builder'  ) { echo '<div class="row">'; } ?>

			<!-- Start Single Post Container -->
			<div class="project-wrap <?php echo esc_attr( $cols_class ); ?>">
					
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					
					<!-- Start Post Item -->
					<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">

						<?php get_template_part( 'includes/content-portfolio' ); ?>

					</div>
					<!-- End Post Item -->
					
				<?php endwhile; endif; ?>

			<?php if ( get_post_meta( $post->ID, 'za_project_layout', true ) !== 'page-builder'  ) { echo '</div>'; } ?>
			<!-- End Single Post Container -->
			
		</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>