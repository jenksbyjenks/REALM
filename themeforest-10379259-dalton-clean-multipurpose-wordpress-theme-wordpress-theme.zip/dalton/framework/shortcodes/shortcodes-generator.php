<?php

// Define plugin constants
define( 'Za_ENABLE_CACHE', false);

// Includes
//require_once 'inc/load.php';
require_once 'inc/assets.php';
require_once 'inc/tools.php';
require_once 'inc/data.php';
require_once 'inc/generator-views.php';
require_once 'inc/generator.php';
require_once 'inc/widget.php';
