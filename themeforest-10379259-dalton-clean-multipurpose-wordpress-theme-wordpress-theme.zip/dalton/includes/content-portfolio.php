<?php

	global $post;
	global $zoomarts_options;
	$dots_nav = 'false';
	$arrows_nav = 'false';
	$project_cats = '';
	$sliderAnimateIn = 'fadeInDown';
	$sliderAnimateOut = 'fadeOutDown';
	$terms = get_the_terms($post->id,"project-type");
	$extra_content = get_post_meta( $post->ID, 'za_project_extra_content', true );
	$thumb_content = get_post_meta( $post->ID, 'za_project_thumb_content', true );
	$project_layout = get_post_meta( $post->ID, 'za_project_layout', true );

	if ( $zoomarts_options['project-slider-nav'] == 'arrows' ) {
		$arrows_nav = 'true';
	} elseif ( $zoomarts_options['project-slider-nav'] == 'dots' )  {
		$dots_nav = 'true';
	} elseif ( $zoomarts_options['project-slider-nav'] == 'both' )  {
		$dots_nav = 'true';
		$arrows_nav = 'true';
	}

	if ( !empty($terms) ){
		foreach ( $terms as $term ) {
			$project_cats .= strtolower($term->slug) . ' ';
		}
	}

	if ( isset($zoomarts_options['project-slider-animation-in']) && $zoomarts_options['project-slider-animation-in'] != 'false' ) {
		$sliderAnimateIn = $zoomarts_options['project-slider-animation-in'];
	}

	if ( isset($zoomarts_options['project-slider-animation-out']) && $zoomarts_options['project-slider-animation-out'] != 'false' ) {
		$sliderAnimateOut = $zoomarts_options['project-slider-animation-out'];
	}

?>

<?php if ( $project_layout == 'mini-centered'  ) : ?>

	<div class="project-thumb <?php echo $project_layout; ?>">
		<?php if ( !empty($thumb_content) ) :
			foreach ( (array) $thumb_content as $key => $entry ) {
				$gallery_images = $gallery_image = $video_embed_code = '';
				if ( !empty( $entry['project_thumb_video'] ) ) :
					$video_embed_code = wp_oembed_get( esc_url( $entry['project_thumb_video'] ) );
					echo '<div class="fitvid">'.$video_embed_code.'</div>';
				elseif ( !empty( $entry['project_thumb_slider'] ) ) :
					$gallery_images = $entry['project_thumb_slider'];
					if ( isset($zoomarts_options['project-slider-style']) && $zoomarts_options['project-slider-style'] == 'thumbs-slider' ) {
						echo '<div class="project-slider custom-slider swiper-container gallery-top">';
						echo '<div class="swiper-wrapper">';
							foreach ( $gallery_images as $gallery_image ) {
								echo "<div class='swiper-slide'>";
								if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
									echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
									echo '<i class="icon-expand4"></i>';
									echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
									echo '</a>';
								else :
									echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
								endif;
								echo "</div>";
							}
						echo '</div>';
							echo '<div class="swiper-controls">';
							if ( $dots_nav == 'true' ) {
								echo '<div class="swiper-pagination"></div>';
							}
							if ( $arrows_nav =='true' ) {
								echo '<div class="swiper-button-next"><i class="icon-arrow-right4"></i></div><div class="swiper-button-prev"><i class="icon-arrow-left4"></i></div>';
							}
							echo '</div>';
						echo '</div>';
						echo '<div class="mini-slider swiper-container gallery-thumbs"><div class="swiper-wrapper">';
							foreach ( $gallery_images as $gallery_images ) {
								echo "<div class='swiper-slide'><div style='background-image:url(".esc_html( $gallery_images ).")'></div></div>";
							}
						echo '</div></div>';
					} else {
						echo '<div class="project-slider custom-slider custom-carousel" data-auto-height="true" data-lazy-load="true"  data-carousel-nav="'.$arrows_nav.'" data-carousel-pag="'.$dots_nav.'" data-items-desktop="1" data-items-tablet="1" data-items-mobile="1" data-animate-out="'.$sliderAnimateOut.'" data-animate-in="'.$sliderAnimateIn.'">';
							foreach ( $gallery_images as $gallery_image ) {
								echo "<div class='item'>";
								if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
									echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
									echo '<i class="icon-expand4"></i>';
									echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
									echo '</a>';
								else :
									echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
								endif;
								echo "</div>";
							}
						echo '</div>';
					}
				elseif ( !empty( $entry['project_thumb_image'] ) ) :
					if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
						echo '<a href="'.esc_html( $entry['project_thumb_image'] ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
						echo '<i class="icon-expand4"></i>';
						echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
						echo '</a>';
					else :
						echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
					endif;
				endif;
			}
		else :
			if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
				$attachment = wp_get_attachment_url( get_post_thumbnail_id( $post->ID) );
				echo '<a href="'.esc_html( $attachment ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
				echo '<i class="icon-expand4"></i>';
				echo '<img src="'.esc_html( $attachment ).'" alt="'.esc_attr( get_the_title() ).'" />';
				echo '</a>';
			else :
				the_post_thumbnail();
			endif;
		endif; ?>
	</div>

	<div class="project-content">
		<div class="project-text">
			<h2 class="project-title"><?php the_title(); ?></h2>
			<?php if ( isset($zoomarts_options['project-cats-list']) && $zoomarts_options['project-cats-list'] == '1' ) : ?>
				<div class="project-cats">
				<?php if ( !empty($terms) ){
					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						if ( is_wp_error( $term_link ) ) {
							continue;
						}
						echo '<a href="'.$term_link.'">'. $term->name .'</a> ';
					}
				} ?>
				</div>
			<?php endif; ?>
			<div class="content-area"><?php the_content(); ?></div>
			<?php if ( $zoomarts_options['check-project-sharing'] == '1') : ?><div class="social-share"><?php za_social_share($post->ID); ?></div><?php endif; ?>
		</div>
	</div>

<?php elseif ( $project_layout == 'wide-centered'  ) : ?>

	<div class="project-thumb <?php echo $project_layout; ?>">
		<?php if ( !empty($thumb_content) ) :
			foreach ( (array) $thumb_content as $key => $entry ) {
				$gallery_images = $gallery_image = $video_embed_code = '';
				if ( !empty( $entry['project_thumb_video'] ) ) :
					$video_embed_code = wp_oembed_get( esc_url( $entry['project_thumb_video'] ) );
					echo '<div class="fitvid">'.$video_embed_code.'</div>';
				elseif ( !empty( $entry['project_thumb_slider'] ) ) :
					$gallery_images = $entry['project_thumb_slider'];
					if ( isset($zoomarts_options['project-slider-style']) && $zoomarts_options['project-slider-style'] == 'thumbs-slider' ) {
						echo '<div class="project-slider custom-slider swiper-container gallery-top">';
						echo '<div class="swiper-wrapper">';
							foreach ( $gallery_images as $gallery_image ) {
								echo "<div class='swiper-slide'>";
								if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
									echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
									echo '<i class="icon-expand4"></i>';
									echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
									echo '</a>';
								else :
									echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
								endif;
								echo "</div>";
							}
						echo '</div>';
							echo '<div class="swiper-controls">';
							if ( $dots_nav == 'true' ) {
								echo '<div class="swiper-pagination"></div>';
							}
							if ( $arrows_nav =='true' ) {
								echo '<div class="swiper-button-next"><i class="icon-arrow-right4"></i></div><div class="swiper-button-prev"><i class="icon-arrow-left4"></i></div>';
							}
							echo '</div>';
						echo '</div>';
						echo '<div class="mini-slider swiper-container gallery-thumbs"><div class="swiper-wrapper">';
							foreach ( $gallery_images as $gallery_images ) {
								echo "<div class='swiper-slide'><div style='background-image:url(".esc_html( $gallery_images ).")'></div></div>";
							}
						echo '</div></div>';
					} else {
						echo '<div class="project-slider custom-slider custom-carousel" data-auto-height="true" data-lazy-load="true"  data-carousel-nav="'.$arrows_nav.'" data-carousel-pag="'.$dots_nav.'" data-items-desktop="1" data-items-tablet="1" data-items-mobile="1" data-animate-out="'.$sliderAnimateOut.'" data-animate-in="'.$sliderAnimateIn.'">';
							foreach ( $gallery_images as $gallery_image ) {
								echo "<div class='item'>";
								if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
									echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
									echo '<i class="icon-expand4"></i>';
									echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
									echo '</a>';
								else :
									echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
								endif;
								echo "</div>";
							}
						echo '</div>';
					}
				elseif ( !empty( $entry['project_thumb_image'] ) ) :
					if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
						echo '<a href="'.esc_html( $entry['project_thumb_image'] ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
						echo '<i class="icon-expand4"></i>';
						echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
						echo '</a>';
					else :
						echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
					endif;
				endif;
			}
		else :
			if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
				$attachment = wp_get_attachment_url( get_post_thumbnail_id( $post->ID) );
				echo '<a href="'.esc_html( $attachment ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
				echo '<i class="icon-expand4"></i>';
				echo '<img src="'.esc_html( $attachment ).'" alt="'.esc_attr( get_the_title() ).'" />';
				echo '</a>';
			else :
				the_post_thumbnail();
			endif;
		endif; ?>
	</div>

	<div class="project-content">
		<div class="project-text">
			<h2 class="project-title"><?php the_title(); ?></h2>
			<?php if ( isset($zoomarts_options['project-cats-list']) && $zoomarts_options['project-cats-list'] == '1' ) : ?>
				<div class="project-cats">
				<?php if ( !empty($terms) ){
					foreach ( $terms as $term ) {
						$term_link = get_term_link( $term );
						if ( is_wp_error( $term_link ) ) {
							continue;
						}
						echo '<a href="'.$term_link.'">'. $term->name .'</a> ';
					}
				} ?>
				</div>
			<?php endif; ?>
			<div class="content-area"><?php the_content(); ?></div>
			<?php if ( $zoomarts_options['check-project-sharing'] == '1') : ?><div class="social-share"><?php za_social_share($post->ID); ?></div><?php endif; ?>
		</div>
	</div>

<?php elseif ( $project_layout == 'page-builder'  ) : ?>

	<?php the_content(); ?>

<?php elseif ( $project_layout == 'two-columns-left'  ) : ?>

	<div class="project-content row">

		<div class="col-md-4">
			<div class="project-info sticky">
				<div class="project-text">
					<h2 class="project-title"><?php the_title(); ?></h2>
					<?php if ( isset($zoomarts_options['project-cats-list']) && $zoomarts_options['project-cats-list'] == '1' ) : ?>
						<div class="project-cats">
						<?php if ( !empty($terms) ){
							foreach ( $terms as $term ) {
								$term_link = get_term_link( $term );
								if ( is_wp_error( $term_link ) ) {
									continue;
								}
								echo '<a href="'.$term_link.'">'. $term->name .'</a> ';
							}
						} ?>
						</div>
					<?php endif; ?>
					<div class="content-area"><?php the_content(); ?></div>
					<?php if ( $zoomarts_options['check-project-sharing'] == '1') : ?>
						<div class="social-share"><?php za_social_share($post->ID); ?></div>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<div class="col-md-8">
			<div class="project-thumb <?php echo $project_layout; ?>">
				<?php if ( !empty($thumb_content) ) :
					foreach ( (array) $thumb_content as $key => $entry ) {
						$gallery_images = $gallery_image = $video_embed_code = '';
						if ( !empty( $entry['project_thumb_video'] ) ) :
							$video_embed_code = wp_oembed_get( esc_url( $entry['project_thumb_video'] ) );
							echo '<div class="fitvid">'.$video_embed_code.'</div>';
						elseif ( !empty( $entry['project_thumb_slider'] ) ) :
					$gallery_images = $entry['project_thumb_slider'];
					if ( isset($zoomarts_options['project-slider-style']) && $zoomarts_options['project-slider-style'] == 'thumbs-slider' ) {
						echo '<div class="project-slider custom-slider swiper-container gallery-top">';
						echo '<div class="swiper-wrapper">';
							foreach ( $gallery_images as $gallery_image ) {
								echo "<div class='swiper-slide'>";
								if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
									echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
									echo '<i class="icon-expand4"></i>';
									echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
									echo '</a>';
								else :
									echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
								endif;
								echo "</div>";
							}
						echo '</div>';
							echo '<div class="swiper-controls">';
							if ( $dots_nav == 'true' ) {
								echo '<div class="swiper-pagination"></div>';
							}
							if ( $arrows_nav =='true' ) {
								echo '<div class="swiper-button-next"><i class="icon-arrow-right4"></i></div><div class="swiper-button-prev"><i class="icon-arrow-left4"></i></div>';
							}
							echo '</div>';
						echo '</div>';
						echo '<div class="mini-slider swiper-container gallery-thumbs"><div class="swiper-wrapper">';
							foreach ( $gallery_images as $gallery_images ) {
								echo "<div class='swiper-slide'><div style='background-image:url(".esc_html( $gallery_images ).")'></div></div>";
							}
						echo '</div></div>';
					} else {
						echo '<div class="project-slider custom-slider custom-carousel" data-auto-height="true" data-lazy-load="true"  data-carousel-nav="'.$arrows_nav.'" data-carousel-pag="'.$dots_nav.'" data-items-desktop="1" data-items-tablet="1" data-items-mobile="1" data-animate-out="'.$sliderAnimateOut.'" data-animate-in="'.$sliderAnimateIn.'">';
							foreach ( $gallery_images as $gallery_image ) {
								echo "<div class='item'>";
								if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
									echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
									echo '<i class="icon-expand4"></i>';
									echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
									echo '</a>';
								else :
									echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
								endif;
								echo "</div>";
							}
						echo '</div>';
					}
						elseif ( !empty( $entry['project_thumb_image'] ) ) :
						    if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
								echo '<a href="'.esc_html( $entry['project_thumb_image'] ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
								echo '<i class="icon-expand4"></i>';
								echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
								echo '</a>';
							else :
								echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
							endif;
						endif;
					}
				else :
					if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
						$attachment = wp_get_attachment_url( get_post_thumbnail_id( $post->ID) );
						echo '<a href="'.esc_html( $attachment ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
						echo '<i class="icon-expand4"></i>';
						echo '<img src="'.esc_html( $attachment ).'" alt="'.esc_attr( get_the_title() ).'" />';
						echo '</a>';
					else :
						the_post_thumbnail();
					endif;
				endif; ?>
			</div>
		</div>

	</div>

<?php else : ?>

	<div class="project-content row">

		<div class="col-md-8">
			<div class="project-thumb <?php echo $project_layout; ?>">
				<?php if ( !empty($thumb_content) ) :
					foreach ( (array) $thumb_content as $key => $entry ) {
						$gallery_images = $gallery_image = $video_embed_code = '';
						if ( !empty( $entry['project_thumb_video'] ) ) :
							$video_embed_code = wp_oembed_get( esc_url( $entry['project_thumb_video'] ) );
							echo '<div class="fitvid">'.$video_embed_code.'</div>';
						elseif ( !empty( $entry['project_thumb_slider'] ) ) :
							$gallery_images = $entry['project_thumb_slider'];
							if ( isset($zoomarts_options['project-slider-style']) && $zoomarts_options['project-slider-style'] == 'thumbs-slider' ) {
								echo '<div class="project-slider custom-slider swiper-container gallery-top">';
								echo '<div class="swiper-wrapper">';
									foreach ( $gallery_images as $gallery_image ) {
										echo "<div class='swiper-slide'>";
										if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
											echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
											echo '<i class="icon-expand4"></i>';
											echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
											echo '</a>';
										else :
											echo '<img src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
										endif;
										echo "</div>";
									}
								echo '</div>';
									echo '<div class="swiper-controls">';
									if ( $dots_nav == 'true' ) {
										echo '<div class="swiper-pagination"></div>';
									}
									if ( $arrows_nav =='true' ) {
										echo '<div class="swiper-button-next"><i class="icon-arrow-right4"></i></div><div class="swiper-button-prev"><i class="icon-arrow-left4"></i></div>';
									}
									echo '</div>';
								echo '</div>';
								echo '<div class="mini-slider swiper-container gallery-thumbs"><div class="swiper-wrapper">';
									foreach ( $gallery_images as $gallery_images ) {
										echo "<div class='swiper-slide'><div style='background-image:url(".esc_html( $gallery_images ).")'></div></div>";
									}
								echo '</div></div>';
							} else {
								echo '<div class="project-slider custom-slider custom-carousel" data-auto-height="true" data-lazy-load="true"  data-carousel-nav="'.$arrows_nav.'" data-carousel-pag="'.$dots_nav.'" data-items-desktop="1" data-items-tablet="1" data-items-mobile="1" data-animate-out="'.$sliderAnimateOut.'" data-animate-in="'.$sliderAnimateIn.'">';
									foreach ( $gallery_images as $gallery_image ) {
										echo "<div class='item'>";
										if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
											echo '<a href="'.esc_html( $gallery_image ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
											echo '<i class="icon-expand4"></i>';
											echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
											echo '</a>';
										else :
											echo '<img class="owl-lazy" data-src="'.esc_html( $gallery_image ).'" alt="'.esc_attr( get_the_title() ).'" />';
										endif;
										echo "</div>";
									}
								echo '</div>';
							}
						elseif ( !empty( $entry['project_thumb_image'] ) ) :
						    if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
								echo '<a href="'.esc_html( $entry['project_thumb_image'] ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
								echo '<i class="icon-expand4"></i>';
								echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
								echo '</a>';
							else :
								echo '<img alt="'.esc_attr( get_the_title() ).'" src="'.esc_html( $entry['project_thumb_image'] ).'" />';
							endif;
						endif;
					}
				else :
					if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
						$attachment = wp_get_attachment_url( get_post_thumbnail_id( $post->ID) );
						echo '<a href="'.esc_html( $attachment ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
						echo '<i class="icon-expand4"></i>';
						echo '<img src="'.esc_html( $attachment ).'" alt="'.esc_attr( get_the_title() ).'" />';
						echo '</a>';
					else :
						if ( isset($zoomarts_options['project-lighbox-image']) && $zoomarts_options['project-lighbox-image'] == '1' ) :
							$attachment = wp_get_attachment_url( get_post_thumbnail_id( $post->ID) );
							echo '<a href="'.esc_html( $attachment ).'" class="open-image lightbox" data-rel="lightcase:myCollection:slideshow-'.$post->ID.'">';
							echo '<i class="icon-expand4"></i>';
							echo '<img src="'.esc_html( $attachment ).'" alt="'.esc_attr( get_the_title() ).'" />';
							echo '</a>';
						else :
							the_post_thumbnail();
						endif;
					endif;
				endif; ?>
			</div>
		</div>

		<div class="col-md-4">
			<div class="project-info sticky">
				<div class="project-text">
					<h2 class="project-title"><?php the_title(); ?></h2>
					<?php if ( isset($zoomarts_options['project-cats-list']) && $zoomarts_options['project-cats-list'] == '1' ) : ?>
						<div class="project-cats">
						<?php if ( !empty($terms) ){
							foreach ( $terms as $term ) {
								$term_link = get_term_link( $term );
								if ( is_wp_error( $term_link ) ) {
									continue;
								}
								echo '<a href="'.$term_link.'">'. $term->name .'</a> ';
							}
						} ?>
						</div>
					<?php endif; ?>
					<div class="content-area"><?php the_content(); ?></div>
					<?php if ( $zoomarts_options['check-project-sharing'] == '1') : ?>
						<div class="social-share"><?php za_social_share($post->ID); ?></div>
					<?php endif; ?>
				</div>
			</div>
		</div>

	</div>

<?php endif; ?>