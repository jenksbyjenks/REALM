<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=1">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-touch-fullscreen" content="yes">
	<meta http-equiv="cleartype" content="on">
	<meta name="HandheldFriendly" content="True">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<title><?php wp_title('|', true, 'right'); ?></title>
	<?php wp_head(); ?>
</head>

<?php global $zoomarts_options; ?>

<body <?php body_class( ); ?>>

	<div class="mobile-nav">
    
    <span class="close-mobile-nav">&times;</span>

    <div class="mobile-menu">
        <?php
            wp_nav_menu( array(
                'theme_location' => 'responsive_menu',
                'container'  => '',
                'container_class' => 'nav-menu',
                'menu_class' => '',
                'menu_id' => '',
            ));
        ?>
    </div>

</div>

	<!-- Start Wrapper -->
	<div class="wrapper <?php echo esc_attr( $zoomarts_options['main-layout-style'] ); ?>">
	
	<?php if ( $zoomarts_options['loader'] == '1' ) : ?>
		<div id="loader" class="style-<?php echo esc_attr( $zoomarts_options['spinner_style'] ); ?>">
			<div class="loader-container">
				<?php if ( isset($zoomarts_options['loader-logo']['url']) && !empty($zoomarts_options['loader-logo']['url']) ) : ?>
					<div class="loader-logo"><img src="<?php echo esc_attr( $zoomarts_options['loader-logo']['url'] ); ?>" alt="<?php get_bloginfo( 'name' ) ?>" /></div>
				<?php endif; ?>
				<div class="spinner">
					<?php if ( $zoomarts_options['spinner_style'] == '3' ) : ?>
						<div class="double-bounce1"></div>
						<div class="double-bounce2"></div>
					<?php elseif ( $zoomarts_options['spinner_style'] == '4' ) : ?>
						<div class="cube1"></div>
						<div class="cube2"></div>
					<?php elseif ( $zoomarts_options['spinner_style'] == '5' ) : ?>
						<div class="dot1"></div>
						<div class="dot2"></div>
					<?php elseif ( $zoomarts_options['spinner_style'] == '6' ) : ?>
						<div class="bounce1"></div>
						<div class="bounce2"></div>
						<div class="bounce3"></div>
					<?php elseif ( $zoomarts_options['spinner_style'] == '7' ) : ?>
						<div class="rect1"></div>
						<div class="rect2"></div>
						<div class="rect3"></div>
						<div class="rect4"></div>
						<div class="rect5"></div>
					<?php elseif ( $zoomarts_options['spinner_style'] == '8' ) : ?>
						<div class="spinner-container container1">
							<div class="circle1"></div>
							<div class="circle2"></div>
							<div class="circle3"></div>
							<div class="circle4"></div>
						</div>
						<div class="spinner-container container2">
							<div class="circle1"></div>
							<div class="circle2"></div>
							<div class="circle3"></div>
							<div class="circle4"></div>
						</div>
						<div class="spinner-container container3">
							<div class="circle1"></div>
							<div class="circle2"></div>
							<div class="circle3"></div>
							<div class="circle4"></div>
						</div>
					<?php elseif ( $zoomarts_options['spinner_style'] == '9' ) : ?>
						<div class="spinner-container"></div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<div id="ajaxing-content">
	<?php endif; ?>
	
	<?php za_display_header(); ?>