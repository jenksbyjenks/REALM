<?php
/**
 * Class for managing plugin data
 */
class Za_Data {

	/**
	 * Constructor
	 */
	function __construct() {}

	/**
	 * Shortcode groups
	 */
	public static function groups() {
		return apply_filters( 'su/data/groups', array(
				'all'     => __( 'All', 'zoomarts' ),
				'content' => __( 'Content', 'zoomarts' ),
				'box'     => __( 'Box', 'zoomarts' ),
				'media'   => __( 'Media', 'zoomarts' ),
				'other'   => __( 'Other', 'zoomarts' )
			) );
	}

	/**
	 * Shortcodes
	 */
	public static function shortcodes( $shortcode = false ) {

		$shortcodes = apply_filters( 'su/data/shortcodes', array(
				// row
				'row' => array(
					'name' => __( 'Row', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'box content',
					'atts' => array(
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'zoomarts' ),
							'desc' => __( 'Extra CSS class', 'zoomarts' )
						)
					),
					'content' => "[%prefix_column size=\"col-md-4\"]Content[/%prefix_column]\n[%prefix_column size=\"col-md-4\"]Content[/%prefix_column]\n[%prefix_column size=\"col-md-4\"]Content[/%prefix_column]",
					'desc' => __( 'Row for flexible columns', 'zoomarts' ),
					'icon' => 'columns'
				),
				// column
				'column' => array(
					'name' => __( 'Column', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'box content',
					'atts' => array(
						'size' => array(
							'type' => 'select',
							'values' => array(
								'col-md-12' => __( 'Full width', 'zoomarts' ),
								'col-md-6' => __( 'One half', 'zoomarts' ),
								'col-md-4' => __( 'One third', 'zoomarts' ),
								'col-md-8' => __( 'Two third', 'zoomarts' ),
								'col-md-3' => __( 'One fourth', 'zoomarts' ),
								'col-md-9' => __( 'Three fourth', 'zoomarts' ),
								'col-md-2' => __( 'One sixth', 'zoomarts' ),
								'col-md-10' => __( 'Five sixth', 'zoomarts' )
							),
							'default' => 'col-md-6',
							'name' => __( 'Size', 'zoomarts' ),
							'desc' => __( 'Select column width. This width will be calculated depend page width', 'zoomarts' )
						),
						'center' => array(
							'type' => 'bool',
							'default' => 'no',
							'name' => __( 'Centered', 'zoomarts' ),
							'desc' => __( 'Is this column centered on the page', 'zoomarts' )
						),
						'class' => array(
							'default' => '',
							'name' => __( 'Class', 'zoomarts' ),
							'desc' => __( 'Extra CSS class', 'zoomarts' )
						)
					),
					'content' => __( 'Column content', 'zoomarts' ),
					'desc' => __( 'Flexible and responsive columns', 'zoomarts' ),
					'note' => __( 'Did you know that you need to wrap columns with [row] shortcode?', 'zoomarts' ),
					'example' => 'columns',
					'icon' => 'columns'
				),
				// heading
				'custom_font' => array(
					'name' => __( 'Custom Font', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'content',
					'content' => __( 'You Text Here', 'zoomarts' ),
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'values' => array(
								'' => '',
                                'style-1' => __( 'Style 1', 'zoomarts' ),
								'style-2' => __( 'Style 2', 'zoomarts' ),
							),
							'default' => '',
							'name' => __( 'Custom Style', 'zoomarts' ),
							'desc' => __( 'Choose style for this text', 'zoomarts' )
						),
						'borders_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Borders Color', 'zoomarts' ),
						),
						'font_family' => array(
							'type' => 'select',
							'values' => array(
								'' => __( 'Default', 'zoomarts' ),
								'custom-font-1' => __( 'Custom Font 1', 'zoomarts' ),
								'custom-font-2' => __( 'Custom Font 2', 'zoomarts' ),
								'custom-font-3' => __( 'Custom Font 3', 'zoomarts' ),
								'custom-font-4' => __( 'Custom Font 4', 'zoomarts' ),
								'custom-font-5' => __( 'Custom Font 5', 'zoomarts' ),
								'custom-font-6' => __( 'Custom Font 6', 'zoomarts' ),
								'custom-font-7' => __( 'Custom Font 7', 'zoomarts' ),
								'custom-font-8' => __( 'Custom Font 8', 'zoomarts' ),
								'custom-font-9' => __( 'Custom Font 9', 'zoomarts' ),
								'custom-font-10' => __( 'Custom Font 10', 'zoomarts' ),
								'custom-font-11' => __( 'Custom Font 11', 'zoomarts' ),
								'custom-font-12' => __( 'Custom Font 12', 'zoomarts' ),
								'custom-font-13' => __( 'Custom Font 13', 'zoomarts' ),
								'custom-font-14' => __( 'Custom Font 14', 'zoomarts' ),
								'custom-font-15' => __( 'Custom Font 15', 'zoomarts' ),
							),
							'default' => '',
							'name' => __( 'Custom Font Family?', 'zoomarts' ),
							'desc' => __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' )
						),
						'element_tag' => array(
							'type' => 'select',
							'values' => array(
								'h1' => 'h1',
								'h2' => 'h2',
								'h3' => 'h3',
								'h4' => 'h4',
								'h5' => 'h5',
								'h6' => 'h6',
								'p' => 'p',
								'div' => 'div',
								'span' => 'span',
							),
							'default' => 'h4',
							'name' => __( 'Element Tag', 'zoomarts' ),
							'desc' => __( 'Select element tag', 'zoomarts' )
						),
						'text_align' => array(
							'type' => 'select',
							'values' => array(
								'left' => __( 'Left', 'zoomarts' ),
								'right' => __( 'Right', 'zoomarts' ),
								'center' => __( 'Center', 'zoomarts' ),
								'justify' => __( 'Justify', 'zoomarts' ),
							),
							'default' => '',
							'name' => __( 'Text Align?', 'zoomarts' ),
							'desc' => __( 'Select text alignment', 'zoomarts' )
						),
						'font_size' => array(
							'default' => '',
							'name' => __( 'Font Size', 'zoomarts' ),
							'desc' => __( 'Enter font size. (pixels)', 'zoomarts' )
						),
						'line_height' => array(
							'default' => '',
							'name' => __( 'Line Height', 'zoomarts' ),
							'desc' => __( 'Enter line height. (pixels)', 'zoomarts' )
						),
						'letter_spacing' => array(
							'default' => '',
							'name' => __( 'Letter Spacing', 'zoomarts' ),
							'desc' => __( 'Enter letter spacing. (pixels)', 'zoomarts' )
						),
						'text_transform' => array(
							'type' => 'select',
							'values' => array(
								'' => '',
								'lowercase' => __( 'Lowercase', 'zoomarts' ),
								'capitalize' => __( 'Capitalize', 'zoomarts' ),
								'uppercase' => __( 'Uppercase', 'zoomarts' ),
							),
							'default' => 'lowercase',
							'name' => __( 'Text Transform', 'zoomarts' ),
							'desc' => __( 'Select transform for this text', 'zoomarts' )
						),
						'color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Color', 'zoomarts' ),
							'desc' => __( 'Pick color for this text', 'zoomarts' )
						),
					),
					'desc' => __( 'Add Text With Custom Font', 'zoomarts' ),
					'icon' => 'h-square'
				),
				// icon
				'custom_icon' => array(
					'name' => __( 'Icon', 'zoomarts' ),
					'type' => 'single',
					'group' => 'box other',
					'atts' => array(
						'link' => array(
							'default' => '',
							'name' => __( 'Link URL', 'zoomarts' ),
							'desc' => ''
						),
						'link_target' => array(
							'type' => 'select',
							'values' => array(
								'_self' => __( 'Same window', 'zoomarts' ),
								'_blank' => __( 'New window', 'zoomarts' ),
							),
							'default' => '_self',
							'name' => __( 'Open link in', 'zoomarts' ),
							'desc' => ''
						),
						'font_icon' => array(
							'default' => '',
							'name' => __( 'Icon', 'zoomarts' ),
							'desc' => __( 'You can use font icon from our collection or <a href="http://fontawesome.io/icons/">FontAwesome</a>', 'zoomarts' )
						),
						'width_heigh' => array(
							'default' => '',
							'name' => __( 'Icon Width/Heigh', 'zoomarts' ),
							'desc' => __( 'Enter icon block Width/Heigh. (pixels)', 'zoomarts' )
						),
						'font_size' => array(
							'default' => '',
							'name' => __( 'Font Size', 'zoomarts' ),
							'desc' => __( 'Enter icon font size. (pixels)', 'zoomarts' )
						),
						'border_width' => array(
							'default' => '',
							'name' => __( 'Border Width', 'zoomarts' ),
							'desc' => __( 'Enter icon block Width/Heigh. (pixels)', 'zoomarts' )
						),
						'border_radius' => array(
							'default' => '',
							'name' => __( 'Border Radius', 'zoomarts' ),
							'desc' => __( 'Enter icon block border radius. (pixels)', 'zoomarts' )
						),
						'icon_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Icon Color', 'zoomarts' ),
							'desc' => __( 'Pick the color for this icon', 'zoomarts' )
						),
						'bg_color' => array(
							'type' => 'color',
							'default' => 'transparent',
							'name' => __( 'Icon Background Color', 'zoomarts' ),
							'desc' => __( 'Pick the background color for this icon', 'zoomarts' )
						),
						'border_color' => array(
							'type' => 'color',
							'default' => 'transparent',
							'name' => __( 'Icon Border Color', 'zoomarts' ),
							'desc' => __( 'Pick the border color for this icon', 'zoomarts' )
						),
						'color_hover' => array(
							'type' => 'color',
							'default' => 'transparent',
							'name' => __( 'Icon Color (Hover)', 'zoomarts' ),
							'desc' => __( 'Pick the color for this icon', 'zoomarts' )
						),
						'bg_color_hover' => array(
							'type' => 'color',
							'default' => 'transparent',
							'name' => __( 'Icon Background Color (Hover)', 'zoomarts' ),
							'desc' => __( 'Pick the background color for this icon', 'zoomarts' )
						),
						'border_color_hover' => array(
							'type' => 'color',
							'default' => 'transparent',
							'name' => __( 'Icon Border Color (Hover)', 'zoomarts' ),
							'desc' => __( 'Pick the border color for this icon', 'zoomarts' )
						),
					),
					'desc' => __( 'Font Icons', 'zoomarts' ),
					'icon' => 'cube'
				),
				// button
				'button' => array(
					'name' => __( 'Buttons', 'zoomarts' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'caption' => array(
							'default' => 'Nice Button',
							'name' => __( 'Caption', 'zoomarts' ),
							'desc' => __( 'Button caption', 'zoomarts' )
						),
						'icon' => array(
							'default' => '',
							'name' => __( 'Icon', 'zoomarts' ),
							'desc' => __( 'Button icon', 'zoomarts' )
						),
						'animate_icon' => array(
							'type' => 'select',
							'values' => array(
								'false' => __( 'No', 'zoomarts' ),
								'animate_icon' => __( 'Yes', 'zoomarts' ),
							),
							'default' => 'false',
							'name' => __( 'Icon Animation?', 'zoomarts' ),
							'desc' => __( 'Animate icon when mouse hover', 'zoomarts' )
						),
						'link' => array(
							'default' => '',
							'name' => __( 'Link URL', 'zoomarts' ),
							'desc' => __( 'Button Link URL', 'zoomarts' )
						),
						'link_target' => array(
							'type' => 'select',
							'values' => array(
								'_self' => __( 'Same window', 'zoomarts' ),
								'_blank' => __( 'New window', 'zoomarts' ),
							),
							'default' => '',
							'name' => __( 'Open Link In', 'zoomarts' ),
							'desc' => __( 'Open link in same or new window', 'zoomarts' )
						),
						'font_family' => array(
							'type' => 'select',
							'values' => array(
								'' => __( 'Default', 'zoomarts' ),
								'custom-font-1' => __( 'Custom Font 1', 'zoomarts' ),
								'custom-font-2' => __( 'Custom Font 2', 'zoomarts' ),
								'custom-font-3' => __( 'Custom Font 3', 'zoomarts' ),
								'custom-font-4' => __( 'Custom Font 4', 'zoomarts' ),
								'custom-font-5' => __( 'Custom Font 5', 'zoomarts' ),
								'custom-font-6' => __( 'Custom Font 6', 'zoomarts' ),
								'custom-font-7' => __( 'Custom Font 7', 'zoomarts' ),
								'custom-font-8' => __( 'Custom Font 8', 'zoomarts' ),
								'custom-font-9' => __( 'Custom Font 9', 'zoomarts' ),
								'custom-font-10' => __( 'Custom Font 10', 'zoomarts' ),
								'custom-font-11' => __( 'Custom Font 11', 'zoomarts' ),
								'custom-font-12' => __( 'Custom Font 12', 'zoomarts' ),
								'custom-font-13' => __( 'Custom Font 13', 'zoomarts' ),
								'custom-font-14' => __( 'Custom Font 14', 'zoomarts' ),
								'custom-font-15' => __( 'Custom Font 15', 'zoomarts' ),
							),
							'default' => '',
							'name' => __( 'Custom Font Family?', 'zoomarts' ),
							'desc' => __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' )
						),
						'text_transform' => array(
							'type' => 'select',
							'values' => array(
								'' => '',
								'lowercase' => __( 'Lowercase', 'zoomarts' ),
								'capitalize' => __( 'Capitalize', 'zoomarts' ),
								'uppercase' => __( 'Uppercase', 'zoomarts' ),
							),
							'default' => '',
							'name' => __( 'Text Transform', 'zoomarts' ),
							'desc' => __( 'Select transform for this text', 'zoomarts' )
						),
						'font_size' => array(
							'default' => '',
							'name' => __( 'Font Size', 'zoomarts' ),
							'desc' => __( 'Font Size (pixels)', 'zoomarts' )
						),
						'letter_spacing' => array(
							'default' => '',
							'name' => __( 'Letter Spacing', 'zoomarts' ),
							'desc' => __( 'Enter letter spacing. (pixels)', 'zoomarts' )
						),
						'padding_vert' => array(
							'default' => '',
							'name' => __( 'Button Padding Top/Bottom (pixels)', 'zoomarts' ),
						),
						'padding_horz' => array(
							'default' => '',
							'name' => __( 'Button Padding Left/Right (pixels)', 'zoomarts' ),
						),
						'border_width' => array(
							'default' => '',
							'name' => __( 'Border Width (pixels)', 'zoomarts' ),
						),
						'border_radius' => array(
							'default' => '',
							'name' => __( 'Border Radius (pixels)', 'zoomarts' ),
						),
						'text_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Text Color', 'zoomarts' ),
						),
						'bg_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Background Color', 'zoomarts' ),
						),
						'border_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Border Color', 'zoomarts' ),
						),
						'text_color_hover' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Text Color (hover)', 'zoomarts' ),
						),
						'bg_color_hover' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Background Color (hover)', 'zoomarts' ),
						),
						'border_color_hover' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Border Color (hover)', 'zoomarts' ),
						),
					),
					'desc' => __( 'Add a nice button', 'zoomarts' ),
					'icon' => 'star'
				),
				// divider
				'divider' => array(
					'name' => __( 'Divider', 'zoomarts' ),
					'type' => 'single',
					'group' => 'other',
					'atts' => array(
						'style' => array(
							'type' => 'select',
							'default' => 'empty-space',
							'values' => array(
								'empty-space' => __( 'Empty Space', 'zoomarts' ),
								'solid-line' => __( 'Solid Line', 'zoomarts' ),
								'dotted-line' => __( 'Dotted Line', 'zoomarts' ),
								'linear-gradient' => __( 'Gradient Line', 'zoomarts' )
							),
							'name' => __( 'Divider Style', 'zoomarts' ),
						),
						'margin_top' => array(
							'default' => '',
							'name' => __( 'Margin Top (pixels)', 'zoomarts' ),
						),
						'margin_bottom' => array(
							'default' => '',
							'name' => __( 'Margin Bottom (pixels)', 'zoomarts' ),
						),
						'width' => array(
							'default' => '100%',
							'name' => __( 'Divider Width (pixels or percents)', 'zoomarts' ),
						),
						'height' => array(
							'default' => '1px',
							'name' => __( 'Divider Height (pixels)', 'zoomarts' ),
						),
						'position' => array(
							'type' => 'select',
							'default' => 'left',
							'values' => array(
								'left' => __( 'Left', 'zoomarts' ),
								'right' => __( 'Right', 'zoomarts' ),
								'center' => __( 'Center', 'zoomarts' ),
							),
							'name' => __( 'Float', 'zoomarts' ),
						),
						'color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Color', 'zoomarts' ),
						),
					),
					'desc' => __( 'Add Dividers and Spaces', 'zoomarts' ),
					'icon' => 'arrows-v'
				),
				// highlight
				'highlight' => array(
					'name' => __( 'Highlight', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'content other',
					'atts' => array(
						'background' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#ee5555',
							'name' => __( 'Background', 'zoomarts' ),
							'desc' => __( 'Highlighted text background color', 'zoomarts' )
						),
						'color' => array(
							'type' => 'color',
							'values' => array( ),
							'default' => '#ffffff',
							'name' => __( 'Text color', 'zoomarts' ), 'desc' => __( 'Highlighted text color', 'zoomarts' )
						),
					),
					'content' => __( 'Highlighted text', 'zoomarts' ),
					'desc' => __( 'Highlighted text', 'zoomarts' ),
					'icon' => 'pencil'
				),
				// tooltip
				'tooltip' => array(
					'name' => __( 'Tooltip', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'content other',
					'atts' => array(
						'title' => array(
							'default' => '',
							'name' => __( 'Tooltip title', 'zoomarts' ),
							'desc' => __( 'Enter title for tooltip window. Leave this field empty to hide the title', 'zoomarts' )
						),
						'position' => array(
							'type' => 'select',
							'values' => array(
								'top' => __( 'Top', 'zoomarts' ),
								'bottom' => __( 'Bottom', 'zoomarts' ),
								'left' => __( 'Left', 'zoomarts' ),
								'right' => __( 'Right', 'zoomarts' )
							),
							'default' => 'top',
							'name' => __( 'Position', 'zoomarts' ),
							'desc' => __( 'Tooltip position', 'zoomarts' )
						),
					),
					'content' => __( 'Tooltip text', 'zoomarts' ),
					'desc' => __( 'Tooltip effect', 'zoomarts' ),
					'icon' => 'comment-o'
				),
				// quote
				'quote' => array(
					'name' => __( 'Quote', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'content other',
					'atts' => array(
						'float' => array(
							'type' => 'select',
							'values' => array(
								'' => __( 'None', 'zoomarts' ),
								'pullleft' => __( 'Left', 'zoomarts' ),
								'pullright' => __( 'Right', 'zoomarts' )
							),
							'default' => '',
							'name' => __( 'Float', 'zoomarts' ),
							'desc' => __( 'Choose float for this quote', 'zoomarts' )
						),
						'cite' => array(
							'default' => '',
							'name' => __( 'Cite', 'zoomarts' ),
							'desc' => __( 'Quote author name', 'zoomarts' )
						),
						'url' => array(
							'values' => array( ),
							'default' => '',
							'name' => __( 'Cite url', 'zoomarts' ),
							'desc' => __( 'Url of the quote author. Leave empty to disable link', 'zoomarts' )
						),
					),
					'content' => __( 'Quote Content ', 'zoomarts' ),
					'desc' => __( 'Stylish Blockquote', 'zoomarts' ),
					'icon' => 'quote-right'
				),
				// dropcaps
				'dropcap' => array(
					'name' => __( 'Dropcap', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'content other',
					'atts' => array(
						'width_heigh' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 60,
							'step' => 1,
							'default' => 54,
							'name' => __( 'Dropcap Width/Heigh', 'zoomarts' ),
							'desc' => __( 'Choose dropcap block Width/Heigh', 'zoomarts' )
						),
						'font_size' => array(
							'type' => 'slider',
							'min' => 10,
							'max' => 50,
							'step' => 1,
							'default' => 24,
							'name' => __( 'Font Size', 'zoomarts' ),
							'desc' => __( 'Choose dropcap font size', 'zoomarts' )
						),
						'border_width' => array(
							'type' => 'slider',
							'min' => 0,
							'max' => 5,
							'step' => 1,
							'default' => 2,
							'name' => __( 'Border Width', 'zoomarts' ),
							'desc' => __( 'Choose dropcap border width', 'zoomarts' )
						),
						'border_radius' => array(
							'type' => 'slider',
							'min' => 1,
							'max' => 60,
							'step' => 1,
							'default' => 0,
							'name' => __( 'Border Radius', 'zoomarts' ),
							'desc' => __( 'Choose dropcap border radius', 'zoomarts' )
						),
						'font_color' => array(
							'type' => 'color',
							'default' => '#333333',
							'name' => __( 'Font color', 'zoomarts' ),
							'desc' => __( 'Choose dropcap font color', 'zoomarts' )
						),
						'bg_color' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Background color', 'zoomarts' ),
							'desc' => __( 'Choose dropcap background color', 'zoomarts' )
						),
						'border_color' => array(
							'type' => 'color',
							'default' => '#ffffff',
							'name' => __( 'Border color', 'zoomarts' ),
							'desc' => __( 'Choose dropcap Border color', 'zoomarts' )
						),
					),
					'content' => __( 'D', 'zoomarts' ),
					'desc' => __( 'Dropcap', 'zoomarts' ),
					'icon' => 'bold'
				),
				// alerts
				'alert' => array(
					'name' => __( 'Alert', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'box content',
					'atts' => array(
						'alert_type' => array(
							'type' => 'select',
							'values' => array(
								'alert-success' => __( 'Success', 'zoomarts' ),
								'alert-info' => __( 'Info', 'zoomarts' ),
								'alert-warning' => __( 'Warning', 'zoomarts' ),
								'alert-danger' => __( 'Danger', 'zoomarts' ),
							),
							'default' => '',
							'name' => __( 'Alert Type', 'zoomarts' ),
							'desc' => __( 'Select column width. This width will be calculated depend page width', 'zoomarts' )
						),
					),
					'content' => __( 'Alert text', 'zoomarts' ),
					'desc' => __( 'Alert messages', 'zoomarts' ),
					'icon' => 'exclamation-circle'
				),
				// frame
				'frame' => array(
					'name' => __( 'Frame', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'media',
					'atts' => array(
						'float' => array(
							'type' => 'select',
							'values' => array(
								'none' => __( 'none', 'zoomarts' ),
								'left' => __( 'Left', 'zoomarts' ),
								'right' => __( 'Right', 'zoomarts' )
							),
							'default' => 'none',
							'name' => __( 'Float', 'zoomarts' ),
							'desc' => __( 'Frame float', 'zoomarts' )
						),
						'style' => array(
							'type' => 'select',
							'values' => array(
								'border' => __( 'With Border', 'zoomarts' ),
								'shadow' => __( 'With Shadow', 'zoomarts' ),
								'hover' => __( 'Hover Effect', 'zoomarts' )
							),
							'default' => 'border',
							'name' => __( 'Style', 'zoomarts' ),
							'desc' => __( 'Frame style', 'zoomarts' )
						),
					),
					'content' => '<img src="http://lorempixel.com/g/400/200/" />',
					'desc' => __( 'Styled image frame', 'zoomarts' ),
					'icon' => 'picture-o'
				),
				// lightbox
				'lightbox' => array(
					'name' => __( 'Lightbox', 'zoomarts' ),
					'type' => 'wrap',
					'group' => 'media',
					'atts' => array(
						'type' => array(
							'type' => 'select',
							'values' => array(
								'iframe' => __( 'Iframe', 'zoomarts' ),
								'image-video' => __( 'Image or Video', 'zoomarts' ),
							),
							'default' => 'iframe',
							'name' => __( 'Content type', 'zoomarts' ),
							'desc' => __( 'Select type of the lightbox window content', 'zoomarts' )
						),
						'src' => array(
							'default' => '',
							'name' => __( 'Content source', 'zoomarts' ),
							'desc' => __( 'Insert here URL. Use URL for Iframe and Image content types. <br />Example values:<br /><b%value>http://www.youtube.com/watch?v=XXXXXXXXX</b> - YouTube video (iframe)<br /><b%value>http://example.com/wp-content/uploads/image.jpg</b> - uploaded image (image)<br /><b%value>http://example.com/</b> - any web page (iframe)', 'zoomarts' )
						),
						'title' => array(
							'default' => '',
							'name' => __( 'Title', 'zoomarts' ),
							'desc' => __( 'Lightbox Title', 'zoomarts' )
						)
					),
					'content' => __( 'Lightbox Content', 'zoomarts' ),
					'desc' => __( 'Lightbox window with custom content', 'zoomarts' ),
					'icon' => 'external-link'
				),

			) );
		// Return result
		return ( is_string( $shortcode ) ) ? $shortcodes[sanitize_text_field( $shortcode )] : $shortcodes;
	}
}

class Za_Shortcodes_Ultimate_Data extends Za_Data {
	function __construct() {
		parent::__construct();
	}
}
