<?php
	global $zoomarts_options;
?>

<div class="content-area">
	<?php if( !is_singular() ) : ?>
		<?php
		if ( $zoomarts_options['blog-excerpts'] == '1' ) {
			$za_excerpt_length = za_excerpt_length();
			za_excerpt( $za_excerpt_length );
		} else {
			the_content();
		} ?>
	<?php else: ?>
		<?php the_content(); ?>
	<?php endif; ?>
</div>

<?php if( !is_singular() ) : ?>
	<div class="post-border"><span></span></div>
<?php endif; ?>

<?php if( is_singular() ) { za_set_post_views(get_the_ID()); } ?>