<form id="searchform" action="<?php echo home_url(); ?>" method="GET">
	<div>
		<input type="text" name="s" id="s" size="15" placeholder="<?php _e('Enter Keywords...', 'zoomarts') ?>" />
		<i class="icon-search6"><input type="submit" value="" /></i>
	</div>
</form>