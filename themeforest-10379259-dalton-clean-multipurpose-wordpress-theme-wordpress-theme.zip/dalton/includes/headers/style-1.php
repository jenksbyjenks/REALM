<?php if ( $check_custom_header_style == 'default-bg' ) {
    echo '<div class="hidden-header" style="height:'.$hidden_header_height.'px"></div>';
} ?>

<div class="header-outer <?php echo esc_attr( $custom_header_style ).' '.$check_tablet_menu; ?>" data-class-style="<?php echo esc_attr( $custom_header_style ); ?>" data-sticky-topbar="<?php echo esc_attr( $check_sticky_top_bar ); ?>">
        
    <?php if ( $top_bar == '1' ) { za_top_bar(); } ?>

    <!-- Start Header -->
    <div id="header" class="header" data-sticky="<?php echo esc_attr( $zoomarts_options['sticky_header'] ); ?>" data-header-height="<?php echo esc_attr( $zoomarts_options['header-height'] ); ?>" data-sticky-height="<?php echo esc_attr( $zoomarts_options['sticky-header-height'] ); ?>" data-shrink="<?php echo esc_attr( $zoomarts_options['shrink_header'] ); ?>">

        <?php echo ($start_container_tb); ?>
        
            <div class="row">

                <div class="header-leftside">
                    <div id="logo" class="logo">
                        <div class="logo-c">
                            <?php if ( $zoomarts_options['custom-logo-checkbox'] == 1 ) : ?>
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
                                    <?php if ( isset($zoomarts_options['dark-logo']['url']) ) : ?>
                                        <img class="dark-logo no-retina" width="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['width'] ); ?>" height="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['height'] ); ?>" src="<?php echo esc_url( $zoomarts_options['dark-logo']['url'] ); ?>" alt="<?php esc_attr( get_bloginfo( 'name' ) ); ?>" />
                                    <?php endif; ?>
                                    <?php if ( isset($zoomarts_options['dark-logo-retina']['url']) ) : ?>
                                        <img class="dark-logo retina" width="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['width'] ); ?>" height="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['height'] ); ?>" src="<?php echo esc_url( $zoomarts_options['dark-logo-retina']['url'] ); ?>" alt="<?php esc_attr( get_bloginfo( 'name' ) ); ?>" />
                                    <?php endif; ?>
                                    <?php if ( isset($zoomarts_options['light-logo']['url']) ) : ?>
                                        <img class="light-logo no-retina" width="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['width'] ); ?>" height="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['height'] ); ?>" src="<?php echo esc_url( $zoomarts_options['light-logo']['url'] ); ?>" alt="<?php esc_attr( get_bloginfo( 'name' ) ); ?>" />
                                    <?php endif; ?>
                                    <?php if ( isset($zoomarts_options['light-logo-retina']['url']) ) : ?>
                                        <img class="light-logo retina" width="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['width'] ); ?>" height="<?php echo esc_attr( $zoomarts_options['logo-dimensions']['height'] ); ?>" src="<?php echo esc_url( $zoomarts_options['light-logo-retina']['url'] ); ?>" alt="<?php esc_attr( get_bloginfo( 'name' ) ); ?>" />
                                    <?php endif; ?>
                                </a>
                            <?php else : ?>
                                <h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo esc_attr( get_bloginfo( 'name' ) ); ?></a></h1>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="header-rightside">
                    <div class="header-right">
                        <div class="nav-menu">
                            <?php 
                                wp_nav_menu( array(
                                    'theme_location' => 'main_menu',
                                    'container'  => '',
                                    'container_class' => 'nav-menu',
                                    'menu_class' => '',
                                    'menu_id' => '',
                                    'walker' => new za_header_walker_nav_menu()
                                ));
                            ?>
                        </div>
                        <div class="show-menu"><span><i></i></span></div>
                        <?php if ( $zoomarts_options['header-wc-cart'] == '1' ) { ?>
                            <?php do_action('header_checkout'); ?>
                        <?php } if ( $zoomarts_options['header-search'] == '1' ) { ?>
                            <div class="show-search"><span><i class="fa fa-search"></i></span></div>
                        <?php } ?>
                    </div>
                 </div>

            </div>

        <?php echo ($end_container_tb); ?>

        <?php if ( $zoomarts_options['header-search'] == '1' ) : ?>
            <div id="search-box" class="search-box">
                <div class="container">
                    <form role="search" method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <input id="s" type="search" class="field" name="s" value="<?php _e( 'Enter your keywords...', 'zoomarts' ); ?>" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" />
                    </form>
                    <div class="close-btn">&times;</div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ( $zoomarts_options['header-search'] == '1' && $zoomarts_options['ajax-search'] == 'enabled' ) : ?>
            <div class="autocomplete-results results-count-<?php echo (!empty($zoomarts_options['ajax-search-count']) ? $zoomarts_options['ajax-search-count'] : '8'); ?>">
                <div class="container"><div class="search-results"></div></div>
            </div>
        <?php endif; ?>

    </div>
</div>