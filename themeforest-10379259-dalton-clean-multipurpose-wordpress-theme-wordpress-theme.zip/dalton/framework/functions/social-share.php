<?php

if ( !function_exists( 'za_social_share' ) ) {

	function za_social_share( $postid ) {

		global $post;
		global $zoomarts_options;
		$tooltip_class = null;
		$check_project_social = $zoomarts_options['check-project-sharing'];
		$project_sharing_tooltip = $zoomarts_options['project-sharing-tooltip'];
		$project_social = $zoomarts_options['project-sharing']['enabled'];
		$postid = $postid ? $postid : $post->ID;
		$permalink = get_permalink($postid);
		$url = urlencode( $permalink );
		$title = urlencode( esc_attr( the_title_attribute( 'echo=0' ) ) );
		$summary = urlencode( za_get_excerpt( '40' ) );
		$gallery_images = get_post_meta( $postid, 'za_gallery_images', true );
		$img = null;
		$source = home_url();

		if ( has_post_thumbnail() ) {
			$img = wp_get_attachment_url( get_post_thumbnail_id($postid) );
		} elseif ( !empty($gallery_images) ) {
			$img = reset($gallery_images);
		}

		if ( $check_project_social == '0' || !$post || post_password_required() ) {
			return;
		}
		
		if ( $project_sharing_tooltip == '1' ) {
			$tooltip_class = 'za-tooltip';
		}

		?>

		<ul class="social-list">
			<?php foreach ( $project_social as $key => $value ) {
				if ( $key == 'facebook' && $value ) { ?>
					<li class="share-facebook">
						<a href="http://www.facebook.com/share.php?u=<?php echo ($url); ?>" target="_blank" title="<?php _e( 'Share on Facebook', 'zoomarts' ); ?>" rel="nofollow" class="<?php echo ($tooltip_class); ?>" data-placement="bottom" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
							<i class="icon-facebook"></i>
						</a>
					</li>
				<?php }
				if ( $key == 'twitter' && $value ) { ?>
					<li class="share-twitter">
						<a href="http://twitter.com/share?text=<?php echo ($title); ?>&amp;url=<?php echo ($url); ?>" target="_blank" title="<?php _e( 'Share on Twitter', 'zoomarts' ); ?>" rel="nofollow" class="<?php echo ($tooltip_class); ?>" data-placement="bottom" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
							<i class="icon-twitter"></i>
						</a>
					</li>
				<?php }
				if ( $key == 'google-plus' && $value ) { ?>
					<li class="share-googleplus">
						<a title="<?php _e( 'Share on Google+', 'zoomarts' ); ?>" rel="external" href="https://plus.google.com/share?url=<?php echo ($url); ?>" class="<?php echo ($tooltip_class); ?>" data-placement="bottom" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
							<i class="icon-google-plus"></i>
						</a>
					</li>
				<?php }
				if ( $key == 'pinterest' && $value ) { ?>
					<li class="share-pinterest">
						<a href="http://pinterest.com/pin/create/button/?url=<?php echo ($url); ?>&amp;media=<?php echo ($img); ?>&amp;description=<?php echo ($summary); ?>" target="_blank" title="<?php _e( 'Share on Pinterest', 'zoomarts' ); ?>" rel="nofollow" class="<?php echo ($tooltip_class); ?>" data-placement="bottom" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
							<i class="icon-pinterest"></i>
						</a>
					</li>
				<?php }
				if ( $key == 'linkedin' && $value ) { ?>
					<li class="share-linkedin">
						<a title="<?php _e( 'Share on LinkedIn', 'zoomarts' ); ?>" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo ($url); ?>&amp;title=<?php echo ($title); ?>&amp;summary=<?php echo ($summary); ?>&amp;source=<?php echo ($source); ?>" target="_blank" rel="nofollow" class="<?php echo ($tooltip_class); ?>" data-placement="bottom" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
							<i class="icon-linkedin"></i>
						</a>
					</li>
				<?php }
			} ?>
		</ul>

	<?php
	}
}