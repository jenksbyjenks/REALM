/* ----------------- Start JS Document ----------------- */

//Mobile Detect
var $j = jQuery.noConflict(),
	header_offset = $j('#header').offset().top,
	deviceAgent = navigator.userAgent.toLowerCase(),
	isTouchDevice = Modernizr.touch || 
		(deviceAgent.match(/(iphone|ipod|ipad)/) ||
		deviceAgent.match(/(android)/)  || 
		deviceAgent.match(/(iemobile)/) || 
		deviceAgent.match(/iphone/i) || 
		deviceAgent.match(/ipad/i) || 
		deviceAgent.match(/ipod/i) || 
		deviceAgent.match(/blackberry/i) || 
		deviceAgent.match(/bada/i));
	
$j(document).ready(function() {
	initVideoBackground();
	crossfadeBackground();
	moveLayersParallax();
	layersParallax();
	stickyHeader();
	headerSearch();
	navMenu();
	imageLightbox();
	moreScripts();
	pieCharts();
	progressBar();
	customCarousel();
	counterBlock();
	cssTransition();
	portfolioIsotope();
	fullScreenSection();
	onePageNav();
	productGallery();
	parallaxInit();
	stickyProjectContent();
	widgetGridImages();
	$j(window).scroll(function() {
		EasyPeasyParallax();	
	});
	blogisotope();
});

$j(window).load(function() {
	fullHeightColumn();
	fadeInProjects();
	fadeInPosts();
});

$j(window).resize(function() {
	blogisotope();
	fullScreenSection();
	widgetGridImages();
});

$j(window).scroll(function() {
	stickyHeader();
});

$j(window).bind('scroll', function () {
	parallaxContent();
});

$j(window).bind('load', function () {
	portfolioIsotope();
});

$j(window).bind('resize', function () {
	fullHeightColumn();
});


//-------------- Video Background --------------//
function initVideoBackground(){
	"use strict";
	$j('.video-bg .video').mediaelementplayer({
		enableKeyboard: false,
		pauseOtherPlayers: false,
		iPadUseNativeControls: false,
		iPhoneUseNativeControls: false,
		AndroidUseNativeControls: false,
	});
	//mobile check
	if (isTouchDevice) {
		$j('.mobile-video-image').show();
		$j('.video-bg .video').remove();
	}
	$j('.yt-player-bg').each(function() {
        $j('.yt-player-bg').mb_YTPlayer();
    });
}


//-------------- Parallax Background --------------//
function parallaxInit(){
	"use strict";
	$j(window).stellar({
		horizontalOffset: 0,
		verticalOffset: 0,
		horizontalScrolling: false,
	});
}


//-------------- Move Layers Parallax --------------//
function moveLayersParallax() {
	"use strict";
	$j('.layers-parallax').each(function() {
		var container = $j(this),
			containerClone = $j(this).clone(),
			sectionContainer = container.parents('.section');
		containerClone.prependTo(sectionContainer);
		container.detach();
	})
}	


//-------------- Layers Parallax --------------//
function layersParallax() {
	"use strict";
	$j('.layers-parallax').each(function() {
		var containerID = $j(this).attr('id'),
			scene = document.getElementById(containerID),
			parallax = new Parallax(scene);
	})
}	


//-------------- Scripts --------------//
function crossfadeBackground(){
	"use strict";
	$j(".portfolio-filters.style1").hover(function() {
		$j(this).find('ul').slideToggle(400, 'easeOutSine');
	});
	$j('.section-crossfade').crossfade({ threshold: 0.2 });
}


//-------------- Sticky Header --------------//
function stickyHeader() {
	"use strict";
	var scroll_top = $j(window).scrollTop(),
		top_bar_height = $j('#top-bar').height(),
		header_shrink = $j('#header').attr('data-shrink'),
		header_sticky = $j('#header').attr('data-sticky'),
		header_style = $j('.header-outer').attr('data-class-style'),
		header_height = parseInt($j('#header').attr('data-header-height')),
		header_sticky_height = parseInt($j('#header').attr('data-sticky-height')),
		header_outer_sticky_height = top_bar_height + header_sticky_height,
		header_outer_height = top_bar_height + header_height,
		top_bar_sticky = $j('.header-outer').attr('data-sticky-topbar');
	
	if ( header_sticky == '1' ) {
		if ( scroll_top > header_offset ) {
			$j('.header-outer').removeClass(header_style);
			if (  top_bar_sticky == '1' ) {
				$j('#header').addClass('sticky-topbar');
				$j('#top-bar').addClass('sticky');
			} else {
				$j('#header').addClass('sticky');
			}
			$j('.hidden-header').css({
				height: header_outer_sticky_height + 'px'
			});
			if ( header_shrink == '1' ) {
				$j('.nav-menu > ul > li > a, #header .show-search').css({
					height: header_sticky_height + 'px',
					lineHeight: header_sticky_height + 'px'
				});
				$j('#header #logo, .wc-cart-icon, #header .show-menu').css({
					height: header_sticky_height + 'px'
				});
			}
		} else {
			$j('.header-outer').addClass(header_style);
			if (  top_bar_sticky == '1' ) {
				$j('#header').removeClass('sticky-topbar');
				$j('#top-bar').removeClass('sticky');
			} else {
				$j('#header').removeClass('sticky');
			}
			$j('.hidden-header').css({
				height: header_outer_height + 'px'
			});
			if ( header_shrink == '1' ) {
				$j('.nav-menu > ul > li > a, #header .show-search').css({
					height: header_height + 'px',
					lineHeight: header_height + 'px'
				});
				$j('#header #logo, .wc-cart-icon, #header .show-menu').css({
					height: header_height + 'px'
				});
			}
		}
	}

	$j('.show-menu span').click(function(){
		$j('body').addClass('mobile-menu-showen');
	});

	$j('.close-mobile-nav').click(function(){
		$j('body').removeClass('mobile-menu-showen');
	});

}


//-------------- Nav Menu --------------//
function navMenu(){
	"use strict";
	// Dropdown Nav Menu
	$j('.nav-menu ul li').hover(function(){
		var sub = $j(this).find('.second-lvl');
		if(sub.length > 0 && $j(window).width() > 979) {
			sub.stop().fadeIn(300, 'easeOutCubic');
		}
	}, function(){
		var sub = $j(this).find('.second-lvl');
		if(sub.length > 0 && $j(window).width() > 979) {
			sub.stop().fadeOut(150, 'easeOutCubic');
		}
	});
	// Dropdown Nav Menu
	$j(".responsive-menu .nav-menu").hide();
    $j(".toggle-menu").click(function() {
        $j(".responsive-menu .nav-menu").slideToggle(500);
    });
	// Mega Menu Background Image
	$j('.mega-menu').each(function(){
		var menuBackground = ($j(this).attr("data-background-image")) ? ($j(this).attr("data-background-image")) : '',
			menuBackgroundPos = ($j(this).attr("data-background-pos")) ? ($j(this).attr("data-background-pos")) : '';
		$j(this).find('.second-lvl').css({
			'background-image' : 'url('+menuBackground+')',
			'background-position' : menuBackgroundPos,
		});
	});
	$j('.wc-cart-icon').hover(function(){
		var sub = $j(this).find('.woo-cart-box');
		sub.stop().fadeIn(300, 'easeOutCubic');
	}, function(){
		var sub = $j(this).find('.woo-cart-box');
		sub.stop().fadeOut(200, 'easeOutCubic');
	});
}


//-------------- Header Search --------------//
function headerSearch(){
	"use strict";
	// Dropdown Nav Menu
	$j('.show-search').click(function(){
		var sub = $j('#search-box');
		sub.stop().slideDown(200, 'easeOutCubic');
		sub.find('#s').focus();
	});
	$j('#search-box .close-btn').click(function(){
		var sub = $j('#search-box');
		sub.stop().slideUp(150, 'easeOutCubic');
	});
}


//-------------- Full Height Columns --------------//
function fullHeightColumn() {
	"use strict";
   	$j('.fullheight-columns').each(function() {
   		$j(this).find('.container > .row > .col, > .col').matchHeight({
   			byRow: false,
   		});
   	});

}


//-------------- Parallax Contnet Effect --------------//
function EasyPeasyParallax() {
	var scrollPos = $j(this).scrollTop();
	$j(".page-header.parallax-content").each(function() {
		var titleLetterSpac = parseInt($j(this).find('h2').attr("data-letter-spacing"));
		$j(this).find('.page_header-content').css({
			'top': (scrollPos*0.5)+"px",
			'opacity': 1-(scrollPos/400)
		});
		$j(this).find('h2').css({
			'letter-spacing': (scrollPos/30)+titleLetterSpac+"px",
		});
		if ( $j(".page-header.parallax-content").length ) {
			var suptitleLetterSpac = parseInt($j(this).find('h5').attr("data-letter-spacing"));
			$j(this).find('h5').css({
				'letter-spacing': (scrollPos/40)+suptitleLetterSpac+"px",
			});
		}
	});
}


//-------------- Parallax Contnet Effect --------------//
function parallaxContent() {
	var scrollTop = $j(this).scrollTop();
	$j(".za-parallax-box").each(function() {
		var elementOffset = $j(this).offset().top,
    		distance = (elementOffset - scrollTop);
		if ( distance > 0 ) {
			$j(this).css({
				//'top': ((scrollTop/3)*parallaxSpeed)+"px",
				'top': ((distance*0.4)*0.5)+"px",
			});
		} else {
			$j(this).css({
				//'top': ((scrollTop/3)*parallaxSpeed)+"px",
				'top': "0px",
			});
		}
	});
}


//-------------- Sticky Header --------------//
function imageLightbox() {
	$j('a.lightbox').lightcase({
		maxWidth: '100%', 
		maxHeight: '100%',
		overlayOpacity: 1,
		labels: {
			'errorMessage': 'Source could not be found...',
			'sequenceInfo.of': ' of ',
			'close': '<i class="icon-cross3"></i>',
			'navigator.prev': '<i class="icon-arrow-left4"></i>',
			'navigator.next': '<i class="icon-arrow-right4"></i>',
 			'navigator.play': '<i class="icon-controller-play"></i>',
			'navigator.pause': '<i class="icon-controller-paus"></i>'
		},
	});
}


//-------------- Progress Bars --------------//	
function progressBar() {
	$j("[data-progress-animation]").each(function() {
		var $this = $j(this);
		$this.waypoint(function() {
			var delay = ($this.attr("data-appear-animation-delay") ? $this.attr("data-appear-animation-delay") : 1);
			if(delay > 1) $this.css("animation-delay", delay + "ms");
			setTimeout(function() { $this.animate({width: $this.attr("data-progress-animation")}, 800);}, delay);
		},{offset: '90%'});
	});
}


//-------------- Counters --------------//	
function counterBlock() {
	$j('.za-counter-block').each(function() {
		$j(this).waypoint(function() {
			var endNum = parseInt($j(this).attr("data-number"));
			$j(this).find('.num').countTo({
				from: 0,
				to: endNum,
				speed: 2000,
			});
		},{offset: '100%', triggerOnce: true});
	});
}


//-------------- Carousel --------------//	
function customCarousel() {
	$j('.custom-carousel').each(function(){
		var owl = $j(this),
			itemsNumDesktop = (owl.data('items-desktop')) ? (owl.data('items-desktop')) : 4,
			itemsNumTablet = (owl.data('items-tablet')) ? (owl.data('items-tablet')) : 3,
			itemsNumMobile = (owl.data('items-mobile')) ? (owl.data('items-mobile')) : 2,
			carouselNav = (owl.data('carousel-nav')) ? (owl.data('carousel-nav')) : false,
			carouselPag = (owl.data('carousel-pag')) ? (owl.data('carousel-pag')) : false,
			animateOutData = (owl.data('animate-out')) ? (owl.data('animate-out')) : false,
			animateInData = (owl.data('animate-in')) ? (owl.data('animate-in')) : false,
			carouselAutoHeight = (owl.data('auto-height')) ? (owl.data('auto-height')) : false,
			carouselMargin = (owl.data('margin')) ? (owl.data('margin')) : 0,
			carouselStagePadding = (owl.data('stage-padding')) ? (owl.data('stage-padding')) : 0,
			carouselLazyLoad = (owl.data('lazy-load')) ? (owl.data('lazy-load')) : false;

		owl.owlCarousel({
			smartSpeed: 200,
			autoplay: false,
			autoplayHoverPause: true,
			nav : carouselNav,
			dots: carouselPag,
			loop: true,
			lazyLoad: carouselLazyLoad,
			margin: carouselMargin,
			stagePadding: carouselStagePadding,
			autoHeight: carouselAutoHeight,
			animateOut: animateOutData,
			animateIn: animateInData,
			items : itemsNumDesktop,
			autoplayHoverPause:true,
			navText: [
				"<i class='icon-arrow-left4'></i>",
				"<i class='icon-arrow-right4'></i>"
			],
			responsive:{
		        0:{
		            items:itemsNumMobile,
		        },
		        479:{
		            items:itemsNumTablet,
		        },
		        768:{
		        	items:itemsNumDesktop,
		        },
		    }
		});
	});

	var galleryTop = new Swiper('.gallery-top', {
        spaceBetween: 0,
        autoHeight: true,
        pagination: '.swiper-pagination',
        paginationClickable: true,
        //effect: 'fade',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
    });
    var galleryThumbs = new Swiper('.gallery-thumbs', {
        spaceBetween: 0,
        centeredSlides: true,
        slidesPerView: 'auto',
        touchRatio: 0.2,
        slideToClickedSlide: true,
    });
    galleryTop.params.control = galleryThumbs;
    galleryThumbs.params.control = galleryTop;

}


//-------------- Pie Charts --------------//
var pieChartClass = 'pie-chart',
	pieChartLoadedClass = 'pie-chart-loaded';	
function pieCharts() {
	var chart = $j('.' + pieChartClass);
	chart.each(function() {
		$j(this).waypoint(function() {
			var $this = $j(this),
				chartBarColor = ($this.data('bar-color')) ? ($this.data('bar-color')) : "#444444",
				chartLineWidth = ($this.data('line-width')) ? ($this.data('line-width')) : 2,
				chartBarWidth = ($this.data('bar-width')) ? ($this.data('bar-width')) : 150
			if( !$this.hasClass(pieChartLoadedClass) ) {
				$this.easyPieChart({
					animate: 2000,
					size: chartBarWidth,
					lineWidth: chartLineWidth,
					scaleColor: false,
					trackColor: "rgba(0,0,0,0.08)",
					lineCap: 'square',
					barColor: chartBarColor,
				}).addClass(pieChartLoadedClass);
			}
		},{offset: '110%'});
	});
}


//-------------- Css3 Transition --------------//
function cssTransition() {
	$j('.animation-class').each(function(){
		var animationName = $j(this).attr('data-animation'),
			animationDelay = $j(this).attr('data-animation-delay');
		$j(this).waypoint(function() {
			$j(this).addClass('animated').addClass(animationName);
			$j(this).css({
				'animation-delay': animationDelay+'s',
				'-webkit-animation-delay': animationDelay+'s',
				'-moz-animation-delay': animationDelay+'s',
				'-o-animation-delay': animationDelay+'s',
			});
		},{offset: '60%'});
	});
}


//-------------- FadeIn Projects --------------//
function fadeInProjects() {
	$j('.projects-list').each(function(){
		var container = $j(this);
		setTimeout(function() {
			container.find('.projects-loader').delay(600).fadeOut(600);
			$j('.projects-wrap .project-item').each(function(i) {
				var li = $j(this);
				setTimeout(function() {
					li.addClass('visible-item');
				}, i*200);
			});
		}, 1200);
	});
}


//-------------- Portfolio Isotope --------------//
function portfolioIsotope() {
	$j('.projects-list').each( function() {
		if( $j(this).hasClass('grid-layout') ) {
			var $container = $j('.projects-list').imagesLoaded( function() {
				$container.isotope({
					itemSelector: '.project-item',
				});
			});
			$j('.projects-wrap .filters-list').on( 'click', 'span', function() {
				var filterValue = $j( this ).attr('data-filter');
				filterValue = filterValue;
				$j('.projects-list').isotope({ filter: filterValue });
			});
			$j('.projects-wrap .filters-list').each( function( i, buttonGroup ) {
				var $buttonGroup = $j( buttonGroup );
				$buttonGroup.on( 'click', 'span', function() {
					$buttonGroup.find('.active').removeClass('active');
					$j( this ).addClass('active');
				});
			});
		} else if( $j(this).hasClass('masonry-layout') || $j(this).hasClass('masonry-multisize-layout') ) {
			var $container = $j('.projects-list').imagesLoaded( function() {
				$container.isotope({
					itemSelector: '.project-item',
					masonry: {
						columnWidth: '.grid-sizer',
					},
				});
			});
			$j('.projects-wrap .filters-list').on( 'click', 'span', function() {
				var filterValue = $j( this ).attr('data-filter');
				filterValue = filterValue;
				$j('.projects-list').isotope({ filter: filterValue });
			});
			$j('.projects-wrap .filters-list').each( function( i, buttonGroup ) {
				var $buttonGroup = $j( buttonGroup );
				$buttonGroup.on( 'click', 'span', function() {
					$buttonGroup.find('.active').removeClass('active');
					$j( this ).addClass('active');
				});
			});
		}
	});
}


//-------------- FullScreen Sections --------------//
function fullScreenSection() {
	"use strict";
	$j('.section.fullscreen-section').each( function() {
		var contentHeight = $j(this).find('.row').height(),
			section = $j(this),
			windowHeight = $j(window).height();
		if ( contentHeight < windowHeight ) {
			section.css('height', (windowHeight)+'px');
		}
	});
}


//-------------- One Page Nav --------------//
function onePageNav() {
	"use strict";

	// Nav Menu (current class)
	var menuItems = $j("#one-page-nav li a"),
		lastId,
		fromTop,
		cur,
		scrollItems = menuItems.map(function() {
			var item = $j($j(this).attr("href"));
			if (item.length) return item;
		});

	menuItems.parent().eq(0).addClass('current');
	menuItems.wrapInner( "<span></span>");

	// click nav
	menuItems.on('click', function(e) {
		var href  = $j(this).attr("href"),
		offsetTop = $j(href).offset().top + 'px';
		$j('html, body').stop().animate({scrollTop: offsetTop}, 600, 'easeOutCubic');
		e.preventDefault();
	});

	// add current class to menu
	$j(window).scroll(function(){
		fromTop = $j(this).scrollTop() + 10,
		cur = scrollItems.map( function() {
			if ($j(this).offset().top < fromTop) return this;
		});
		cur = cur[cur.length-1];
		var id = cur && cur.length ? cur[0].id : "";
		if (lastId !== id) {
			lastId = id;
			menuItems.parent().removeClass("current").end().filter("[href=#"+id+"]").parent().addClass("current");
		}
	});
}


//-------------- Products Gallery --------------//
function productGallery() {
	"use strict";

	var imgGallery = '.product-gallery img',
		imgSmall = '.has-post-thumbnail .images .small',
		imgFull;

	$j(document).on('click', imgGallery, function(e){
		e.preventDefault();
		e.stopPropagation();
		$j('.single-product-main-image .thumbnails img').removeClass('active');
		$j(this).addClass('active');
		var photo_fullsize =  $j(this).parent('.product-gallery').data('gallery-full');
		var photo_smallsize =  $j(this).parent('.product-gallery').data('gallery-img');
		if (photo_fullsize != $j(imgSmall).attr('src')) {
			$j('<img src="'+ photo_fullsize +'">').load(function() {
				$j(imgSmall).attr('src', photo_smallsize);
				$j('.has-post-thumbnail .images .lightbox').attr('href', photo_fullsize);
			});
		}
		return false;
	});
}


//-------------- Widget Grid Images --------------//
function widgetGridImages() {
	"use strict";
	$j('.style-grid.widget-recent-posts li, .flickr-me-feed .grid-pics a').each(function() {
		var imageWidth = $j(this).find('img').outerWidth();
		$j(this).find('img').css('height', imageWidth+'px');
	});
}


//-------------- Sticky Info for Project Page --------------//
function stickyProjectContent() {
	"use strict";
	$j('.project-info.sticky').each(function() {
		if ( $j('#header').attr('data-sticky') == '1' ) {
			if ( $j("#wpadminbar").length ) {
				var topSticky = parseInt($j('#header').attr('data-sticky-height')) + $j('#wpadminbar').height() + 25;
			} else {
				var topSticky = parseInt($j('#header').attr('data-sticky-height')) + 25;
			}
		} else {
			if ( $j("#wpadminbar").length ) {
				var topSticky = $j('#header').height() + $j('#wpadminbar').height() + 25;
			} else {
				var topSticky =  $j('#header').height() + 25;
			}
		}
		$j('.project-info.sticky').pin({
			containerSelector: ".project-content",
			padding: {top: topSticky},
			minWidth: 992
		})
	});
}


//-------------- More Scripts --------------//
function moreScripts() {
	"use strict";

	$j('select').wrap('<span class="styled-select"></span>');

	// Fit Videos for Widgets
	$j(".fitvid, .textwidget").fitVids();

	// Tooltips
	$j('.za-tooltip, .tagcloud a').tooltip();

	// Go Top Button
	$j('#go-top').click(function(){
		$j('html, body').animate({scrollTop : 0},600, "easeInOutExpo");
		return false;
	});

	// Fix Container Inside other Container
	$j('.section > .container').each(function() {
		$j(this).find('.container').removeClass('container');
	});

	// Add Star Icon for Sticky Posts
	$j('.blog-items .post.sticky, .blog-items .post.tag-sticky-2').each(function() {
		$j(this).append('<span class="sticky-icon"><i class="icon-star-full"></i></span>');
	});

	// Icon Box
	$j('.za-icon-box.boxed-style').each(function() {
		var iconBox = $j(this),
			iconHeight = $j(this).find('i.font-icon').height();
		iconBox.css('margin-top', (iconHeight/2)+'px');
		iconBox.css('padding-top', (iconHeight/2)+24+'px');
	});

	// Lists
	$j('.content-area ul, .comments ul').each(function() {
		var attr = $j(this).attr('class');
		if ( typeof attr == typeof undefined || attr == false ) {
			$j(this).addClass('unordered-list');
		}
	});
	$j('.content-area ol, .comments ol').each(function() {
		var attr = $j(this).attr('class');
		if ( typeof attr == typeof undefined || attr == false ) {
			$j(this).addClass('ordered_list');
		}
	});
	$j('.pinglist').each(function() {
			$j(this).addClass('ordered_list');
	});


	// Login Form Styling
	$j('.za-login-form').each(function() {
		var usernameData = $j(this).attr('data-username'),
			passwordData = $j(this).attr('data-password'),
			bgColorData = $j(this).attr('data-bg-color'),
			textColorData = $j(this).attr('data-text-color'),
			borderColorData = $j(this).attr('data-border-color'),
			borderradiusData = $j(this).attr('data-border-radius');
		$j(this).find('input[type="text"]').attr("placeholder", usernameData).css({'background-color': bgColorData, 'border-color': borderColorData, 'color': textColorData, 'border-radius': borderradiusData, '-o-border-radius': borderradiusData, '-moz-border-radius': borderradiusData, '-webkit-border-radius': borderradiusData });
		$j(this).find('input[type="password"]').attr("placeholder", passwordData).css({'background-color': bgColorData, 'border-color': borderColorData, 'color': textColorData });
	});

	// Bottom Border For Wite Page Header
	if ( $j('.page-header').length > 0) {
		var pageHeaderBg = $j('.page-header').css('background-color');
		if ( pageHeaderBg == 'rgb(255,255,255)' || typeof(pageHeaderBg) != "undefined" ) {
			$j('.page-header').css({'border-bottom': '1px solid #eeeeee'});
		}
	}

	// WooCommerce Counter
	$j('body').on('click', '.add_to_cart_button', function() {
		$j(this).parents('.product:eq(0)').addClass('woocommerce_adding_loading').removeClass('woocommerce_added_check');
		var nel = $j('.woo-cart-icon').find('span');
		var num = nel.data('num');
		nel.text(num+1);
		nel.data('num', num+1);
	})
	$j('body').bind('added_to_cart', function() {
		$j('.woocommerce_adding_loading').removeClass('woocommerce_adding_loading').addClass('woocommerce_added_check');
	});

	// Styled Forms
	$j('.styled-form p').each(function() {
		var formP = $j(this);
		if ( $j(formP.find('input').hasClass('wpcf7-validates-as-required') ) ) {
			formP.find('label').append('<i>*</i>');;
		}
		$j(formP.find('input'), this).focus(function(){
			formP.addClass('focused');
        }).blur(function(){
        	if ( $j(this).val().length === 0 ) {
			    formP.removeClass('focused');
			}
        });
        $j(formP.find('textarea'), this).focus(function(){
			formP.addClass('focused');
        }).blur(function(){
        	if ( $j(this).val().length === 0 ) {
			    formP.removeClass('focused');
			}
        });
        if(formP.html().replace(/\s|&nbsp;/g, '').length == 0) {
            formP.remove();
        }
	});

	// Flip Boxes Effect
	if ( $j('.flipper').length > 0) {
		$j('.flipper').each(function() {
			var flipper = $j(this);
			flipper.flip({
				trigger: 'hover',
				speed: 600
			});
		});
	}
}


//-------------- FadeIn Posts --------------//
fadeInPosts = function() {
	$j($j('.blog-masonry li.post').get().reverse()).each(function(i) {
		var li = $j(this);
		setTimeout(function() {
			li.addClass('visible-item');
		}, i*200);
	});
};


//-------------- Blog Isotope Call --------------//
blogisotope = function() {
	var blog_container = $j('.blog-masonry .items-list');
	blog_container.imagesLoaded( function(){
		blog_container.isotope({
			itemSelector: '.post',
		});
	});  
};