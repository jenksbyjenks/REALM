<?php
/**
 * Customizing Visual-Composer
 *
 * @package WordPress
 * @subpackage Dalton
 * @since Dalton 1.2.1
*/

global $zoomarts_options;


/*-----------------------------------------------------------------------------*/
/*  Removing Defaults Shortcodes
/*-----------------------------------------------------------------------------*/

// Remove unused elements
if (function_exists('vc_remove_element') && isset($zoomarts_options['vc_default_shortcodes']) && $zoomarts_options['vc_default_shortcodes'] == 0 ) {
	vc_remove_element("vc_widget_sidebar");
	vc_remove_element("vc_wp_search");
	vc_remove_element("vc_wp_meta");
	vc_remove_element("vc_wp_recentcomments");
	vc_remove_element("vc_wp_calendar");
	vc_remove_element("vc_wp_pages");
	vc_remove_element("vc_wp_tagcloud");
	vc_remove_element("vc_wp_custommenu");
	vc_remove_element("vc_wp_text");
	vc_remove_element("vc_wp_posts");
	vc_remove_element("vc_wp_links");
	vc_remove_element("vc_wp_categories");
	vc_remove_element("vc_wp_archives");
	vc_remove_element("vc_wp_rss");
	vc_remove_element("vc_teaser_grid");
	vc_remove_element("vc_button");
	vc_remove_element("vc_button2");
	vc_remove_element("vc_cta_button");
	vc_remove_element("vc_cta_button2");
	vc_remove_element("vc_message");
	vc_remove_element("vc_progress_bar");
	vc_remove_element("vc_pie");
	vc_remove_element("vc_toggle");
	vc_remove_element("vc_images_carousel");
	vc_remove_element("vc_posts_grid");
	vc_remove_element("vc_basic_grid");
	vc_remove_element("vc_media_grid");
	vc_remove_element("vc_posts_slider");
	vc_remove_element("vc_masonry_grid");
	vc_remove_element("vc_masonry_media_grid");
	vc_remove_element("vc_carousel");
	vc_remove_element("vc_separator");
	vc_remove_element("vc_text_separator");
	vc_remove_element("vc_gmaps");
	vc_remove_element("vc_empty_space");
	vc_remove_element("vc_gallery");
	vc_remove_element("vc_single_image");
	vc_remove_element("vc_icon");
	vc_remove_element("vc_custom_heading");
	vc_remove_element("vc_tta_accordion");
}

// Remove unused parameters
if (function_exists('vc_remove_param')) {
	vc_remove_param('vc_row', 'full_width');
	vc_remove_param('vc_row', 'full_height');
	vc_remove_param('vc_row', 'content_placement');
	vc_remove_param('vc_row', 'video_bg');
	vc_remove_param('vc_row', 'video_bg_url');
	vc_remove_param('vc_row', 'video_bg_parallax');
	vc_remove_param('vc_row', 'parallax');
	vc_remove_param('vc_row', 'parallax_image');
	vc_remove_param('vc_column', 'font_color');
}

// Remove frontend editor
if(function_exists('vc_disable_frontend')){
	vc_disable_frontend();
}


/*-----------------------------------------------------------------------------*/
/*  Options Arrays
/*-----------------------------------------------------------------------------*/

// Links Targets Array
$target_arr = array(
	'Same window' 		=> '_self',
	'New window'		=> "_blank"
);

// Custom Font Array
$custom_fonts = array(
	__( 'default', 'zoomarts' ) 				=> "",
	__( 'Custom Font 1', 'zoomarts' ) 		=> "custom-font-1",
	__( 'Custom Font 2', 'zoomarts' ) 		=> "custom-font-2",
	__( 'Custom Font 3', 'zoomarts' ) 		=> "custom-font-3",
	__( 'Custom Font 4', 'zoomarts' ) 		=> "custom-font-4",
	__( 'Custom Font 5', 'zoomarts' ) 		=> "custom-font-5",
	__( 'Custom Font 6', 'zoomarts' ) 		=> "custom-font-6",
	__( 'Custom Font 7', 'zoomarts' ) 		=> "custom-font-7",
	__( 'Custom Font 8', 'zoomarts' ) 		=> "custom-font-8",
	__( 'Custom Font 9', 'zoomarts' ) 		=> "custom-font-9",
	__( 'Custom Font 10', 'zoomarts' ) 		=> "custom-font-10",
	__( 'Custom Font 11', 'zoomarts' ) 		=> "custom-font-11",
	__( 'Custom Font 12', 'zoomarts' ) 		=> "custom-font-12",
	__( 'Custom Font 13', 'zoomarts' ) 		=> "custom-font-13",
	__( 'Custom Font 14', 'zoomarts' ) 		=> "custom-font-14",
	__( 'Custom Font 15', 'zoomarts' ) 		=> "custom-font-15",
);

// Social Icons Array
$social_icons_array = array(
	"" 					=> "",
	__( 'Facebook', 'zoomarts' )			=> "facebook",
	__( 'Twitter', 'zoomarts' ) 			=> "twitter",
	__( 'Google Plus', 'zoomarts' ) 		=> "google-plus",
	__( 'Dribbble', 'zoomarts' )			=> "dribbble",
	__( 'Flickr', 'zoomarts' ) 			=> "flickr",
	__( 'Behance', 'zoomarts' ) 			=> "behance",
	__( 'Deviantart', 'zoomarts' )		=> "deviantart",
	__( 'Youtube', 'zoomarts' ) 			=> "youtube",
	__( 'Instagram', 'zoomarts' ) 		=> "instagram",
	__( 'Pinterest', 'zoomarts' ) 		=> "pinterest",
	__( 'Tumblr', 'zoomarts' ) 			=> "tumblr",
	__( 'Vimeo', 'zoomarts' )			=> "vimeo",
	__( 'Linkedin', 'zoomarts' )			=> "linkedin",
	__( 'Github', 'zoomarts' ) 			=> "github",
	__( 'Skype', 'zoomarts' ) 			=> "skype",
	__( 'VK', 'zoomarts' ) 				=> "vk",
	__( 'Soundcloud', 'zoomarts' )		=> "soundcloud",
	__( 'Xing', 'zoomarts' )				=> "xing",
);

// Slider Animations In Array
$slider_animations_in_array = array(
	__( 'Default', 'zoomarts' ) 			=> "false",
	__( 'bounceIn', 'zoomarts' )			=> "bounceIn",
	__( 'bounceInDown', 'zoomarts' )		=> "bounceInDown",
	__( 'bounceInLefts', 'zoomarts' ) 	=> "bounceInLeft",
	__( 'bounceInRight', 'zoomarts' ) 	=> "bounceInRight",
	__( 'bounceInUp', 'zoomarts' ) 		=> "bounceInUp",
	__( 'fadeIn', 'zoomarts' ) 			=> "fadeIn",
	__( 'fadeInDown', 'zoomarts' ) 		=> "fadeInDown",
	__( 'fadeInLeft', 'zoomarts' ) 		=> "fadeInLeft",
	__( 'fadeInRight', 'zoomarts' ) 		=> "fadeInRight",
	__( 'fadeInUp', 'zoomarts' ) 		=> "fadeInUp",
	__( 'flipInX', 'zoomarts' ) 			=> "flipInX",
	__( 'flipInY', 'zoomarts' ) 			=> "flipInY",
	__( 'zoomIn', 'zoomarts' ) 			=> "zoomIn",
	__( 'zoomInDown', 'zoomarts' ) 		=> "zoomInDown",
	__( 'zoomInLeft', 'zoomarts' ) 		=> "zoomInLeft",
	__( 'zoomInRight', 'zoomarts' ) 		=> "zoomInRight",
	__( 'zoomInUp', 'zoomarts' )			=> "zoomInUp",
	__( 'slideInDown', 'zoomarts' ) 		=> "slideInDown",
	__( 'slideInLeft', 'zoomarts' ) 		=> "slideInLeft",
	__( 'slideInRight', 'zoomarts' )		=> "slideInRight",
	__( 'slideInUp', 'zoomarts' ) 		=> "slideInUp",
	__( 'rollIn', 'zoomarts' ) 			=> "rollIn",
);

// Slider Animations Out Array
$slider_animations_out_array = array(
	__( 'Default', 'zoomarts' ) 			=> "false",
	__( 'bounceOut', 'zoomarts' ) 		=> "bounceOut",
	__( 'bounceOutDown', 'zoomarts' ) 	=> "bounceOutDown",
	__( 'bounceOutLefts', 'zoomarts' ) 	=> "bounceOutLeft",
	__( 'bounceOutRight', 'zoomarts' ) 	=> "bounceOutRight",
	__( 'bounceOutUp', 'zoomarts' ) 		=> "bounceOutUp",
	__( 'fadeOut', 'zoomarts' ) 			=> "fadeOut",
	__( 'fadeOutDown', 'zoomarts' ) 		=> "fadeOutDown",
	__( 'fadeOutLeft', 'zoomarts' ) 		=> "fadeOutLeft",
	__( 'fadeOutRight', 'zoomarts' )		=> "fadeOutRight",
	__( 'fadeOutUp', 'zoomarts' ) 		=> "fadeOutUp",
	__( 'flipOutX', 'zoomarts' )			=> "flipOutX",
	__( 'flipOutY', 'zoomarts' )			=> "flipOutY",
	__( 'zoomOut', 'zoomarts' ) 			=> "zoomOut",
	__( 'zoomOutDown', 'zoomarts' ) 		=> "zoomOutDown",
	__( 'zoomOutLeft', 'zoomarts' ) 		=> "zoomOutLeft",
	__( 'zoomOutRight', 'zoomarts' )		=> "zoomOutRight",
	__( 'zoomOutUp', 'zoomarts' ) 		=> "zoomOutUp",
	__( 'slideOutDown', 'zoomarts' )		=> "slideOutDown",
	__( 'slideOutLeft', 'zoomarts' )		=> "slideOutLeft",
	__( 'slideOutRight', 'zoomarts' ) 	=> "slideOutRight",
	__( 'slideOutUp', 'zoomarts' ) 		=> "slideOutUp",
	__( 'rollOut', 'zoomarts' ) 			=> "rollOut",
);

// Full Animations
$animations_array = array(
	__( 'flash', 'zoomarts' ) 			=> "flash",
	__( 'pulse', 'zoomarts' ) 			=> "pulse",
	__( 'rubberBand', 'zoomarts' ) 		=> "rubberBand",
	__( 'shake', 'zoomarts' ) 			=> "shake",
	__( 'swing', 'zoomarts' ) 			=> "swing",
	__( 'tada', 'zoomarts' )				=> "tada",
	__( 'wobble', 'zoomarts' ) 			=> "wobble",
	__( 'bounce', 'zoomarts' ) 			=> "bounce",
	__( 'bounceIn', 'zoomarts' )			=> "bounceIn",
	__( 'bounceInDown', 'zoomarts' )		=> "bounceInDown",
	__( 'bounceInLeft', 'zoomarts' ) 	=> "bounceInLeft",
	__( 'bounceInRight', 'zoomarts' ) 	=> "bounceInRight",
	__( 'bounceInUp', 'zoomarts' ) 		=> "bounceInUp",
	__( 'fadeIn', 'zoomarts' ) 			=> "fadeIn",
	__( 'fadeInDown', 'zoomarts' ) 		=> "fadeInDown",
	__( 'fadeInLeft', 'zoomarts' ) 		=> "fadeInLeft",
	__( 'fadeInRight', 'zoomarts' ) 		=> "fadeInRight",
	__( 'fadeInUp', 'zoomarts' )			=> "fadeInUp",
	__( 'flipInX', 'zoomarts' ) 			=> "flipInX",
	__( 'flipInY', 'zoomarts' ) 			=> "flipInY",
	__( '"zoomIn', 'zoomarts' ) 			=> "zoomIn",
	__( 'zoomInDown', 'zoomarts' ) 		=> "zoomInDown",
	__( 'zoomInLeft', 'zoomarts' ) 		=> "zoomInLeft",
	__( 'zoomInRight', 'zoomarts' ) 		=> "zoomInRight",
	__( 'zoomInUp', 'zoomarts' )  		=> "zoomInUp",
	__( 'slideInDown', 'zoomarts' )  	=> "slideInDown",
	__( 'slideInLeft', 'zoomarts' )  	=> "slideInLeft",
	__( 'slideInRight', 'zoomarts' )  	=> "slideInRight",
	__( 'slideInUp', 'zoomarts' )  		=> "slideInUp",
	__( 'rotateIn', 'zoomarts' )  		=> "rotateIn",
	__( 'rotateInDownLeft', 'zoomarts' )	=> "rotateInDownLeft",
	__( 'rotateInDownRight', 'zoomarts' )=> "rotateInDownRight",
	__( 'rotateInUpLeft', 'zoomarts' )  	=> "rotateInUpLeft",
	__( 'rotateInUpRight', 'zoomarts' )	=> "rotateInUpRight",
	__( 'rollIn', 'zoomarts' )			=> "rollIn",
	__( 'lightSpeedIn', 'zoomarts' )		=> "lightSpeedIn",
);


$order_by_values = array(
	'',
	__( 'Date', 'zoomarts' )				=> 'date',
	__( 'ID', 'zoomarts' )				=> 'ID',
	__( 'Author', 'zoomarts' )			=> 'author',
	__( 'Title', 'zoomarts' ) 			=> 'title',
	__( 'Modified', 'zoomarts' ) 		=> 'modified',
	__( 'Random', 'zoomarts' ) 			=> 'rand',
	__( 'Comment count', 'zoomarts' ) 	=> 'comment_count',
	__( 'Menu order', 'zoomarts' ) 		=> 'menu_order',
);

$order_way_values = array(
	'',
	__( 'Descending', 'zoomarts' )		=> 'DESC',
	__( 'Ascending', 'zoomarts' ) 		=> 'ASC',
);


/*-----------------------------------------------------------------------------*/
/*  Custom Shortcodes Options
/*-----------------------------------------------------------------------------*/

// Row Shortcode
vc_add_param("vc_row", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'Anchor ID', 'zoomarts' ),
	"param_name" 				=> "anchor",
	"value" 					=> "",
));

vc_add_param("vc_row", array(
	"type" 						=> "checkbox",
	"param_name" 				=> "fullheight_columns",
	"heading" 					=> "<hr/><br/>".__( 'Equal Heights for Columns', 'zoomarts' ),
	"value" 					=> array(
		"Yes" => "true"
	),
));

vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"show_settings_on_create"	=> true,
	"heading" 					=> "<hr/><br/>".__( 'Row Type', 'zoomarts' ),
	"param_name" 				=> "row_type",
	"value" 					=> array(
		__( 'Full Width (Standard)', 'zoomarts' ) 	=> "fullwidth",
		__( 'Full Width Content', 'zoomarts' ) 		=> "fullwidth_content",
	)
));

vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"heading" 					=> "<hr/><br/>".__( 'Background Type', 'zoomarts' ),
	"param_name" 				=> "background_type",
	"value" 					=> array(
		__( 'Color', 'zoomarts' ) 		=> "color_bg",
		__( 'Image', 'zoomarts' ) 		=> "image_bg",
		__( 'Video', 'zoomarts' ) 		=> "video_bg",
	),
	"dependency" 				=> array( 'element' => "row_type", 'value' => array('fullwidth_content', 'fullwidth')),
));

vc_add_param("vc_row", array(
	"type" 						=> "colorpicker",
	"heading" 					=> __( 'Background Color', 'zoomarts' ),
	"param_name" 				=> "background_color",
	"value" 					=> "",
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('color_bg')),
));

vc_add_param("vc_row", array(
	"type" 						=> "attach_image",
	"heading" 					=> __( 'Background Image', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "background_image",
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('image_bg')),
));

vc_add_param("vc_row", array(
	"type" 						=> "colorpicker",
	"heading" 					=> __( 'Background Overlay Color', 'zoomarts' ),
	"param_name" 				=> "background_overlay_color",
	"value" 					=> "",
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('image_bg', 'video_bg')),
));

vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"heading" 					=> __( 'Background Position', 'zoomarts' ),
	"param_name" 				=> "background_position",
	"value" 					=> array(
		"" 										=> "",
		__( 'Left Top', 'zoomarts' ) 		=> "left top",
  		__( 'Left Center', 'zoomarts' ) 		=> "left center",
  		__( 'Left Bottom', 'zoomarts' ) 		=> "left bottom",
  		__( 'Center Top', 'zoomarts' ) 		=> "center top",
  		__( 'Center Center', 'zoomarts' ) 	=> "center center",
  		__( 'Center Bottom', 'zoomarts' ) 	=> "center bottom",
  		__( 'Right Top', 'zoomarts' ) 		=> "right top",
  		__( 'Right Center', 'zoomarts' ) 	=> "right center",
  		__( 'Right Bottom', 'zoomarts' ) 	=> "right bottom"
	),
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"heading" 					=> __( 'Background Repeat', 'zoomarts' ),
	"param_name" 				=> "background_repeat",
	"value" 					=> array(
		__( 'No Repeat', 'zoomarts' ) 		=> "no-repeat",
		__( 'Repeat', 'zoomarts' ) 			=> "repeat"
	),
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_row", array(
	"type" 						=> "checkbox",
	"heading" 					=> __( 'Cover Background', 'zoomarts' ),
	"value" 					=> array("Background Size (Cover)" => "true" ),
	"param_name" 				=> "cover_background",
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_row", array(
	"type" 						=> "checkbox",
	"heading" 					=> __( 'Background Attachment', 'zoomarts' ),
	"value" 					=> array("Fixed" => "true" ),
	"param_name" 				=> "background_attachment",
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"heading" 					=> __( 'Background Effect', 'zoomarts' ),
	"param_name" 				=> "background_effect",
	"value" 					=> array(
		"" 										=> "",
		__( 'Parallax', 'zoomarts' ) 		=> "parallax",
		__( 'Crossfade', 'zoomarts' ) 		=> "crossfade",
		__( 'Animation', 'zoomarts' ) 		=> "animation"
	),
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('image_bg')),
));

vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"heading" 					=> __( 'Background Animations', 'zoomarts' ),
	"param_name" 				=> "background_animation",
	"value" 					=> array(
		__( 'Moving To Top', 'zoomarts' ) 	=> "animate-top",
		__( 'Moving To Bottom', 'zoomarts' )	=> "animate-bottom",
		__( 'Moving To Right', 'zoomarts' ) 	=> "animate-right",
		__( 'Moving To Left', 'zoomarts' ) 	=> "animate-left",
		__( 'Zoom In-Out', 'zoomarts' ) 		=> "animate-zoom",
		__( 'Zoom With Rotate', 'zoomarts' )	=> "animate-zoom-rotate",
	),
	"dependency" 				=> array( 'element' => "background_effect", 'value' => array('animation')),
));

vc_add_param("vc_row", array(
	"type" 						=> "attach_image",
	"heading" 					=> __( 'CrossFade End Image', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "crossfade_end_image",
	"dependency" 				=> array( 'element' => "background_effect", 'value' => array('crossfade')),
));

vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"show_settings_on_create" 	=> true,
	"heading" 					=> __( 'Video Type', 'zoomarts' ),
	"param_name" 				=> "video_type",
	"value" 					=> array(
		__( 'Youtube Video', 'zoomarts' ) 		=> "youtube",
		__( 'Self Hosted Video', 'zoomarts' ) 	=> "self-hosted",
	),
	"dependency" 				=> array('element' => "background_type", 'value' => array('video_bg'))
));

vc_add_param("vc_row", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'Youtube Video URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "youtube_url",
	"description" 				=> __( 'Insert your youtube video URL.', 'zoomarts' ).'<strong>http://youtu.be/fH_jchqoFcA</strong>',
	"dependency" 				=> array('element' => "video_type", 'value' => array('youtube'))
));

vc_add_param("vc_row", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'WebM File URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_webm",
	"description" 				=> __( 'You must include this format & the mp4 format to render your video with cross browser compatibility, OGV is optional.
Video must be in a 16:9 aspect ratio', 'zoomarts' ),
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

vc_add_param("vc_row", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'MP4 File URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_mp4",
	"description" 				=> __( 'Enter the URL for your mp4 video file here', 'zoomarts' ),
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

vc_add_param("vc_row", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'OGV File URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_ogv",
	"description" 				=> __( 'Enter the URL for your ogv video file here', 'zoomarts' ),
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

vc_add_param("vc_row", array(
	"type" 						=> "attach_image",
	"class" 					=> "",
	"heading" 					=> __( 'Video Poster Image', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_poster",
	"description" 				=> __( 'This image will be a background for this section on mobiles', 'zoomarts' ),
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

/*vc_add_param("vc_row", array(
	"type" 						=> "dropdown",
	"heading" 					=> "<hr/><br/>Elements Color",
	"param_name" 				=> "elements_color",
	"value" 					=> array(
		"Light" 	=> "light-section",
		"Dark" 		=> "dark-section",
	),
));*/

vc_add_param("vc_row", array(
	"type" 						=> "colorpicker",
	"heading" 					=> __( 'Text Color', 'zoomarts' ),
	"param_name" 				=> "text_color",
	"value" 					=> "",
));

vc_add_param("vc_row", array(
	"type" 						=> "checkbox",
	"param_name" 				=> "fullscreen_section",
	"heading" 					=> "<hr/><br/>".__( 'FullScreen Section', 'zoomarts' ),
	"value" 					=> array(
		"Yes" => "true"
	),
));


// Columns Shortcode
vc_add_param("vc_column", array(
	"type" 						=> "checkbox",
	"param_name" 				=> "vertical_center",
	"heading" 					=> "<hr/><br/>".__( 'Vertical Centering Content', 'zoomarts' ),
	"value" 					=> array(
		"Yes" => "true"
	),
));

vc_add_param("vc_column", array(
	"type" 						=> "checkbox",
	"param_name" 				=> "check_animation",
	"heading" 					=> "<hr/><br/>".__( 'Column Animation', 'zoomarts' ),
	"value" 					=> array(
		"Enable Animation" => "true"
	),
));

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"heading" 					=> __( 'Animation', 'zoomarts' ),
	"param_name" 				=> "animation",
	"value" 					=> $animations_array,
	"dependency" 				=> Array('element' => "check_animation", 'not_empty' => true)
));

vc_add_param("vc_column", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'Animation Delay (seconed)', 'zoomarts' ),
	"param_name" 				=> "delay",
	"value" 					=> "0.0",
	"dependency" 				=> Array('element' => "check_animation", 'not_empty' => true)
));

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"heading" 					=> "<hr/><br/>".__( 'Background Type', 'zoomarts' ),
	"param_name" 				=> "background_type",
	"value" 					=> array(
		__( 'Color', 'zoomarts' ) 		=> "color_bg",
		__( 'Image', 'zoomarts' ) 		=> "image_bg",
		__( 'Video', 'zoomarts' ) 		=> "video_bg",
	),
));

vc_add_param("vc_column", array(
	"type" 						=> "colorpicker",
	"heading" 					=> __( 'Background Color', 'zoomarts' ),
	"param_name" 				=> "background_color",
	"value" 					=> "",
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('color_bg')),
));

vc_add_param("vc_column", array(
	"type" 						=> "attach_image",
	"heading" 					=> __( 'Background Image', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "background_image",
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('image_bg')),
));

vc_add_param("vc_column", array(
	"type" 						=> "colorpicker",
	"class" 					=> "",
	"heading" 					=> __( 'Background Overlay Color', 'zoomarts' ),
	"param_name" 				=> "background_overlay_color",
	"value" 					=> "",
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('image_bg', 'video_bg')),
));

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"heading" 					=> __( 'Background Position', 'zoomarts' ),
	"param_name" 				=> "background_position",
	"value" 					=> array(
		"" 										=> "",
		__( 'Left Top', 'zoomarts' ) 		=> "left top",
  		__( 'Left Center', 'zoomarts' ) 		=> "left center",
  		__( 'Left Bottom', 'zoomarts' ) 		=> "left bottom",
  		__( 'Center Top', 'zoomarts' ) 		=> "center top",
  		__( 'Center Center', 'zoomarts' ) 	=> "center center",
  		__( 'Center Bottom', 'zoomarts' ) 	=> "center bottom",
  		__( 'Right Top', 'zoomarts' ) 		=> "right top",
  		__( 'Right Center', 'zoomarts' ) 	=> "right center",
  		__( 'Right Bottom', 'zoomarts' ) 	=> "right bottom"
	),
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"class"	 					=> "",
	"heading" 					=> __( 'Background Repeat', 'zoomarts' ),
	"param_name" 				=> "background_repeat",
	"value" 					=> array(
		__( 'No Repeat', 'zoomarts' ) 	=> "no-repeat",
		__( 'Repeat', 'zoomarts' ) 		=> "repeat"
	),
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_column", array(
	"type" 						=> "checkbox",
	"heading" 					=> __( 'Cover Background', 'zoomarts' ),
	"value" 					=> array("Background Size (Cover)" => "true" ),
	"param_name" 				=> "cover_background",
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_column", array(
	"type" 						=> "checkbox",
	"heading" 					=> __( 'Background Attachment', 'zoomarts' ),
	"value" 					=> array("Fixed" => "true" ),
	"param_name" 				=> "background_attachment",
	"dependency" 				=> array('element' => "background_image", 'not_empty' => true),
));

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"heading" 					=> __( 'Background Effect', 'zoomarts' ),
	"param_name" 				=> "background_effect",
	"value" 					=> array(
		"" 				=> "",
		"Parallax" 		=> "parallax",
		"Crossfade" 	=> "crossfade",
		"Animation" 	=> "animation"
	),
	"dependency" 				=> array( 'element' => "background_type", 'value' => array('image_bg')),
));

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"class" 					=> "",
	"heading" 					=> __( 'Background Animations', 'zoomarts' ),
	"param_name" 				=> "background_animation",
	"value" 					=> array(
		__( 'Moving To Top', 'zoomarts' ) 		=> "animate-top",
		__( 'Moving To Bottom', 'zoomarts' )		=> "animate-bottom",
		__( 'Moving To Right', 'zoomarts' ) 		=> "animate-right",
		__( 'Moving To Left', 'zoomarts' ) 		=> "animate-left",
		__( 'Zoom In-Out', 'zoomarts' ) 			=> "animate-zoom",
		__( 'Zoom With Rotate', 'zoomarts' )		=> "animate-zoom-rotate",
	),
	"dependency" 				=> array( 'element' => "background_effect", 'value' => array('animation')),
));

vc_add_param("vc_column", array(
	"type" 						=> "attach_image",
	"heading" 					=> __( 'CrossFade End Image', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "crossfade_end_image",
	"dependency" 				=> array( 'element' => "background_effect", 'value' => array('crossfade')),
));

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"show_settings_on_create" 	=> true,
	"heading" 					=> __( 'Video Type', 'zoomarts' ),
	"param_name" 				=> "video_type",
	"value" 					=> array(
		__( 'Youtube Video', 'zoomarts' ) 		=> "youtube",
		__( 'Self Hosted Video', 'zoomarts' ) 	=> "self-hosted",
	),
	"dependency" 				=> array('element' => "background_type", 'value' => array('video_bg'))
));

vc_add_param("vc_column", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'Youtube Video URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=>  "youtube_url",
	"description" 				=> __( 'Insert your youtube video URL.', 'zoomarts' ).'<strong>http://youtu.be/fH_jchqoFcA</strong>',
	"dependency" 				=> array('element' => "video_type", 'value' => array('youtube'))
));

vc_add_param("vc_column", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'WebM File URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_webm",
	"description" 				=> "You must include this format & the mp4 format to render your video with cross browser compatibility, OGV is optional.
Video must be in a 16:9 aspect ratio",
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

vc_add_param("vc_column", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'MP4 File URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_mp4",
	"description" 				=> __( 'Enter the URL for your mp4 video file here', 'zoomarts' ),
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

vc_add_param("vc_column", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'OGV File URL', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_ogv",
	"description" 				=> __( 'Enter the URL for your ogv video file here', 'zoomarts' ),
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

vc_add_param("vc_column", array(
	"type" 						=> "attach_image",
	"class" 					=> "",
	"heading" 					=> __( 'Video Poster Image', 'zoomarts' ),
	"value" 					=> "",
	"param_name" 				=> "video_poster",
	"description" 				=> __( 'This image will be a background for this section on mobiles', 'zoomarts' ),
	"dependency" 				=> array('element' => "video_type", 'value' => array('self-hosted'))
));

/*vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"class" 					=> "",
	"heading" 					=> "<hr/><br/>Elements Color",
	"param_name" 				=> "elements_color",
	"value" 					=> array(
		"Light" 	=> "light-section",
		"Dark" 		=> "dark-section",
	),
));*/

vc_add_param("vc_column", array(
	"type" 						=> "dropdown",
	"heading" 					=> "<hr/><br/>".__( 'Text Align?', 'zoomarts' ),
	"param_name" 				=> "text_align",
	'description' 				=> __( 'Select text alignment', 'zoomarts' ),
	"value" 					=> array(
		__( 'Left', 'zoomarts' ) 		=> "left",
		__( 'Right', 'zoomarts' ) 		=> "right",
		__( 'Center', 'zoomarts' ) 		=> "center",
		__( 'Justify', 'zoomarts' ) 		=> "justify",
	),
));

vc_add_param("vc_column_inner", array(
	"type" 						=> "dropdown",
	"heading" 					=> "<hr/><br/>".__( 'Text Align?', 'zoomarts' ),
	"param_name" 				=> "text_align",
	'description' 				=> __( 'Select text alignment', 'zoomarts' ),
	"value" 					=> array(
		__( 'Left', 'zoomarts' ) 		=> "left",
		__( 'Right', 'zoomarts' ) 		=> "right",
		__( 'Center', 'zoomarts' ) 		=> "center",
		__( 'Justify', 'zoomarts' ) 		=> "justify",
	),
));

vc_add_param("vc_column", array(
	"type" 						=> "colorpicker",
	"class" 					=> "",
	"heading" 					=> __( 'Text Color', 'zoomarts' ),
	"param_name"		 		=> "text_color",
	"value" 					=> "",
));


// Tabs Shortcode
vc_add_param("vc_tabs", array(
	"type" 						=> "dropdown",
	"heading" 					=> "<hr/><br/>".__( 'Tabs Style', 'zoomarts' ),
	"param_name" 				=> "style",
	"value" 					=> array(
		__( 'Style 1', 'zoomarts' ) 		=> "style-1",
		__( 'Style 2', 'zoomarts' ) 		=> "style-2",
		__( 'Style 3', 'zoomarts' ) 		=> "style-3",
	),
));


// Accordions Shortcode
vc_add_param("vc_accordion", array(
	"type" 						=> "dropdown",
	"heading" 					=> "<hr/><br/>".__( 'Accordion Style', 'zoomarts' ),
	"param_name" 				=> "style",
	"value" 					=> array(
		__( 'Style 1', 'zoomarts' ) 		=> "style-1",
		__( 'Style 2', 'zoomarts' ) 		=> "style-2",
	),
));


// Accordions tabs Shortcode
vc_add_param("vc_accordion_tab", array(
	"type" 						=> "textfield",
	"heading" 					=> __( 'Icon', 'zoomarts' ),
	"param_name" 				=> "icon",
));


// Buttons Shortcode
vc_map( array(
	"name" 			=> __( 'Button', 'zoomarts' ),
	"base" 			=> "za_button",
	"icon" 			=> "icon-wpb-ui-button",
	"category" 		=> "by ZoOmArts",
	"description" 	=> __( 'Add a nice button', 'zoomarts' ),
	"params" 		=> array(
		array(
			"type" 				=> "textfield",
			"heading" 			=> __( 'Button Caption', 'zoomarts' ),
			"admin_label" 		=> true,
			"param_name" 		=> "caption",
			"value" 			=> __( 'Nice Button', 'zoomarts' ),
		),
		array(
			"type" 				=> "textfield",
			"heading" 			=> __( 'Icon', 'zoomarts' ),
			"param_name" 		=> "icon",
		),
		array(
			"type" 				=> "checkbox",
			"heading" 			=> __( 'Only Display Icon On Mouse Hover', 'zoomarts' ),
			"param_name" 		=> "animate_icon",
			"value" 			=> array(
				"" 		=> "animate_icon"
			)
		),
		array(
			"type" 				=> "textfield",
			"heading" 			=> "<hr/><br/>".__( 'Link URL', 'zoomarts' ),
			"param_name" 		=> "link",
		),
		array(
			"type" 				=> "dropdown",
			"heading" 			=> __( 'Open link in', 'zoomarts' ),
			"param_name" 		=> "link_target",
			"value" 			=> $target_arr,
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "dropdown",
			"heading" 			=> __( 'Custom Font Family?', 'zoomarts' ),
			"param_name" 		=> "font_family",
			'description' 		=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
			"value" 			=> $custom_fonts,
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "dropdown",
			"heading" 			=> __( 'Text Transform', 'zoomarts' ),
			"param_name" 		=> "text_transform",
			"value" 			=> array(
				'' 											=> '',
				__( 'Lowercase', 'zoomarts' ) 			=> 'lowercase',
				__( 'Capitalize', 'zoomarts' ) 			=> 'capitalize',
				__( 'Uppercase', 'zoomarts' ) 			=> 'uppercase',
			),
		),
		array(
			"group" 			=> "Styling",
			'type' 				=> 'textfield',
			'heading' 			=> __( 'Font Size', 'zoomarts' ),
			'param_name' 		=> 'font_size',
			'description' 		=> __( 'Enter font size. (pixels)', 'zoomarts' ),
		),
		array(
			"group" 			=> "Styling",
			'type' 				=> 'textfield',
			'heading' 			=> __( 'Letter Spacing', 'zoomarts' ),
			'param_name' 		=> 'letter_spacing',
			'description' 		=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "textfield",
			"heading" 			=> "<hr/><br/>".__( 'Button Padding Top/Bottom (pixels)', 'zoomarts' ),
			"param_name" 		=> "padding_vert",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "textfield",
			"heading" 			=> __( 'Button Padding Left/Right (pixels)', 'zoomarts' ),
			"param_name" 		=> "padding_horz",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "textfield",
			"heading" 			=> __( 'Border Width (pixels)', 'zoomarts' ),
			"param_name" 		=> "border_width",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "textfield",
			"heading" 			=> __( 'Border Radius (pixels)', 'zoomarts' ),
			"param_name" 		=> "border_radius",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "colorpicker",
			"heading" 			=> "<hr/><br/>".__( 'Text Color', 'zoomarts' ),
			"param_name" 		=> "text_color",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Background Color', 'zoomarts' ),
			"param_name" 		=> "bg_color",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Border Color', 'zoomarts' ),
			"param_name" 		=> "border_color",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Text Color (hover)', 'zoomarts' ),
			"param_name" 		=> "text_color_hover",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Background Color (hover)', 'zoomarts' ),
			"param_name" 		=> "bg_color_hover",
		),
		array(
			"group" 			=> "Styling",
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Border Color (hover)', 'zoomarts' ),
			"param_name" 		=> "border_color_hover",
		),
	),
) );


// Team Members Shortcode
vc_map( array(
    "name" 				=> __( 'Team Member', 'zoomarts' ),
    "base" 				=> 'za_team_member',
    "description" 		=> __( 'Add Team Member', 'zoomarts' ),
    "icon" 				=> "za_ourteam",
    "category" 			=> "by ZoOmArts",
    'admin_enqueue_css' => array(get_template_directory_uri().'/css/vc-extend.css'),
    "params"			=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Style', 'zoomarts' ),
			"param_name" 			=> "member_style",
			"value" 				=> array(
				__( 'Default Style', 'zoomarts' ) 		=> "default-style",
				__( 'Boxed Style', 'zoomarts' ) 			=> "boxed-style",
			),
		),	
		array(
			'type' 					=> 'attach_image',
			'heading' 				=> __( 'Team Memeber Image', 'zoomarts' ),
			'param_name' 			=> 'member_img',
			'value'					=> '',
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Team Memeber Name', 'zoomarts' ),
			'param_name' 			=> 'member_name',
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Team Memeber Custom Link (URL)', 'zoomarts' ),
			'param_name' 			=> 'member_link',
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Open link in', 'zoomarts' ),
			"param_name" 			=> "link_target",
			"value" 				=> $target_arr,
			"dependency" 				=> array('element' => "member_link", 'not_empty' => true),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Team Memeber Position', 'zoomarts' ),
			'param_name' 			=> 'member_position',
		),
		array(
			'type' 					=> 'textarea',
			'heading' 				=> __( 'Team Memeber Description', 'zoomarts' ),
			'param_name' 			=> 'member_desc',
			"dependency" 			=> array( 'element' => "member_style", 'value' => array('default-style')),
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Social Icon 1', 'zoomarts' ),
			"param_name" 			=> "member_social_1",
			"value" 				=> $social_icons_array,
		),
		array(
			"type" 					=> "textfield",
			"heading" 				=> __( 'Social Icon 1 Link', 'zoomarts' ),
			"param_name" 			=> "member_social_1_link"
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Social Icon 2', 'zoomarts' ),
			"param_name" 			=> "member_social_2",
			"value" 				=> $social_icons_array,
		),
		array(
			"type" 					=> "textfield",
			"heading" 				=> __( 'Social Icon 2 Link', 'zoomarts' ),
			"param_name" 			=> "member_social_2_link"
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Social Icon 3', 'zoomarts' ),
			"param_name" 			=> "member_social_3",
			"value" 				=> $social_icons_array,
		),
		array(
			"type" 					=> "textfield",
			"heading" 				=> __( 'Social Icon 3 Link', 'zoomarts' ),
			"param_name" 			=> "member_social_3_link"
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Social Icon 4', 'zoomarts' ),
			"param_name" 			=> "member_social_4",
			"value" 				=> $social_icons_array,
		),
		array(
			"type" 					=> "textfield",
			"heading" 				=> __( 'Social Icon 4 Link', 'zoomarts' ),
			"param_name" 			=> "member_social_4_link"
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Social Icon 5', 'zoomarts' ),
			"param_name" 			=> "member_social_5",
			"value" 				=> $social_icons_array,
		),
		array(
			"type" 					=> "textfield",
			"heading" 				=> __( 'Social Icon 5 Link', 'zoomarts' ),
			"param_name" 			=> "member_social_5_link"
		),
	),
) );


// Social Icons Shortcode
vc_map( array(
    "name" 						=> __( 'Social Icons', 'zoomarts' ),
    "base" 						=> 'za_social_icons',
    "description" 				=> __( 'Add Social Icons', 'zoomarts' ),
    "icon" 						=> "za_social",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'za_social_icon'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> false,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(),
) );

// Social Icon Shortcode
vc_map( array(
    "name" 						=> __( 'Social Icon', 'zoomarts' ),
    "base" 						=> 'za_social_icon',
    "description" 				=> __( 'Add Social Icon', 'zoomarts' ),
    "icon" 						=> "za_social",
    "category" 					=> "by ZoOmArts",
    "content_element" 			=> true,
    "as_child" 					=> array('only' => 'za_social_icons'),
    "params" 					=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Icon', 'zoomarts' ),
			"admin_label" 			=> true,
			"param_name" 			=> "social_icon",
			"value" 				=> $social_icons_array,
		),
		array(
			"type" 					=> "textfield",
			"heading" 				=> __( 'Social Icon Link', 'zoomarts' ),
			"param_name" 			=> "social_icon_link"
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Open link in', 'zoomarts' ),
			"param_name" 	=> "link_target",
			"value" 		=> $target_arr,
		),
    ),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Social_Icons extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Social_Icon extends WPBakeryShortCode {
    }
}


// Pie Charts Shortcode
vc_map( array(
    "name" 				=> __( 'Pie Chart', 'zoomarts' ),
    "base" 				=> 'za_pie_chart',
    "description" 		=> __( 'Add Circle Pie Chart', 'zoomarts' ),
    "icon" 				=> "za_pie_chart",
    "category" 			=> "by ZoOmArts",
    "params" 			=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Pie Chart Type', 'zoomarts' ),
			"param_name" 			=> "type",
			"value"					=> array(
				__( 'Icon', 'zoomarts' )				=> "icon",
				__( 'Text', 'zoomarts' )				=> "text",
				__( 'Icon & Text', 'zoomarts' )		=> "iconText",
				__( 'Number & Text', 'zoomarts' )	=> "numberText",
			),
		),	
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Pie Chart Percent', 'zoomarts' ),
			'param_name' 			=> 'percent',
		),
    	array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Pie Chart Color', 'zoomarts' ),
			"param_name" 			=> "color",
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Pie Chart Width & Height', 'zoomarts' ),
			'param_name' 			=> 'width',
		),	
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Line Width', 'zoomarts' ),
			'param_name' 			=> 'line_width',
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Pie Chart Number', 'zoomarts' ),
			'param_name' 			=> 'number',
			"description" 			=> __( 'You can also using symbols.', 'zoomarts' ),
			"dependency" 			=> array( 'element' => "type", 'value' => array('numberText')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Icon Class', 'zoomarts' ),
			'param_name' 			=> 'icon',
			"dependency" 			=> array( 'element' => "type", 'value' => array('icon','iconText')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Pie Chart Text', 'zoomarts' ),
			'param_name' 			=> 'text',
			"dependency" 			=> array( 'element' => "type", 'value' => array('text','iconText','numberText')),
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> "<hr/><br/>".__( 'Custom Font Family?', 'zoomarts' ),
			"param_name" 			=> "font_family",
			'description' 			=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
			"value" 				=> $custom_fonts,
			"dependency" 			=> array( 'element' => "type", 'value' => array('text','iconText','numberText')),
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Text Transform', 'zoomarts' ),
			"param_name" 			=> "text_transform",
			"value" 				=> array(
				'' 											=> '',
				__( 'Lowercase', 'zoomarts' ) 			=> 'lowercase',
				__( 'Capitalize', 'zoomarts' ) 			=> 'capitalize',
				__( 'Uppercase', 'zoomarts' ) 			=> 'uppercase',
			),
			"dependency" 			=> array( 'element' => "type", 'value' => array('text','iconText','numberText')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Letter Spacing', 'zoomarts' ),
			'param_name' 			=> 'letter_spacing',
			'description' 			=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
			"dependency" 			=> array( 'element' => "type", 'value' => array('text','iconText','numberText')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Font Size ( For Number )', 'zoomarts' ),
			'param_name' 			=> 'number_font_size',
			'description' 			=> __( 'Enter font size. (pixels)', 'zoomarts' ),
			"dependency" 			=> array( 'element' => "type", 'value' => array('numberText')),
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Number Color', 'zoomarts' ),
			"param_name" 			=> "number_color",
			"dependency" 			=> array( 'element' => "type", 'value' => array('numberText')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Font Size ( For Text )', 'zoomarts' ),
			'param_name' 			=> 'text_font_size',
			'description' 			=> __( 'Enter font size. (pixels)', 'zoomarts' ),
			"dependency" 			=> array( 'element' => "type", 'value' => array('text','iconText','numberText')),
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Text Color', 'zoomarts' ),
			"param_name" 			=> "text_color",
			"dependency" 			=> array( 'element' => "type", 'value' => array('text','iconText','numberText')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Font Size ( For Icon )', 'zoomarts' ),
			'param_name' 			=> 'icon_font_size',
			'description' 			=> __( 'Enter font size. (pixels)', 'zoomarts' ),
			"dependency" 			=> array( 'element' => "type", 'value' => array('icon','iconText')),
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Icon Color', 'zoomarts' ),
			"param_name" 			=> "icon_color",
			"dependency" 			=> array( 'element' => "type", 'value' => array('icon','iconText')),
		),
		array(
            'type' 					=> 'css_editor',
            'heading' 				=> __( 'Css', 'zoomarts' ),
            'param_name' 			=> 'css',
            'group' 				=> __( 'Design options', 'zoomarts' )
        )
	),
) );


// Flip Boxes Shortcode
vc_map( array(
    "name" 						=> __( 'Flip Box', 'zoomarts' ),
    "base" 						=> 'za_flip_box',
    "description" 				=> __( 'Add Flip Box', 'zoomarts' ),
    "icon" 						=> "za_flip_box",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'za_front_content, za_back_content'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> false,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(),
) );

// Flip Boxes Shortcode
vc_map( array(
    "name" 						=> __( 'Front Content', 'zoomarts' ),
    "base" 						=> 'za_front_content',
    "description" 				=> __( 'Add a Front Content', 'zoomarts' ),
    "icon" 						=> "za_flip_box",
    "category" 					=> "by ZoOmArts",
    "content_element" 			=> true,
    "as_child" 					=> array('only' => 'za_flip_box'),
    "params" 					=> array(
    	array(
			'type' 					=> 'textarea_html',
			'heading' 				=> __( 'Front Content', 'zoomarts' ),
			'param_name' 			=> 'content',
		),
    	array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Front Background Color', 'zoomarts' ),
			"param_name" 			=> "front_bg",
		),
	),
) );

// Flip Box Shortcode
vc_map( array(
    "name" 					=> __( 'Back Content', 'zoomarts' ),
    "base" 					=> 'za_back_content',
    "description" 			=> __( 'Add a Back Content', 'zoomarts' ),
    "icon" 					=> "za_flip_box",
    "category" 				=> "by ZoOmArts",
    "content_element" 		=> true,
    "as_child" 				=> array('only' => 'za_flip_box'),
    "params" 				=> array(
    	array(
			'type' 					=> 'textarea_html',
			'heading' 				=> __( 'Back Content', 'zoomarts' ),
			'param_name' 			=> 'content',
			'value' 				=> '<p>I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>'
		),
    	array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Back Background Color', 'zoomarts' ),
			"param_name" 			=> "back_bg",
		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Flip_Box extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Back_Content extends WPBakeryShortCode {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Front_Content extends WPBakeryShortCode {
    }
}


// Image Boxes Shortcode
vc_map( array(
    "name" 						=> __( 'Image Box', 'zoomarts' ),
    "base" 						=> 'za_image_box',
    "description" 				=> __( 'Add Image Box', 'zoomarts' ),
    "icon" 						=> "za_gallery",
    "as_parent" 				=> array('only' => 'za_image_box_front, za_image_box_back'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> true,
    "js_view" 					=> 'VcColumnView',
    "category" 					=> "by ZoOmArts",
    "params" 					=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Front/Back Content', 'zoomarts' ),
			"param_name" 			=> "type",
			"value" 				=> array(
				__( 'Front Only', 'zoomarts' )			=> "front-only",
				__( 'Front & Back', 'zoomarts' )			=> "front-back",
			),
		),	
    	array(
			'type' 					=> 'attach_image',
			'heading' 				=> __( 'Image', 'zoomarts' ),
			'param_name' 			=> 'image',
			'value' 				=> '',
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'OverLay Color', 'zoomarts' ),
			"param_name" 			=> "overlay_color",
		),
	),
) );

// Image Box Shortcode
vc_map( array(
    "name" 				=> __( 'Front Content', 'zoomarts' ),
    "base" 				=> 'za_image_box_front',
    "description" 		=> __( 'Add a Front Content', 'zoomarts' ),
    "icon" 				=> "za_gallery",
    "category" 			=> "by ZoOmArts",
    "content_element" 	=> true,
    "as_child" 			=> array('only' => 'za_image_box'),
    "params" 			=> array(
    	array(
			'type' 					=> 'textarea_html',
			'heading' 				=> __( 'Front Content', 'zoomarts' ),
			'param_name' 			=> 'content',
		),
	),
) );

// Image Box Shortcode
vc_map( array(
    "name" 				=> __( 'Back Content', 'zoomarts' ),
    "base" 				=> 'za_image_box_back',
    "description" 		=> __( 'Add a Back Content', 'zoomarts' ),
    "icon" 				=> "za_gallery",
    "category" 			=> "by ZoOmArts",
    "content_element" 	=> true,
    "as_child" 			=> array('only' => 'za_image_box'),
    "params"			=> array(
    	array(
			'type' 					=> 'textarea_html',
			'heading' 				=> __( 'Back Content', 'zoomarts' ),
			'param_name' 			=> 'content',
			'value' 				=> '<p>I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>'
		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Image_Box extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Image_Box_Front extends WPBakeryShortCode {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Image_Box_Back extends WPBakeryShortCode {
    }
}


// Parallax Layers Shortcode
vc_map( array(
    "name" 						=> __( 'Layers Parallax', 'zoomarts' ),
    "base" 						=> 'za_multilayer_parallax',
    "description" 				=> __( 'Add a Multilayer Parallax', 'zoomarts' ),
    "icon" 						=> "za_multilayer_parallax",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'za_layer_parallax'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> false,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(),
) );

// Parallax Layer Shortcode
vc_map( array(
    "name" 						=> __( 'Layer Parallax', 'zoomarts' ),
    "base" 						=> 'za_layer_parallax',
    "description"			 	=> __( 'Add a Layer Parallax', 'zoomarts' ),
    "icon" 						=> "za_multilayer_parallax",
    "category" 					=> "by ZoOmArts",
    "content_element" 			=> true,
    "as_child" 					=> array('only' => 'za_multilayer_parallax'),
    "params" 					=> array(
    	array(
			'type' 					=> 'attach_image',
			'heading' 				=> __( 'Layer Background', 'zoomarts' ),
			'param_name' 			=> 'bg_img',
			'description' 			=> __( 'Upload image for this layer', 'zoomarts' ),
		),
    	array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Layer Depth', 'zoomarts' ),
			'param_name' 			=> 'depth',
			'description' 			=> __( 'The depth of a layer within a parallax scene', 'zoomarts' ),
		),
		array(
			'type' 					=> 'dropdown',
			'heading' 				=> __( 'Background Position', 'zoomarts' ),
			'param_name' 			=> 'bg_position',
			'value' 				=> array(
				'' 										=> '',
				__( 'Left Top', 'zoomarts' ) 		=> "left top",
		  		__( 'Left Center', 'zoomarts' ) 		=> "left center",
		  		__( 'Left Bottom', 'zoomarts' ) 		=> "left bottom",
		  		__( 'Center Top', 'zoomarts' ) 		=> "center top",
		  		__( 'Center Center', 'zoomarts' ) 	=> "center center",
		  		__( 'Center Bottom', 'zoomarts' ) 	=> "center bottom",
		  		__( 'Right Top', 'zoomarts' ) 		=> "right top",
		  		__( 'Right Center', 'zoomarts' ) 	=> "right center",
		  		__( 'Right Bottom', 'zoomarts' ) 	=> "right bottom"
			),
		),
		array(
			'type' 					=> 'dropdown',
			'heading' 				=> __( 'Background Repeat', 'zoomarts' ),
			'param_name' 			=> 'bg_repeat',
			'value' 				=> array(
				__( 'No Repeat', 'zoomarts' ) 		=> "no-repeat",
				__( 'Repeat', 'zoomarts' ) 			=> "repeat"
			),
		),
		array(
			'type' 					=> 'checkbox',
			'heading' 				=> __( 'Background Size', 'zoomarts' ),
			'param_name' 			=> 'bg_cover',
			'value' 				=> array(
				__( 'Cover', 'zoomarts' )			=> 'cover'
			),
		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Multilayer_Parallax extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Layer_Parallax extends WPBakeryShortCode {
    }
}


// Clients Shortcode
vc_map( array(
    "name" 						=> __( 'Clients', 'zoomarts' ),
    "base" 						=> 'za_clients',
    "description" 				=> __( 'Add Clients Logos"', 'zoomarts' ),
    "icon" 						=> "za_clients",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'za_client'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> true,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Clients Layout', 'zoomarts' ),
			"param_name" 			=> "clients_layout",
			"value" 				=> array(
				__( 'Grid', 'zoomarts' ) 			=> "grid-layout",
				__( 'Carousel', 'zoomarts' ) 		=> "carousel-layout",
			),
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Clients Layout (columns X rows)', 'zoomarts' ),
			"param_name" 			=> "clients_grid_layout",
			"value" 				=> array(
				"2 X 1" 								=> "2-1",
				"3 X 1" 								=> "3-1",
				"4 X 1" 								=> "4-1",
				"5 X 1" 								=> "5-1",
				"2 X 2" 								=> "2-2",
				"3 X 2" 								=> "3-2",
				"4 X 2" 								=> "4-2",
				"5 X 2" 								=> "5-2",
			),
			"dependency" 			=> array( 'element' => "clients_layout", 'value' => array('grid-layout')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Items Number For Desktop', 'zoomarts' ),
			'param_name' 			=> 'clients_items_desktop',
			"dependency" 			=> array( 'element' => "clients_layout", 'value' => array('carousel-layout')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Items Number For Tablet', 'zoomarts' ),
			'param_name' 			=> 'clients_items_tablet',
			"dependency" 			=> array( 'element' => "clients_layout", 'value' => array('carousel-layout')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Items Number For Mobile', 'zoomarts' ),
			'param_name' 			=> 'clients_items_mobile',
			"dependency" 			=> array( 'element' => "clients_layout", 'value' => array('carousel-layout')),
		),
	),
) );

// Client Shortcode
vc_map( array(
    "name" 					=> __( 'Client', 'zoomarts' ),
    "base" 					=> 'za_client',
    "description" 			=> __( 'Add Client Logo', 'zoomarts' ),
    "icon" 					=> "za_clients",
    "category" 				=> "by ZoOmArts",
    "content_element" 		=> true,
    "as_child" 				=> array('only' => 'za_clients'),
    "params" 				=> array(
    	array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Client Name', 'zoomarts' ),
			'param_name' 			=> 'client_name',
			"admin_label" 			=> true,
		),
		array(
			'type' 					=> 'checkbox',
			'heading' 				=> __( 'Enable Tooltip Effect', 'zoomarts' ),
			'param_name' 			=> 'client_tooltip',
			'value' 				=> array( __( 'Enable', 'zoomarts' ) => 'true' )
		),
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> "<hr/><br/>".__( 'Client Style', 'zoomarts' ),
			"param_name" 			=> "client_style",
			"value" 				=> array(
				__( 'Basic', 'zoomarts' )				=> "basic",
				__( 'Boxed Border', 'zoomarts' )			=> "boxed-border",
				__( 'oxed Background', 'zoomarts' )		=> "boxed-background",
				__( 'Fancy Divider', 'zoomarts' )		=> "fancy-divider",
			),
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Background Color', 'zoomarts' ),
			"param_name" 			=> "client_bg",
			"value" 				=> "rgba(0,0,0,0.1)",
			"dependency" 			=> array( 'element' => "client_style", 'value' => array('boxed-background')),
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Divider Color', 'zoomarts' ),
			"param_name" 			=> "client_divider",
			"value" 				=> "rgba(0,0,0,0.1)",
			"dependency" 			=> array( 'element' => "client_style", 'value' => array('fancy-divider')),
		),
		array(
			"type" 					=> "colorpicker",
			"class" 				=> "",
			"heading" 				=> __( 'Border Color', 'zoomarts' ),
			"param_name" 			=> "client_border",
			"value" 				=> "rgba(0,0,0,0.1)",
			"dependency" 			=> array( 'element' => "client_style", 'value' => array('boxed-border')),
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Client URL', 'zoomarts' ),
			'param_name' 			=> 'client_url',
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Open link in', 'zoomarts' ),
			"param_name" 			=> "link_target",
			"value" 				=> $target_arr,
		),
		array(
			'type' 					=> 'attach_image',
			'heading' 				=> __( 'Client Image', 'zoomarts' ),
			'param_name' 			=> 'client_img',
		),
		array(
			'type' 					=> 'attach_image',
			'heading' 				=> __( 'Client Image (hover)', 'zoomarts' ),
			'param_name' 			=> 'client_img_hover',
		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Clients extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Client extends WPBakeryShortCode {
    }
}


// Lists Shortcode
vc_map( array(
    "name" 						=> __( 'List', 'zoomarts' ),
    "base" 						=> 'za_list',
    "description" 				=> __( 'Add List', 'zoomarts' ),
    "icon" 						=> "za_list",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'za_list_item, za_list_item_icon'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> true,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'List Type', 'zoomarts' ),
			"param_name" 			=> "list_type",
			"value" 				=> array(
				__( 'Ordered List', 'zoomarts' )			=> "ordered_list",
				__( 'Unordered List', 'zoomarts' )		=> "unordered-list",
				__( 'Icons List', 'zoomarts' )			=> "icons-list",
			),
		),
	),
) );

// List Item Shortcode
vc_map( array(
    "name" 				=> __( 'List Item', 'zoomarts' ),
    "base" 				=> 'za_list_item',
    "description" 		=> __( 'Add an Ordered or Unordered list item', 'zoomarts' ),
    "icon" 				=> "za_list",
    "category" 			=> "by ZoOmArts",
    "content_element" 	=> true,
    "as_child" 			=> array('only' => 'za_list'),
    "params" 			=> array(
    	array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'List Item Text', 'zoomarts' ),
			'param_name' 			=> 'text',
		),
	),
) );

// List Item Shortcode
vc_map( array(
    "name" 				=> __( 'List Item With Icon', 'zoomarts' ),
    "base" 				=> 'za_list_item_icon',
    "description" 		=> __( 'Add an icon list item', 'zoomarts' ),
    "icon" 				=> "za_list",
    "category" 			=> "by ZoOmArts",
    "content_element" 	=> true,
    "as_child" 			=> array('only' => 'za_list'),
    "params" 			=> array(
    	array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'List Item Text', 'zoomarts' ),
			'param_name' 			=> 'text',
		),
		array(
			'type' 					=> 'textfield',
			'heading' 				=> __( 'Icon Name', 'zoomarts' ),
			'param_name' 			=> 'icon',
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Icon Color', 'zoomarts' ),
			"param_name" 			=> "icon_color",
			"value"					=> "#bbbbbb",
		),
		array(
			"type" 					=> "colorpicker",
			"heading" 				=> __( 'Text Color', 'zoomarts' ),
			"param_name" 			=> "text_color",
			"value"					=> "#666666",
		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_List extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_List_item extends WPBakeryShortCode {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_List_Item_Icon extends WPBakeryShortCode {
    }
}


// Gallery Shortcode
vc_map( array(
    "name" 						=> __( 'Gallery', 'zoomarts' ),
    "base" 						=> 'za_gallery',
    "description" 				=> __( 'Add Gallery Grid', 'zoomarts' ),
    "icon" 						=> "za_gallery",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'za_gallery_item'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> true,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Columns', 'zoomarts' ),
			"param_name" 			=> "columns",
			"value" 				=> array(
				__( '2 Columns', 'zoomarts' ) 				=> "cols-2",
				__( '3 Columns', 'zoomarts' ) 				=> "cols-3",
				__( '4 Columns', 'zoomarts' ) 				=> "cols-4",
				__( '5 Columns', 'zoomarts' ) 				=> "cols-5",
				__( '6 Columns', 'zoomarts' ) 				=> "cols-6",
			),
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Spaces', 'zoomarts' ),
			"param_name" 			=> "spaces",
			"value" 				=> array(
				__( 'True', 'zoomarts' )						=> "spaces-true",
				__( 'False', 'zoomarts' ) 					=> "spaces-false",
			),
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Hover Style', 'zoomarts' ),
			"param_name" 			=> "style",
			"value" 				=> array(
				__( 'Style 1', 'zoomarts' ) 					=> "style-1",
				__( 'Style 2', 'zoomarts' ) 					=> "style-2",
				__( 'Style 3', 'zoomarts' ) 					=> "style-3",
			),
		),
	),
) );

// Gallery Item Shortcode
vc_map( array(
    "name" 				=> __( 'Gallery Item', 'zoomarts' ),
    "base" 				=> 'za_gallery_item',
    "description" 		=> __( 'Add gallery image', 'zoomarts' ),
    "icon" 				=> "za_gallery",
    "content_element" 	=> true,
    "as_child" 			=> array('only' => 'za_list'),
    "params" 			=> array(
    	array(
			'type' 				=> 'attach_image',
			'heading' 			=> __( 'Image', 'zoomarts' ),
			'param_name' 		=> 'image',
			'value' 			=> '',
			'description' 		=> __( 'Select images from media library', 'zoomarts' )
		),
		array(
			'type' 				=> 'textfield',
			'heading' 			=> __( 'Caption', 'zoomarts' ),
			'param_name' 		=> 'caption',
		),
		array(
			'type' 				=> 'textfield',
			'heading' 			=> __( 'Custom Link', 'zoomarts' ),
			'param_name' 		=> 'custom_link',
			'description' 		=> __( 'Enter you custom link (Leave this field empty if you need to open image with lightbox)', 'zoomarts' )

		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Gallery extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Gallery_Item extends WPBakeryShortCode {
    }
}


// Single Image Shortcode
vc_map( array(
    "name" 			=> __( 'Single Image', 'zoomarts' ),
    "base" 			=> 'za_single_image',
    "description" 	=> __( 'Add Single Image', 'zoomarts' ),
    "icon" 			=> "icon-wpb-single-image",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Hover Style', 'zoomarts' ),
			"param_name" 			=> "style",
			"value" 				=> array(
				__( 'Style 1', 'zoomarts' )		=> "style-1",
				__( 'Style 2', 'zoomarts' )		=> "style-2",
			),
		),
		array(
			'type' 					=> 'attach_image',
			'heading' 				=> __( 'Image', 'zoomarts' ),
			'param_name' 			=> 'image',
			'value' 				=> '',
			'description' 			=> __( 'Select image from media library.', 'zoomarts' )
		),
		array(
			'type' 					=> 'checkbox',
			'heading' 				=> __( 'Lightbox', 'zoomarts' ),
			'param_name' 			=> 'lightbox',
			'value' 				=> array( __( 'Yes', 'zoomarts' ) => 'true' )
		),
		array(
			"type" 					=> "textfield",
			"heading" 				=> __( 'Custom Link URL', 'zoomarts' ),
			"param_name" 			=> "link",
		),
		array(
			"type" 					=> "dropdown",
			"heading" 				=> __( 'Open link in', 'zoomarts' ),
			"param_name" 			=> "link_target",
			"value" 				=> $target_arr,
			"dependency" 			=> array('element' => "link", 'not_empty' => true),
		),
	),
) );


// Progress Bars Shortcode
vc_map( array(
    "name" 			=> __( 'Progress Bar', 'zoomarts' ),
    "base" 			=> 'za_progress_bar',
    "description" 	=> __( 'Add Anmation Progress Bar', 'zoomarts' ),
    "icon" 			=> "za_progress_bar",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 				=> "dropdown",
			"heading" 			=> __( 'Progress Bar Type', 'zoomarts' ),
			"param_name"		=> "type",
			"value" 			=> array(
				__( 'Default', 'zoomarts' ) 				=> "default",
				__( 'Striped', 'zoomarts' ) 				=> "striped",
				__( 'Striped & Animation', 'zoomarts' ) 	=> "striped-animation",
			),
		),
		array(
			"type" 				=> "textfield",
			"heading" 			=> __( 'Progress Bar Height', 'zoomarts' ),
			"param_name" 		=> "height",
			'description' 		=> __( 'Enter progress bar heigh. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 				=> 'textfield',
    		"param_name" 		=> "border_radius",
    		"heading" 			=> __( 'Progress Bar Border Radius', 'zoomarts' ),
			'description' 		=> __( 'Enter progress bar border radius. (pixels)', 'zoomarts' ),
		),
    	array(
			'type' 				=> 'textfield',
			'heading' 			=> __( 'Progress Bar Percent', 'zoomarts' ),
			'param_name' 		=> 'percent',
		),
		array(
			'type' 				=> 'textfield',
			'heading' 			=> __( 'Progress Bar Text', 'zoomarts' ),
			'param_name' 		=> 'text',
			'holder' 			=> 'div',
		),
		array(
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Progress Bar Color', 'zoomarts' ),
			"param_name" 		=> "color",
		),
	),
) );


// Icons Shortcode
vc_map( array(
    "name" 			=> __( 'Icon', 'zoomarts' ),
    "base" 			=> 'za_custom_icon',
    "description" 	=> __( 'Add Image/Font Icon"', 'zoomarts' ),
    "icon" 			=> "za_icon",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Link URL', 'zoomarts' ),
			"param_name" 	=> "link",
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Open link in', 'zoomarts' ),
			"param_name" 	=> "link_target",
			"value" 		=> $target_arr,
		),
    	array(
			"type" 				=> "dropdown",
			"heading" 			=> "<hr/><br/>".__( 'Icon Type', 'zoomarts' ),
			"param_name" 		=> "type",
			"value" 			=> array(
				__( 'Font Icon', 'zoomarts' ) 			=> "font-icon",
				__( 'Image Icon', 'zoomarts' ) 			=> "image-icon",
			),
		),
		array(
			'type' 				=> 'attach_image',
			'heading' 			=> __( 'Icon Image', 'zoomarts' ),
			'param_name' 		=> 'image_icon',
			'value'				=> '',
			"dependency" 		=> array( 'element' => "type", 'value' => array('image-icon')),
		),
		array(
			'type' 				=> 'textfield',
    		"param_name" 		=> "font_icon",
    		"heading" 			=> __( 'Icon', 'zoomarts' ),
			'description' 		=> __( 'You can use font icon from our collection or <a href="http://fontawesome.io/icons/">FontAwesome</a>', 'zoomarts' ),
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 				=> 'textfield',
    		"param_name" 		=> "width_heigh",
    		"heading" 			=> "<hr/><br/>".__( 'Icon Width/Heigh', 'zoomarts' ),
			'description' 		=> __( 'Enter icon block Width/Heigh. (pixels)', 'zoomarts' ),
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 				=> 'textfield',
    		"param_name" 		=> "font_size",
    		"heading" 			=> __( 'Font Size', 'zoomarts' ),
			'description' 		=> __( 'Enter icon font size. (pixels)', 'zoomarts' ),
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 				=> 'textfield',
    		"param_name" 		=> "border_width",
    		"heading" 			=> __( 'Border Width', 'zoomarts' ),
			'description' 		=> __( 'Enter icon block border width. (pixels)', 'zoomarts' ),
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 				=> 'textfield',
    		"param_name" 		=> "border_radius",
    		"heading" 			=> __( 'Border Radius', 'zoomarts' ),
			'description' 		=> __( 'Enter icon block border radius. (pixels)', 'zoomarts' ),
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 				=> "colorpicker",
			"heading" 			=> "<hr/><br/>".__( 'Icon Color', 'zoomarts' ),
			"param_name" 		=> "icon_color",
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Icon Background Color', 'zoomarts' ),
			"param_name" 		=> "bg_color",
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Icon Border Color', 'zoomarts' ),
			"param_name" 		=> "border_color",
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 				=> "colorpicker",
			"heading" 			=> "<hr/><br/>".__( 'Icon Color (Hover)', 'zoomarts' ),
			"param_name" 		=> "color_hover",
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Icon Background Color (Hover)', 'zoomarts' ),
			"param_name" 		=> "bg_color_hover",
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 				=> "colorpicker",
			"heading" 			=> __( 'Icon Border Color (Hover)', 'zoomarts' ),
			"param_name" 		=> "border_color_hover",
			"dependency" 		=> array( 'element' => "type", 'value' => array('font-icon')),
		),
	),
) );


// Side Icon Box Shortcode
vc_map( array(
    "name" 						=> __( 'Icon Box', 'zoomarts' ),
    "base" 						=> 'za_icon_box',
    "description" 				=> __( 'Add icon box', 'zoomarts' ),
    "icon" 						=> "za_icon",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'vc_column_text, za_divider, za_custom_font, za_button'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> true,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Icon Box Style', 'zoomarts' ),
			"param_name" 	=> "style",
			"value" 		=> array(
				__( 'Boxed Style', 'zoomarts' ) 			=> "boxed-style",
				__( 'Side Icon Style', 'zoomarts' ) 		=> "side-icon-style",
			),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Icon Box (Border Color)', 'zoomarts' ),
			"param_name" 	=> "box_border_color",
			"dependency" 	=> array( 'element' => "style", 'value' => array('boxed-style'))
		),
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Icon Side', 'zoomarts' ),
			"param_name" 	=> "side",
			"value" 		=> array(
				__( 'Left', 'zoomarts' )					=> "left-side",
				__( 'Right', 'zoomarts' ) 				=> "right-side",
			),
			"dependency" 	=> array( 'element' => "style", 'value' => array('side-icon-style')),
		),	
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Icon Type', 'zoomarts' ),
			"param_name" 	=> "type",
			"value" 		=> array(
				__( 'Image Icon', 'zoomarts' ) 			=> "image-icon",
				__( 'Font Icon', 'zoomarts' ) 			=> "font-icon",
			),
		),
		array(
			'type' 			=> 'attach_image',
			'heading' 		=> __( 'Icon Image', 'zoomarts' ),
			'param_name' 	=> 'image_icon',
			'value'			=> '',
			"dependency" 	=> array( 'element' => "type", 'value' => array('image-icon')),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "font_icon",
    		"heading" 		=> __( 'Icon', 'zoomarts' ),
			'description' 	=> __( 'You can use font icon from our collection or <a href="http://fontawesome.io/icons/">FontAwesome</a>', 'zoomarts' ),
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "width_heigh",
    		"heading" 		=> "<hr/><br/>".__( 'Icon Width/Heigh', 'zoomarts' ),
			'description' 	=> __( 'Enter icon block Width/Heigh. (pixels)', 'zoomarts' ),
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "font_size",
    		"heading" 		=> __( 'Font Size', 'zoomarts' ),
			'description' 	=> __( 'Enter icon font size. (pixels)', 'zoomarts' ),
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "border_width",
    		"heading" 		=> __( 'Border Width', 'zoomarts' ),
			'description' 	=> __( 'Enter icon block border width. (pixels)', 'zoomarts' ),
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "border_radius",
    		"heading" 		=> __( 'Border Radius', 'zoomarts' ),
			'description' 	=> __( 'Enter icon block border radius. (pixels)', 'zoomarts' ),
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> "<hr/><br/>".__( 'Icon Color', 'zoomarts' ),
			"param_name" 	=> "icon_color",
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Icon Background Color', 'zoomarts' ),
			"param_name" 	=> "bg_color",
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Icon Border Color', 'zoomarts' ),
			"param_name" 	=> "border_color",
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> "<hr/><br/>".__( 'Icon Color (Hover)', 'zoomarts' ),
			"param_name" 	=> "color_hover",
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Icon Background Color (Hover)', 'zoomarts' ),
			"param_name" 	=> "bg_color_hover",
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Icon Border Color (Hover)', 'zoomarts' ),
			"param_name" 	=> "border_color_hover",
			"dependency" 	=> array( 'element' => "type", 'value' => array('font-icon')),
		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Icon_Box extends WPBakeryShortCodesContainer {
    }
}


// Touch Sliders Shortcode
vc_map( array(
    "name" 			=> __( 'Touch Slider', 'zoomarts' ),
    "base" 			=> 'za_touch_slider',
    "description" 	=> __( 'Add Touchable Slider', 'zoomarts' ),
    "icon" 			=> "za_touch_slider",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Auto Height', 'zoomarts' ),
			"param_name" 	=> "auto_height",
			"value" 		=> array(
				__( 'True', 'zoomarts' )				=> "true",
				__( 'False', 'zoomarts' ) 			=> "false",
			),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Dots', 'zoomarts' ),
			"param_name" 	=> "dots",
			"value" 		=> array(
				__( 'True', 'zoomarts' )				=> "true",
				__( 'False', 'zoomarts' ) 			=> "false",
			),
			'description' 	=> __( 'Select to show Navigation Dots.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Animation In', 'zoomarts' ),
			"param_name" 	=> "animation_in",
			"value" 		=> $slider_animations_in_array,
			'description' 	=> __( 'Select CSS3 animation in for this slider.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Animation Out', 'zoomarts' ),
			"param_name" 	=> "animation_out",
			"value" 		=> $slider_animations_out_array,
			'description' 	=> __( 'Select CSS3 animation out for this slider.', 'zoomarts' )
		),
		array(
			'type' 			=> 'attach_images',
			'heading' 		=> __( 'Images', 'zoomarts' ),
			'param_name' 	=> 'images',
			'value' 		=> '',
			'description' 	=> __( 'Select images from media library.', 'zoomarts' )
		),
	),
) );


// Tweets Slider Shortcode
vc_map( array(
    "name" 			=> __( 'Tweets Slider', 'zoomarts' ),
    "base" 			=> 'za_tweets_slider',
    "description" 	=> __( 'Add Tweets Slider', 'zoomarts' ),
    "icon" 			=> "za_tweets",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Twitter Username', 'zoomarts' ),
			'param_name' 	=> 'username',
		),
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Tweets Number', 'zoomarts' ),
			'param_name' 	=> 'count',
		),
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Navigation Arrows', 'zoomarts' ),
			"param_name" 	=> "arrows_nav",
			"value" 		=> array(
				__( 'False', 'zoomarts' ) 				=> "false",
				__( 'True', 'zoomarts' )					=> "true",
			),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Arrows Style', 'zoomarts' ),
			"param_name" 	=> "arrows_nav_style",
			"value" 		=> array(
				__( 'Light', 'zoomarts' ) 				=> "nav-light",
				__( 'Dark', 'zoomarts' )					=> "nav-dark",
			),
			"dependency" 	=> array( 'element' => "arrows_nav", 'value' => array('true')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Dots', 'zoomarts' ),
			"param_name" 	=> "dots_nav",
			"value" 		=> array(
				__( 'False', 'zoomarts' ) 				=> "false",
				__( 'True', 'zoomarts' )					=> "true",
			),
			'description' 	=> __( 'Select to show Navigation Dots.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Dots Style', 'zoomarts' ),
			"param_name" 	=> "dots_nav_style",
			"value" 		=> array(
				__( 'Light', 'zoomarts' ) 				=> "nav-light",
				__( 'Dark', 'zoomarts' )					=> "nav-dark",
			),
			"dependency" 	=> array( 'element' => "dots_nav", 'value' => array('true')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Animation In', 'zoomarts' ),
			"param_name" 	=> "animation_in",
			"value" 		=> $slider_animations_in_array,
			'description' 	=> __( 'Select CSS3 animation in for this slider.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Animation Out', 'zoomarts' ),
			"param_name" 	=> "animation_out",
			"value" 		=> $slider_animations_out_array,
			'description' 	=> __( 'Select CSS3 animation out for this slider.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Custom Font Family?', 'zoomarts' ),
			"param_name" 	=> "font_family",
			'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
			"value" 		=> $custom_fonts,
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Text Transform', 'zoomarts' ),
			"param_name" 	=> "text_transform",
			"value" 		=> array(
				'' 											=> '',
				__( 'Lowercase', 'zoomarts' ) 			=> 'lowercase',
				__( 'Capitalize', 'zoomarts' ) 			=> 'capitalize',
				__( 'Uppercase', 'zoomarts' ) 			=> 'uppercase',
			),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Font Size', 'zoomarts' ),
			'param_name' 	=> 'font_size',
			'description' 	=> __( 'Enter font size. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Line Height', 'zoomarts' ),
			'param_name' 	=> 'line_height',
			'description' 	=> __( 'Enter line height. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Letter Spacing', 'zoomarts' ),
			'param_name' 	=> 'letter_spacing',
			'description' 	=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Color', 'zoomarts' ),
			"param_name" 	=> "color",
		),
	),
) );


// Mockups Slider Shortcode
vc_map( array(
    "name" 			=> __( 'Mockups Slider', 'zoomarts' ),
    "base" 			=> 'za_mockups_slider',
    "description" 	=> __( 'Add Device Mockups Slider', 'zoomarts' ),
    "icon" 			=> "za_mockups_slider",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Device', 'zoomarts' ),
			"param_name" 	=> "device",
			"value" 		=> array(
				__( 'iPhone', 'zoomarts' ) 				=> "iphone6",
				__( 'iPad', 'zoomarts' ) 				=> "ipad",
				__( 'iMac', 'zoomarts' ) 				=> "imac",
				__( 'MacBook Pro', 'zoomarts' ) 			=> "macbook",
				__( 'Galaxy S5', 'zoomarts' ) 			=> "s5",
				__( 'Lumia930', 'zoomarts' ) 			=> "lumia_930",
			),
		),
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Orientation', 'zoomarts' ),
			"param_name" 	=> "orientation",
			"value" 		=> array(
				__( 'Portrait', 'zoomarts' ) 			=> "portrait",
				__( 'Landscape', 'zoomarts' ) 			=> "landscape",
			),
			"dependency" 	=> array( 'element' => "device", 'value' => array('iphone6', 'ipad', 's5', 'lumia930')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Color', 'zoomarts' ),
			"param_name" 	=> "color",
			"value" 		=> array(
				__( 'Black', 'zoomarts' ) 				=> "black",
				__( 'White', 'zoomarts' ) 				=> "white",
				__( 'Gold', 'zoomarts' ) 				=> "gold",
			),
			"dependency" 	=> array( 'element' => "device", 'value' => array('iphone6', 'ipad', 's5', 'lumia930')),
		),
		array(
			'type' 			=> 'attach_images',
			'heading' 		=> __( 'Images', 'zoomarts' ),
			'param_name' 	=> 'images',
			'value' 		=> '',
			'description' 	=> __( 'Select images from media library.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Dots', 'zoomarts' ),
			"param_name" 	=> "dots",
			"value" 		=> array(
				__( 'True', 'zoomarts' ) 				=> "true",
				__( 'False', 'zoomarts' ) 				=> "false",
			),
			'description' 	=> __( 'Select to show Navigation Dots.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Animation In', 'zoomarts' ),
			"param_name" 	=> "animation_in",
			"value" 		=> $slider_animations_in_array,
			'description' 	=> __( 'Select CSS3 animation in for this slider.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Animation Out', 'zoomarts' ),
			"param_name" 	=> "animation_out",
			"value" 		=> $slider_animations_out_array,
			'description' 	=> __( 'Select CSS3 animation out for this slider.', 'zoomarts' )
		),
	),
) );


// Latest Posts Shortcode
vc_map( array(
    "name" 			=> __( 'Latest Posts', 'zoomarts' ),
    "base" 			=> 'za_latest_posts',
    "description" 	=> __( 'The Most Recent Blog Posts', 'zoomarts' ),
    "icon" 			=> "za_latest_posts",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Latest Posts Style', 'zoomarts' ),
			"param_name" 	=> "type",
			"value" 		=> array(
				__( 'Classic Style', 'zoomarts' ) 		=> "classic-style",
				__( 'Sections Style', 'zoomarts' ) 		=> "sections-style",
			),
		),
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Posts Number', 'zoomarts' ),
			'param_name' 	=> 'num',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Columns', 'zoomarts' ),
			"param_name" 	=> "classic_cols",
			"value" 		=> array(
				__( '1 Column', 'zoomarts' ) 			=> "cols-1",
				__( '2 Column', 'zoomarts' ) 			=> "cols-2",
				__( '3 Column', 'zoomarts' ) 			=> "cols-3",
				__( '4 Column', 'zoomarts' ) 			=> "cols-4",
				__( '5 Column', 'zoomarts' ) 			=> "cols-5",
			),
			"dependency" 	=> array( 'element' => 'type', 'value' => array('classic-style')),
		),
	),
) );


// Latest Projects Shortcode
vc_map( array(
    "name" 			=> __( 'Latest Projects', 'zoomarts' ),
    "base" 			=> 'za_latest_projects',
    "description" 	=> __( 'The Most Recent Projects', 'zoomarts' ),
    "icon" 			=> "za_latest_projects",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			'type' 			=> 'textfield',
			"heading" 		=> __( 'Custom Categories by ID', 'zoomarts' ),
			"param_name" 	=> "custom_cats_id",
			'description' 	=> __( 'Enter your custom categories ids. (Optional)', 'zoomarts' ).' <strong>| '.__( 'Example: 6, 7, 11', 'zoomarts' ).'</strong>'
		),
		array(
			'type' 			=> 'textfield',
			"heading" 		=> __( 'Custom Categories by Name', 'zoomarts' ),
			"param_name" 	=> "custom_cats_name",
			'description' 	=> __( 'Enter your custom categories names. (Optional)', 'zoomarts' ).' <strong>| '.__( 'Example: Print, Desgin, Paint', 'zoomarts' ).'</strong>'
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> "<hr/><br/>".__( 'Order By', 'zoomarts' ),
			'param_name' 	=> 'orderby',
			'value' 		=> array(
				'',
				__( 'Date', 'zoomarts' )					=> 'date',
				__( 'ID', 'zoomarts' )					=> 'ID',
				__( 'Author', 'zoomarts' )				=> 'author',
				__( 'Title', 'zoomarts' ) 				=> 'title',
				__( 'Modified', 'zoomarts' ) 			=> 'modified',
				__( 'Random', 'zoomarts' ) 				=> 'rand',
			),
			'description' 	=> sprintf( __( 'Select how to sort retrieved projects. More at %s.', 'zoomarts' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __( 'Order Way', 'zoomarts' ),
			'param_name' 	=> 'order',
			'value' 		=> $order_way_values,
			'description' 	=> sprintf( __( 'Designates the ascending or descending order. More at %s.', 'zoomarts' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Layout', 'zoomarts' ),
			"param_name" 	=> "layout",
			"value" 		=> array(
				__( 'Grid', 'zoomarts' ) 				=> "grid-layout",
				__( 'Masonry', 'zoomarts' ) 				=> "masonry-layout",
				__( 'Multi-Size Masonry', 'zoomarts' ) 	=> "masonry-multisize-layout",
			),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Projects Columns', 'zoomarts' ),
			"param_name" 	=> "columns",
			"value" 		=> array(
				__( '2 Columns', 'zoomarts' ) 			=> "2",
				__( '3 Columns', 'zoomarts' ) 			=> "3",
				__( '4 Columns', 'zoomarts' ) 			=> "4",
				__( '5 Columns', 'zoomarts' ) 			=> "5",
				__( '6 Columns', 'zoomarts' ) 			=> "6",
			),
			"dependency" 	=> array( 'element' => "layout", 'value' => array('grid-layout', 'masonry-layout')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Projects Spaces', 'zoomarts' ),
			"param_name" 	=> "spaces",
			"value" 		=> array(
				__( 'no-space', 'zoomarts' ) 			=> "space-false",
				__( 'space', 'zoomarts' ) 				=> "space-true",
			),
			"dependency" 	=> array( 'element' => "layout", 'value' => array('grid-layout', 'masonry-layout')),
		),
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Projects Style', 'zoomarts' ),
			"param_name" 	=> "style",
			"value" 		=> array(
				__( 'Style 1', 'zoomarts' ) 				=> "style-1",
				__( 'Style 2', 'zoomarts' ) 				=> "style-2",
				__( 'Style 3', 'zoomarts' ) 				=> "style-3",
				__( 'Style 4', 'zoomarts' ) 				=> "style-4",
				__( 'Style 5', 'zoomarts' ) 				=> "style-5",
				__( 'Style 6', 'zoomarts' ) 				=> "style-6",
				__( 'Style 7', 'zoomarts' ) 				=> "style-7",
				__( 'Style 8', 'zoomarts' ) 				=> "style-8",
				__( 'Style 9', 'zoomarts' ) 				=> "style-9",
				__( 'Style 10', 'zoomarts' ) 			=> "style-10",
			),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Projects Number', 'zoomarts' ),
			'param_name' 	=> 'num',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Portfolio Filters', 'zoomarts' ),
			"param_name" 	=> "filter_btns",
			"value" 		=> array(
				__( 'False', 'zoomarts' ) 			=> "false",
				__( 'True', 'zoomarts' ) 			=> "true",
			)
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Portfolio Filters Orderby', 'zoomarts' ),
			"param_name" 	=> "filter_orderby",
			"value" 		=> array(
				__('Name (default)', 'zoomarts')		=> "name",
				__('ID', 'zoomarts') 					=> "ID",
				__('Slug', 'zoomarts') 					=> "slug",
				__('Count', 'zoomarts') 				=> "count",
			),
			"dependency" 	=> array( 'element' => "filter_btns", 'value' => array('true')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Portfolio Filters Order', 'zoomarts' ),
			"param_name" 	=> "filter_order",
			"value" 		=> array(
				__('Ascending (default)', 'zoomarts')	=> "ASC",
				__('Descending', 'zoomarts')			=> "DESC",
			),
			"dependency" 	=> array( 'element' => "filter_btns", 'value' => array('true')),
		),
	),
) );


// Latest Projects Carousel Shortcode
vc_map( array(
    "name"			=> __( 'Latest Projects Carousel', 'zoomarts' ),
    "base"			=> 'za_latest_projects_carousel',
    "description"	=> __( 'The Most Recent Projects Carousel', 'zoomarts' ),
    "icon"			=> "za_latest_projects",
    "category"		=> "by ZoOmArts",
    "params"		=> array(
    	array(
			'type' 			=> 'textfield',
			"heading" 		=> __( 'Custom Category', 'zoomarts' ),
			"param_name" 	=> "custom_category",
			'description' 	=> __( 'Enter your custom category id or name. (Optional)', 'zoomarts' )
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __( 'Order By', 'zoomarts' ),
			'param_name' 	=> 'orderby',
			'value' 		=> array(
				'',
				__( 'Date', 'zoomarts' )					=> 'date',
				__( 'ID', 'zoomarts' )					=> 'ID',
				__( 'Author', 'zoomarts' )				=> 'author',
				__( 'Title', 'zoomarts' ) 				=> 'title',
				__( 'Modified', 'zoomarts' ) 			=> 'modified',
				__( 'Random', 'zoomarts' ) 				=> 'rand',
			),
			'description' 	=> sprintf( __( 'Select how to sort retrieved projects. More at %s.', 'zoomarts' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __( 'Order Way', 'zoomarts' ),
			'param_name' 	=> 'order',
			'value' 		=> $order_way_values,
			'description' 	=> sprintf( __( 'Designates the ascending or descending order. More at %s.', 'zoomarts' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
		),
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Projects Style', 'zoomarts' ),
			"param_name" 	=> "style",
			"value" 		=> array(
				__( 'Style 1', 'zoomarts' ) 				=> "style-1",
				__( 'Style 2', 'zoomarts' ) 				=> "style-2",
				__( 'Style 3', 'zoomarts' ) 				=> "style-3",
				__( 'Style 4', 'zoomarts' ) 				=> "style-4",
				__( 'Style 5', 'zoomarts' ) 				=> "style-5",
				__( 'Style 6', 'zoomarts' ) 				=> "style-6",
				__( 'Style 7', 'zoomarts' ) 				=> "style-7",
				__( 'Style 8', 'zoomarts' ) 				=> "style-8",
				__( 'Style 9', 'zoomarts' ) 				=> "style-9",
				__( 'Style 10', 'zoomarts' ) 			=> "style-10",
			),
		),
		/*array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Project Size', 'zoomarts' ),
			"param_name" 	=> "size",
			"value" 		=> array(
				__( 'Default', 'zoomarts' ) 				=> "default",
				__( 'Hight', 'zoomarts' ) 				=> "high",
			),
		),*/
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Projects Number', 'zoomarts' ),
			'param_name' 	=> 'num',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Carousel Navigation?', 'zoomarts' ),
			"param_name" 	=> "nav",
			"value" 		=> array(
				__( 'False', 'zoomarts' ) 				=> "false",
				__( 'True', 'zoomarts' ) 				=> "true",
			)
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Style', 'zoomarts' ),
			"param_name" 	=> "nav_style",
			"value" 		=> array(
				__( 'Light', 'zoomarts' ) 				=> "nav-light",
				__( 'Dark', 'zoomarts' ) 				=> "nav-dark",
			),
			"dependency" 	=> array( 'element' => "nav", 'value' => array('true')),
		),
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Carousel Margin', 'zoomarts' ),
			'param_name' 	=> 'carousel_margin',
			'description' 	=> __( 'Margin Between Items', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Carousel Padding', 'zoomarts' ),
			'param_name' 	=> 'carousel_padding',
			'description' 	=> __( 'Padding left and right on stage.', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Carousel Items For Desktop', 'zoomarts' ),
			'param_name' 	=> 'items_desktop',
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Carousel Items For Tablet', 'zoomarts' ),
			'param_name' 	=> 'items_tablet',
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Carousel Items For Mobile', 'zoomarts' ),
			'param_name' 	=> 'items_mobile',
		),
	),
) );


// Dividers Shortcode
vc_map( array(
    "name" 			=> __( 'Divider', 'zoomarts' ),
    "base" 			=> 'za_divider',
    "description" 	=> __( 'Add Dividers and Spaces', 'zoomarts' ),
    "icon" 			=> "za_divider",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Divider Style', 'zoomarts' ),
			"param_name" 	=> "style",
			"value"			=> array(
				__( 'Empty Space', 'zoomarts' )			=> "empty-space",
				__( 'Solid Line', 'zoomarts' ) 			=> "solid-line",
				__( 'Dotted Line', 'zoomarts' ) 			=> "dotted-line",
				__( 'Linear Gradient', 'zoomarts' ) 		=> "linear-gradient"
			),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Margin Top (pixels)', 'zoomarts' ),
			'param_name' 	=> 'margin_top',
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Margin Bottom (pixels)', 'zoomarts' ),
			'param_name' 	=> 'margin_bottom',
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Divider Width (pixels or percents)', 'zoomarts' ),
			'param_name' 	=> 'width',
			"value" 		=> '100%',
			"dependency" 	=> array( 'element' => "style", 'value' => array('solid-line', 'dotted-line', 'linear-gradient')),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Divider Height (pixels)', 'zoomarts' ),
			'param_name' 	=> 'height',
			"value" 		=> '1px',
			"dependency" 	=> array( 'element' => "style", 'value' => array('solid-line', 'dotted-line', 'linear-gradient')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Divider Position', 'zoomarts' ),
			"param_name" 	=> "position",
			"value" 		=> array(
				__( 'Left', 'zoomarts' ) 				=> "left",
				__( 'Right', 'zoomarts' ) 				=> "right",
				__( 'Center', 'zoomarts' ) 				=> "center",
			),
			"dependency" 	=> array( 'element' => "style", 'value' => array('solid-line', 'dotted-line', 'linear-gradient')),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Color', 'zoomarts' ),
			"param_name" 	=> "color",
			"dependency" 	=> array( 'element' => "style", 'value' => array('solid-line', 'dotted-line', 'linear-gradient')),
		),
	),
) );


// Login Form Shortcode
vc_map( array(
    "name" 			=> __( 'Login Form', 'zoomarts' ),
    "base" 			=> 'za_login_form',
    "description" 	=> __( 'Add Login Form', 'zoomarts' ),
    "icon" 			=> "za_login",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Inputs Text Color', 'zoomarts' ),
			"param_name" 	=> "inputs_text_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Inputs Background Color', 'zoomarts' ),
			"param_name" 	=> "inputs_bg_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Inputs Border Color', 'zoomarts' ),
			"param_name" 	=> "inputs_border_color",
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Inputs Border Radius', 'zoomarts' ),
			'param_name' 	=> 'inputs_border_radius',
			'value'			=> '0px',
		),
	),
) );


// Registration Form Shortcode 
vc_map( array(
    "name" 			=> __( 'Registration Form', 'zoomarts' ),
    "base" 			=> 'za_registration_form',
    "description" 	=> __( 'Add Registration Form', 'zoomarts' ),
    "icon" 			=> "za_login",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Inputs Text Color', 'zoomarts' ),
			"param_name" 	=> "inputs_text_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Inputs Background Color', 'zoomarts' ),
			"param_name" 	=> "inputs_bg_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Inputs Border Color', 'zoomarts' ),
			"param_name" 	=> "inputs_border_color",
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Inputs Border Radius', 'zoomarts' ),
			'param_name' 	=> 'inputs_border_radius',
			'value'			=> '0px',
		),
	),
) );


// Google Maps Shortcode
vc_map( array(
    "name" 			=> __( 'Google Map', 'zoomarts' ),
    "base" 			=> 'za_gmap',
    "description" 	=> __( 'Google Map Block', 'zoomarts' ),
    "icon" 			=> "za_map",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Map Width', 'zoomarts' ),
			'param_name' 	=> 'width',
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Map Height', 'zoomarts' ),
			'param_name' 	=> 'height',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Custom Style', 'zoomarts' ),
			"param_name" 	=> "style",
			"value" 		=> array(
				'',
				__( 'Shades of Grey', 'zoomarts' ) 		=> "1",
				__( 'Simple & Light', 'zoomarts' ) 		=> "2",
				__( 'Pinkish Gray', 'zoomarts' ) 		=> "3",
				__( 'A Dark World', 'zoomarts' ) 		=> "4",
				__( 'Blue water', 'zoomarts' ) 			=> "5",
				__( 'Blue Essence', 'zoomarts' ) 		=> "6",
				__( 'Apple Maps-esque', 'zoomarts' ) 	=> "7",
				__( 'Pale Dawn', 'zoomarts' ) 			=> "8",
				__( 'Paper', 'zoomarts' ) 				=> "9",
				__( 'Cool Grey', 'zoomarts' ) 			=> "10",
				__( 'Flat', 'zoomarts' ) 				=> "11",
				__( 'Green and Blue', 'zoomarts' )		=> "12",
				__( 'Lemon Tree', 'zoomarts' ) 			=> "13",
				__( 'Even Lighter', 'zoomarts' )			=> "14",
				__( 'Home of Puntcentric', 'zoomarts' )	=> "15",
				__( 'Red Hat Antwerp', 'zoomarts' )		=> "16",
				__( 'Elevation', 'zoomarts' )			=> "17",
				__( 'Light Grey & Blue', 'zoomarts' )	=> "18",
				__( 'Cristalize', 'zoomarts' ) 			=> "19",
				__( 'Old-School', 'zoomarts' ) 			=> "20",
				__( 'Canary', 'zoomarts' ) 				=> "21",
				__( 'Orange', 'zoomarts' ) 				=> "22",
				__( 'Marylebone Area', 'zoomarts' )		=> "23",
				__( 'WLSH', 'zoomarts' ) 				=> "24",
				__( 'Elyx Copper', 'zoomarts' ) 			=> "25",
				__( 'Orange Water', 'zoomarts' ) 		=> "26",
			),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Map Zoom', 'zoomarts' ),
			"param_name" 	=> "zoom",
			"value" 		=> array(
				"1" 				=> "1",
				"2" 				=> "2",
				"3" 				=> "3",
				"4" 				=> "4",
				"5" 				=> "5",
				"6" 				=> "6",
				"7" 				=> "7",
				"8" 				=> "8",
				"9"					=> "9",
				"10"				=> "10",
				"11"				=> "11",
				"12" 				=> "12",
				"13" 				=> "13",
				"14" 				=> "14",
				"15" 				=> "15",
				"16" 				=> "16",
				"17" 				=> "17",
				"18" 				=> "18",
			),
		),
		array(
			'type' 			=> 'attach_image',
			'heading' 		=> __( 'Marker Icon', 'zoomarts' ),
			'param_name' 	=> 'marker',
			'value'			=> '',
		),
	),
) );


// Custom Font Shortcode
vc_map( array(
    "name" 			=> __( 'Custom Font', 'zoomarts' ),
    "base" 			=> 'za_custom_font',
    "description" 	=> __( 'Add Text With Custom Font', 'zoomarts' ),
    "icon" 			=> "icon-wpb-ui-custom_heading",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
            'type' 			=> 'textarea_html',
            'heading' 		=> __( 'Text', 'zoomarts' ),
            'param_name' 	=> 'content',
            'admin_label' 	=> true,
            'value'			=> __( 'This is custom heading element with Google Fonts', 'zoomarts' ),
        ),
        array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Custom Style', 'zoomarts' ),
			"param_name" 	=> "style",
			'description' 	=> __( 'Choose style for this text.', 'zoomarts' ),
			"value" 		=> array(
				"" 										=> "",
				__( 'Style 1', 'zoomarts' ) 			=> "style-1",
				__( 'Style 2', 'zoomarts' ) 			=> "style-2",
			),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Borders Color', 'zoomarts' ),
			"param_name" 	=> "borders_color",
			"dependency" 	=> array( 'element' => "style", 'value' => array('style-1', 'style-2')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Custom Font Family?', 'zoomarts' ),
			"param_name" 	=> "font_family",
			'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
			"value" 		=> $custom_fonts,
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Element Tag', 'zoomarts' ),
			"param_name" 	=> "element_tag",
			'description' 	=> __( 'Select element tag.', 'zoomarts' ),
			"value" 		=> array(
				"h1" 										=> "h1",
				"h2"										=> "h2",
				"h3" 										=> "h3",
				"h4"										=> "h4",
				"h5" 										=> "h5",
				"h6" 										=> "h6",
				"p" 										=> "p",
				"div" 										=> "div",
				"span" 										=> "span",
			),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Text Align?', 'zoomarts' ),
			"param_name" 	=> "text_align",
			'description' 	=> __( 'Select text alignment.', 'zoomarts' ),
			"value" 		=> array(
				__( 'Left', 'zoomarts' ) 				=> "left",
				__( 'Right', 'zoomarts' ) 				=> "right",
				__( 'Center', 'zoomarts' ) 				=> "center",
				__( 'Justify', 'zoomarts' ) 				=> "justify",
			),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Font Size', 'zoomarts' ),
			'param_name' 	=> 'font_size',
			'description' 	=> __( 'Enter font size. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Line Height', 'zoomarts' ),
			'param_name' 	=> 'line_height',
			'description' 	=> __( 'Enter line height. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Letter Spacing', 'zoomarts' ),
			'param_name' 	=> 'letter_spacing',
			'description' 	=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Text Transform', 'zoomarts' ),
			"param_name" 	=> "text_transform",
			"value" 		=> array(
				'' 												=> '',
				__( 'Lowercase', 'zoomarts' ) 				=> 'lowercase',
				__( 'Capitalize', 'zoomarts' ) 				=> 'capitalize',
				__( 'Uppercase', 'zoomarts' ) 				=> 'uppercase',
			),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Color', 'zoomarts' ),
			"param_name" 	=> "color",
		),
        array(
            'type' 			=> 'css_editor',
            'heading' 		=> __( 'Css', 'zoomarts' ),
            'param_name' 	=> 'css',
            'group' 		=> __( 'Design options', 'zoomarts' )
        )
	),
) );


// Separator with Text Shortcode
vc_map( array(
    "name" 			=> __( 'Separator with Text', 'zoomarts' ),
    "base" 			=> 'za_text_separator',
    "description" 	=> __( 'Horizontal separator line with heading', 'zoomarts' ),
    "icon" 			=> "icon-wpb-ui-separator-label",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Title', 'zoomarts' ),
			'param_name' 	=> 'title',
			'holder' 		=> 'div',
			'value' 		=> __( 'Title', 'zoomarts' ),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Title position', 'zoomarts' ),
			"param_name" 	=> "title_align",
			'description' 	=> __( 'Select title location', 'zoomarts' ),
			"value" 		=> array(
				__( 'Center', 'zoomarts' ) 			=> "text-center",
				__( 'Left', 'zoomarts' )				=> "text-left",
				__( 'Right', 'zoomarts' ) 			=> "text-right",				
			),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Separator Color', 'zoomarts' ),
			"param_name" 	=> "separator_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Color', 'zoomarts' ),
			"param_name" 	=> "title_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Background', 'zoomarts' ),
			"param_name" 	=> "bg_color",
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __( 'Style', 'zoomarts' ),
			'param_name' 	=> 'style',
			'description' 	=> __( 'Separator style', 'zoomarts' ),
			"value" 		=> array(
				__( 'Solid', 'zoomarts' ) 			=> "solid",
				__( 'Dashed', 'zoomarts' ) 			=> "dashed",
				__( 'Dotted', 'zoomarts' ) 			=> "dotted",				
			),
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __( 'Element width', 'zoomarts' ),
			'param_name' 	=> 'separator_width',
			"value" 		=> array(
				'20%' 				=> '20%',
				'30%' 				=> '30%',
				'40%' 				=> '40%',
				'50%' 				=> '50%',
				'60%' 				=> '60%',
				'70%' 				=> '70%',
				'80%' 				=> '80%',
				'90%' 				=> '90%',
				'100%' 				=> '100%',
			),
			'description' 	=> __( 'Separator element width in percents.', 'zoomarts' )
		),
	),
) );


// 'Separator with Icon Shortcode
vc_map( array(
    "name" 			=> __( 'Separator with Icon', 'zoomarts' ),
    "base" 			=> 'za_icon_separator',
    "description" 	=> __( 'Horizontal separator line with icon', 'zoomarts' ),
    "icon" 			=> "icon-wpb-ui-separator-label",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Icon', 'zoomarts' ),
			'param_name' 	=> 'icon',
			'holder' 		=> 'div',
			'description' 	=> __( 'You can use font icon from our collection or <a href="http://fontawesome.io/icons/">FontAwesome</a>', 'zoomarts' ),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Separator Color', 'zoomarts' ),
			"param_name" 	=> "separator_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Icon Color', 'zoomarts' ),
			"param_name" 	=> "icon_color",
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __( 'Style', 'zoomarts' ),
			'param_name' 	=> 'style',
			'description' 	=> 'Separator style',
			"value" 		=> array(
				__( 'Solid', 'zoomarts' ) 			=> "solid",
				__( 'Dashed', 'zoomarts' ) 			=> "dashed",
				__( 'Dotted', 'zoomarts' ) 			=> "dotted",			
			),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Separator Width', 'zoomarts' ),
			'param_name' 	=> 'separator_width',
			"value" 		=> "45px",
			'description' 	=> __( 'Separator element width in pixels', 'zoomarts' )
		),
	),
) );


// Testimonials Slider Shortcode
vc_map( array(
    "name" 						=> __( 'Testimonials Slider', 'zoomarts' ),
    "base" 						=> 'za_testimonials_slider',
    "description" 				=> __( 'Add Testimonials Slider', 'zoomarts' ),
    "icon" 						=> "za_testimonial",
    "category" 					=> "by ZoOmArts",
    "as_parent" 				=> array('only' => 'za_testimonial'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> true,
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Arrows', 'zoomarts' ),
			"param_name" 	=> "arrows_nav",
			"value" 		=> array(
				__( 'False', 'zoomarts' ) 			=> "false",
				__( 'True', 'zoomarts' )				=> "true",
			),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Arrows Style', 'zoomarts' ),
			"param_name" 	=> "arrows_nav_style",
			"value" 		=> array(
				__( 'Light', 'zoomarts' ) 			=> "nav-light",
				__( 'Dark', 'zoomarts' )				=> "nav-dark",
			),
			"dependency" 	=> array( 'element' => "arrows_nav", 'value' => array('true')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Navigation Dots', 'zoomarts' ),
			"param_name" 	=> "dots_nav",
			"value" 		=> array(
				__( 'False', 'zoomarts' ) 			=> "false",
				__( 'True', 'zoomarts' )				=> "true",
			),
			'description' 	=> __( 'Select to show Navigation Dots.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Navigation Dots Style', 'zoomarts' ),
			"param_name" 	=> "dots_nav_style",
			"value" 		=> array(
				__( 'Light', 'zoomarts' ) 			=> "nav-light",
				__( 'Dark', 'zoomarts' )				=> "nav-dark",
			),
			"dependency" 	=> array( 'element' => "dots_nav", 'value' => array('true')),
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Animation In', 'zoomarts' ),
			"param_name" 	=> "animation_in",
			"value" 		=> $slider_animations_in_array,
			'description' 	=> __( 'Select CSS3 animation in for this slider.', 'zoomarts' )
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Animation Out', 'zoomarts' ),
			"param_name" 	=> "animation_out",
			"value" 		=> $slider_animations_out_array,
			'description' 	=> __( 'Select CSS3 animation out for this slider.', 'zoomarts' )
		),
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Testimonials_Slider extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Testimonial extends WPBakeryShortCode {
    }
}


// Testimonials Shortcode
vc_map( array(
    "name" 				=> __( 'Testimonial', 'zoomarts' ),
    "base" 				=> 'za_testimonial',
    "description" 		=> __( 'Add Testimonial', 'zoomarts' ),
    "icon" 				=> "za_testimonial",
    "category" 			=> "by ZoOmArts",
    "content_element" 	=> true,
    "as_child" 			=> array('except' => 'za_list'),
    "params" 			=> array(
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Author Name', 'zoomarts' ),
			'param_name' 	=> 'name',
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Author Job', 'zoomarts' ),
			'param_name' 	=> 'job',
		),
		array(
			'type' 			=> 'textarea',
			'heading' 		=> __( 'Testimonial Content', 'zoomarts' ),
			'param_name' 	=> 'testimonial_content',
		),
		array(
			'type' 			=> 'attach_image',
			'heading' 		=> __( 'Author Image', 'zoomarts' ),
			'param_name' 	=> 'img',
			'value'			=> '',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Custom Font Family?', 'zoomarts' ),
			"param_name" 	=> "font_family",
			'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
			"value" 		=> $custom_fonts,
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Text Transform', 'zoomarts' ),
			"param_name" 	=> "text_transform",
			"value" 		=> array(
				'' 											=> '',
				__( 'Lowercase', 'zoomarts' ) 			=> 'lowercase',
				__( 'Capitalize', 'zoomarts' ) 			=> 'capitalize',
				__( 'Uppercase', 'zoomarts' ) 			=> 'uppercase',
			),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Font Size', 'zoomarts' ),
			'param_name' 	=> 'font_size',
			'description' 	=> __( 'Enter font size. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Line Height', 'zoomarts' ),
			'param_name' 	=> 'line_height',
			'description' 	=> __( 'Enter line height. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Letter Spacing', 'zoomarts' ),
			'param_name' 	=> 'letter_spacing',
			'description' 	=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Color', 'zoomarts' ),
			"param_name" 	=> "color",
		),
	),
) );


// Call To Action Shortcode
vc_map( array(
    "name" 						=> __( 'Call To Action', 'zoomarts' ),
    "base" 						=> 'za_call_to_action',
    "description" 				=> __( 'Add Call To Action Section', 'zoomarts' ),
    "icon" 						=> "za_call_to_action",
    "as_parent" 				=> array('only' => 'za_custom_font, za_button'),
    "content_element" 			=> true,
    "show_settings_on_create" 	=> true,
    "js_view" 					=> 'VcColumnView',
    "category" 					=> "by ZoOmArts",
    "params" 					=> array(
    	array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Call To Action Style', 'zoomarts' ),
			"param_name" 	=> "style",
			"value" 		=> array(
				__( 'Creative Style', 'zoomarts' ) 	=> "creative-style",
				__( 'Classic Style', 'zoomarts' ) 	=> "classic-style"
			),
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Link URL', 'zoomarts' ),
			"param_name" 	=> "link",
			"dependency" 	=> array('element' => 'style', 'value' => 'creative-style')
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Open link in', 'zoomarts' ),
			"param_name" 	=> "link_target",
			"value" 		=> $target_arr,
			"dependency" 	=> array('element' => 'style', 'value' => 'creative-style')
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Background Color', 'zoomarts' ),
			"param_name" 	=> "bg_color",
			"dependency" 	=> array('element' => 'style', 'value' => 'creative-style')
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Background Hover Color', 'zoomarts' ),
			"param_name" 	=> "bg_hover_color",
			"dependency" 	=> array('element' => 'style', 'value' => 'creative-style')
		),
		array(
            'type' 			=> 'css_editor',
            'heading' 		=> __( 'Css', 'zoomarts' ),
            'param_name' 	=> 'css',
            'group' 		=> __( 'Design options', 'zoomarts' )
        )
	),
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Call_To_Action extends WPBakeryShortCodesContainer {
    }
}


// Pricing Tables Shortcode
vc_map( array(
    "name" 						=> __( 'Pricing Tables', 'zoomarts' ),
    "base" 						=> "za_pricing_tables",
    "as_parent" 				=> array('only' => 'za_pricing_table'),
    "content_element" 			=> true,
    "category" 					=> 'by ZoOmArts',
    "icon" 						=> "za_pricing_table",
    "show_settings_on_create" 	=> true,
    "description" 				=> __( 'Add Pricing Tables', 'zoomarts' ),
    "js_view" 					=> 'VcColumnView',
    "params" 					=> array(
        array(
            "type" 			=> "dropdown",
            "heading" 		=> __( 'Columns', 'zoomarts' ),
            "param_name" 	=> "columns",
            "value" 		=> array(
                __( 'Two', 'zoomarts' )       		=> "two_columns",
                __( 'Three', 'zoomarts' )     		=> "three_columns",
                __( 'Four', 'zoomarts' )      		=> "four_columns",
            ),
        ),
    ),
) );

// Pricing Table Shortcode
vc_map( array(
	"name" 						=> __( 'Pricing Table', 'zoomarts' ),
	"base" 						=> "za_pricing_table",
	"icon" 						=> "za_pricing_table",
	"category" 					=> 'by ZoOmArts',
	"description" 				=> __( 'Add Pricing Table', 'zoomarts' ),
	"allowed_container_element"	=> 'vc_row',
	"as_child"					=> array('only' => 'za_pricing_tables'),
	"params" 					=> array(
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Title', 'zoomarts' ),
			"param_name" 	=> "title",
			"value" 		=> __( 'Basic Plan', 'zoomarts' ),
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Price', 'zoomarts' ),
			"param_name" 	=> "price",
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Price Custom Font Family?', 'zoomarts' ),
			"param_name" 	=> "font_family",
			'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
			"value" 		=> $custom_fonts,
		),	
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Currency', 'zoomarts' ),
			"param_name" 	=> "currency",
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Price Period', 'zoomarts' ),
			"param_name" 	=> "price_period",
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Special Offer', 'zoomarts' ),
			"param_name" 	=> "special",
			"value" 		=> array(
				__( 'No', 'zoomarts' )				=> "no",
				__( 'Yes', 'zoomarts' ) 				=> "yes"
			),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Special Offer Color', 'zoomarts' ),
			"param_name" 	=> "special_color",
			"dependency" 	=> array('element' => 'special', 'value' => 'yes')
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Show Button', 'zoomarts' ),
			"param_name" 	=> "show_button",
			"value" 		=> array(
				__( 'No', 'zoomarts' )				=> "no",
				__( 'Yes', 'zoomarts' ) 				=> "yes"
			)
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Button Text', 'zoomarts' ),
			"param_name" 	=> "button_text",
			"dependency" 	=> array('element' => 'show_button', 'value' => 'yes')
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Button Icon', 'zoomarts' ),
			"param_name" 	=> "button_icon",
			"dependency" 	=> array('element' => 'show_button', 'value' => 'yes')
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Button Color', 'zoomarts' ),
			"param_name" 	=> "button_color",
		),
		array(
			"type" 			=> "textfield",
			"heading" 		=> __( 'Button Link', 'zoomarts' ),
			"param_name" 	=> "button_link",
			"dependency" 	=> array('element' => 'show_button', 'value' => 'yes')
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> __( 'Button Target', 'zoomarts' ),
			"param_name" 	=> "target",
			"value" 		=> array(
				__( 'Same window', 'zoomarts' ) 		=> "_self",
				__( 'New window', 'zoomarts' ) 		=> "_blank",	
			),
			"dependency" 	=> array('element' => 'show_button', 'value' => 'yes')
		),
		array(
			"type" 			=> "textarea_html",
			"heading" 		=> __( 'Content', 'zoomarts' ),
			"param_name" 	=> "content",
			"value" 		=> "<li>Feature List Item 1</li><li>Feature List Item 2</li><li>Feature List Item 3</li><li>Feature List Item 4</li><li>Feature List Item 5</li>",
		)
	)
) );

if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Za_Pricing_Tables extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Za_Pricing_Table extends WPBakeryShortCode {
    }
}


// Counters Shortcode
vc_map( array(
    "name" 			=> __( 'Counter', 'zoomarts' ),
    "base" 			=> 'za_counter',
    "description" 	=> __( 'Add Anmation Counter', 'zoomarts' ),
    "icon" 			=> "za_counter",
    "category" 		=> "by ZoOmArts",
    "params" 		=> array(
    	array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Counter Number', 'zoomarts' ),
			'param_name' 	=> 'number',
			'holder' 		=> 'div',
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __( 'Symbol', 'zoomarts' ),
			'param_name' 	=> 'symbol',
		),
		array(
			"type" 			=> "dropdown",
			"heading" 		=> "<hr/><br/>".__( 'Custom Font Family?', 'zoomarts' ),
			"param_name" 	=> "font_family",
			'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
			"value" 		=> $custom_fonts,
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "width_heigh",
    		"heading" 		=> __( 'Block Width/Heigh', 'zoomarts' ),
			'description' 	=> __( 'Enter counter block Width/Heigh. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "font_size",
    		"heading" 		=> __( 'Font Size', 'zoomarts' ),
			'description' 	=> __( 'Enter counter font size. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "border_width",
    		"heading" 		=> __( 'Border Width', 'zoomarts' ),
			'description' 	=> __( 'Enter counter block border width. (pixels)', 'zoomarts' ),
		),
		array(
			'type' 			=> 'textfield',
    		"param_name" 	=> "border_radius",
    		"heading" 		=> __( 'Border Radius', 'zoomarts' ),
			'description' 	=> __( 'Enter counter block border radius. (pixels)', 'zoomarts' ),
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Text Color', 'zoomarts' ),
			"param_name" 	=> "text_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Background Color', 'zoomarts' ),
			"param_name" 	=> "bg_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Border Color', 'zoomarts' ),
			"param_name" 	=> "border_color",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Color (Hover)', 'zoomarts' ),
			"param_name" 	=> "color_hover",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Background Color (Hover)', 'zoomarts' ),
			"param_name" 	=> "bg_color_hover",
		),
		array(
			"type" 			=> "colorpicker",
			"heading" 		=> __( 'Border Color (Hover)', 'zoomarts' ),
			"param_name" 	=> "border_color_hover",
		),
	),
) );


// Products Carousel and Product Block Shortcode
if ( class_exists( 'WooCommerce' ) ) {

	vc_map( array(
	    "name" 			=> __( 'Products Carousel', 'zoomarts' ),
	    "base" 			=> 'za_products_carousel',
	    "description" 	=> __( 'The Woo Products Carousel', 'zoomarts' ),
	    "icon" 			=> "za_products",
	    "category" 		=> "by ZoOmArts",
	    "params" 		=> array(
			array(
				'type'			=> 'textfield',
				'heading'		=> __( 'Products Number', 'zoomarts' ),
				'param_name' 	=> 'num',
			),
			array(
				"type"			=> "dropdown",
				"heading" 		=> "<hr/><br/>".__( 'Custom Products', 'zoomarts' ),
				"param_name" 	=> "custom_products",
				"value" 		=> array(
					'',
					__( 'Featured Products', 'zoomarts' )		=> "featured",
					__( 'Sale Products', 'zoomarts' )			=> "on-sale",
					__( 'Best Selling Products', 'zoomarts' )	=> "best-selling",
					__( 'Top Rated Products', 'zoomarts' )		=> "top-rated",
				)
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Order By', 'zoomarts' ),
				'param_name' 	=> 'orderby',
				'value' 		=> $order_by_values,
				'description' 	=> sprintf( __( 'Select how to sort retrieved products. More at %s.', 'zoomarts' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
			),
			array(
				'type' 			=> 'dropdown',
				'heading' 		=> __( 'Order Way', 'zoomarts' ),
				'param_name' 	=> 'order',
				'value' 		=> $order_way_values,
				'description' 	=> sprintf( __( 'Designates the ascending or descending order. More at %s.', 'zoomarts' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' )
			),
			array(
				"type"			=> "dropdown",
				"heading" 		=> "<hr/><br/>".__( 'Carousel Navigation?', 'zoomarts' ),
				"param_name" 	=> "nav",
				"value" 		=> array(
					__( 'False', 'zoomarts' ) 				=> "false",
					__( 'True', 'zoomarts' ) 				=> "true",
				)
			),
			array(
				"type" 			=> "dropdown",
				"heading" 		=> __( 'Navigation Style', 'zoomarts' ),
				"param_name" 	=> "nav_style",
				"value" 		=> array(
					__( 'Light', 'zoomarts' ) 				=> "nav-light",
					__( 'Dark', 'zoomarts' ) 				=> "nav-dark",
				),
				"dependency" 	=> array( 'element' => "nav", 'value' => array('true')),
			),
	    	array(
				'type' 			=> 'textfield',
				'heading' 		=> "<hr/><br/>".__( 'Carousel Margin', 'zoomarts' ),
				'param_name' 	=> 'carousel_margin',
				'description' 	=> __( 'Margin Between Items', 'zoomarts' ),
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Carousel Padding', 'zoomarts' ),
				'param_name' 	=> 'carousel_padding',
				'description' 	=> __( 'Padding left and right on stage', 'zoomarts' ),
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> "<hr/><br/>".__( 'Carousel Items For Desktop', 'zoomarts' ),
				'param_name' 	=> 'items_desktop',
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Carousel Items For Tablet', 'zoomarts' ),
				'param_name' 	=> 'items_tablet',
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Carousel Items For Mobile', 'zoomarts' ),
				'param_name' 	=> 'items_mobile',
			),
		),
	) );
	
	vc_map( array(
	    "name" 			=> __( 'Product Block', 'zoomarts' ),
	    "base" 			=> 'za_product_block',
	    "description" 	=> __( 'The Woo Product Block', 'zoomarts' ),
	    "icon" 			=> "za_products",
	    "category" 		=> "by ZoOmArts",
	    "params" 		=> array(
	    	array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Select identificator', 'zoomarts' ),
				'param_name' 	=> 'id',
				'description' 	=> __( 'Input product ID', 'zoomarts' ),
			),
			array(
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Short Description', 'zoomarts' ),
				'param_name' 	=> 'short_desc',
				'description' 	=> __( 'Enter Your short Description for this product', 'zoomarts' ),
			),
			array(
				'type' 			=> 'attach_image',
				'heading' 		=> __( 'Product Custom Image', 'zoomarts' ),
				'param_name' 	=> 'img',
				'value'			=> '',
			),
			array(
				"group" 		=> "Product Title",
				"type" 			=> "dropdown",
				"heading" 		=> __( 'Custom Font Family', 'zoomarts' ),
				"param_name" 	=> "title_font_family",
				'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
				"value" 		=> $custom_fonts,
			),
			array(
				"group" 		=> "Product Title",
				"type" 			=> "dropdown",
				"heading" 		=> __( 'Text Transform', 'zoomarts' ),
				"param_name" 	=> "title_text_transform",
				"value" 		=> array(
					'' 											=> '',
					__( 'Lowercase', 'zoomarts' ) 			=> 'lowercase',
					__( 'Capitalize', 'zoomarts' ) 			=> 'capitalize',
					__( 'Uppercase', 'zoomarts' ) 			=> 'uppercase',
				),
			),
			array(
				"group" 		=> "Product Title",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Font Size', 'zoomarts' ),
				'param_name' 	=> 'title_font_size',
				'description' 	=> __( 'Enter font size. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Product Title",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Line Height', 'zoomarts' ),
				'param_name' 	=> 'title_line_height',
				'description' 	=> __( 'Enter line height. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Product Title",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Letter Spacing', 'zoomarts' ),
				'param_name' 	=> 'title_letter_spacing',
				'description' 	=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Product Title",
				"type" 			=> "colorpicker",
				"heading" 		=> __( 'Text Color', 'zoomarts' ),
				"param_name" 	=> "title_color",
			),
			array(
				"group" 		=> "Short Description",
				"type" 			=> "dropdown",
				"heading" 		=> __( 'Custom Font Family', 'zoomarts' ),
				"param_name" 	=> "desc_font_family",
				'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
				"value" 		=> $custom_fonts,
			),
			array(
				"group" 		=> "Short Description",
				"type" 			=> "dropdown",
				"heading" 		=> __( 'Text Transform', 'zoomarts' ),
				"param_name" 	=> "desc_text_transform",
				"value" 		=> array(
					'' 											=> '',
					__( 'Lowercase', 'zoomarts' ) 			=> 'lowercase',
					__( 'Capitalize', 'zoomarts' ) 			=> 'capitalize',
					__( 'Uppercase', 'zoomarts' ) 			=> 'uppercase',
				),
			),
			array(
				"group" 		=> "Short Description",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Font Size', 'zoomarts' ),
				'param_name' 	=> 'desc_font_size',
				'description' 	=> __( 'Enter font size. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Short Description",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Line Height', 'zoomarts' ),
				'param_name' 	=> 'desc_line_height',
				'description' 	=> __( 'Enter line height. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Short Description",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Letter Spacing', 'zoomarts' ),
				'param_name' 	=> 'desc_letter_spacing',
				'description' 	=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Short Description",
				"type" 			=> "colorpicker",
				"heading" 		=> __( 'Text Color', 'zoomarts' ),
				"param_name" 	=> "desc_color",
			),
			array(
				"group" 		=> "Price Font",
				"type" 			=> "dropdown",
				"heading" 		=> __( 'Custom Font Family', 'zoomarts' ),
				"param_name" 	=> "price_font_family",
				'description' 	=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
				"value" 		=> $custom_fonts,
			),
			array(
				"group" 		=> "Price Font",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Font Size', 'zoomarts' ),
				'param_name' 	=> 'price_font_size',
				'description' 	=> __( 'Enter font size. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Price Font",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Line Height', 'zoomarts' ),
				'param_name' 	=> 'price_line_height',
				'description' 	=> __( 'Enter line height. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Price Font",
				'type' 			=> 'textfield',
				'heading' 		=> __( 'Letter Spacing', 'zoomarts' ),
				'param_name' 	=> 'price_letter_spacing',
				'description' 	=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 		=> "Price Font",
				"type" 			=> "colorpicker",
				"heading" 		=> __( 'Text Color', 'zoomarts' ),
				"param_name" 	=> "price_color",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "dropdown",
				"heading" 			=> __( 'Custom Font Family?', 'zoomarts' ),
				"param_name" 		=> "btn_font_family",
				'description' 		=> __( 'You can choose your custom fonts from Theme Option > Custom Fonts.', 'zoomarts' ),
				"value" 			=> $custom_fonts,
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "dropdown",
				"heading" 			=> __( 'Text Transform', 'zoomarts' ),
				"param_name" 		=> "btn_text_transform",
				"value" 			=> array(
					'' 											=> '',
					__( 'Lowercase', 'zoomarts' ) 			=> 'lowercase',
					__( 'Capitalize', 'zoomarts' ) 			=> 'capitalize',
					__( 'Uppercase', 'zoomarts' ) 			=> 'uppercase',
				),
			),
			array(
				"group" 			=> "Add To Cart Button",
				'type' 				=> 'textfield',
				'heading' 			=> __( 'Font Size', 'zoomarts' ),
				'param_name' 		=> 'btn_font_size',
				'description' 		=> __( 'Enter font size. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 			=> "Add To Cart Button",
				'type' 				=> 'textfield',
				'heading' 			=> __( 'Letter Spacing', 'zoomarts' ),
				'param_name' 		=> 'btn_letter_spacing',
				'description' 		=> __( 'Enter letter spacing. (pixels)', 'zoomarts' ),
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "textfield",
				"heading" 			=> "<hr/><br/>".__( 'Button Padding Top/Bottom (pixels)', 'zoomarts' ),
				"param_name" 		=> "btn_padding_vert",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "textfield",
				"heading" 			=> __( 'Button Padding Left/Right (pixels)', 'zoomarts' ),
				"param_name" 		=> "btn_padding_horz",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "textfield",
				"heading" 			=> __( 'Border Width (pixels)', 'zoomarts' ),
				"param_name" 		=> "btn_border_width",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "textfield",
				"heading" 			=> __( 'Border Radius (pixels)', 'zoomarts' ),
				"param_name" 		=> "btn_border_radius",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "colorpicker",
				"heading" 			=> "<hr/><br/>".__( 'Text Color', 'zoomarts' ),
				"param_name" 		=> "btn_text_color",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "colorpicker",
				"heading" 			=> __( 'Background Color', 'zoomarts' ),
				"param_name" 		=> "btn_bg_color",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "colorpicker",
				"heading" 			=> __( 'Border Color', 'zoomarts' ),
				"param_name" 		=> "btn_border_color",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "colorpicker",
				"heading" 			=> __( 'Text Color (hover)', 'zoomarts' ),
				"param_name" 		=> "btn_text_color_hover",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "colorpicker",
				"heading" 			=> __( 'Background Color (hover)', 'zoomarts' ),
				"param_name" 		=> "btn_bg_color_hover",
			),
			array(
				"group" 			=> "Add To Cart Button",
				"type" 				=> "colorpicker",
				"heading" 			=> __( 'Border Color (hover)', 'zoomarts' ),
				"param_name" 		=> "btn_border_color_hover",
			),
		),
	) );

}


function custom_css_classes_for_vc_row_and_vc_column($class_string, $tag) {
  if ($tag=='vc_column' || $tag=='vc_column_inner') {
    $class_string = preg_replace('/vc_span(\d{1,2})/', 'col-md-$1', $class_string);
  }
  return $class_string;
}
// Filter to Replace default css class for vc_row shortcode and vc_column
add_filter('vc_shortcodes_css_class', 'custom_css_classes_for_vc_row_and_vc_column', 10, 2);


?>