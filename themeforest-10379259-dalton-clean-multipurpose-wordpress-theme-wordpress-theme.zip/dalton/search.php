<?php

	get_header();
	za_page_header();

	global $zoomarts_options;

	$cols_class	= 'with-sidebar';
	$sidebar_position = $zoomarts_options['search-layout'];

	if ( $sidebar_position == 'fullwidth' ) {
		$cols_class = 'no-sidebar';
	}

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="main-content container <?php echo esc_attr( $sidebar_position ).' '.esc_attr( $cols_class ); ?>">
		
		<div class="page-inner clearfix">
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'left-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->
			
				<!-- Start Posts Container -->
				<div class="search-results by-sidebar">
					
					<?php

						$post_loop_count = 1;
						$page = (get_query_var('paged')) ? get_query_var('paged') : 1;

						if ($page > 1) {
							$post_loop_count = ( (int) ($page - 1) * (int) get_query_var('posts_per_page')) +1;
						}

						if (have_posts()) : while ( have_posts() ) : the_post();

					?>
					
						<!-- Start Search Item -->
						<div class="search-item post">

							<?php

								if ( get_post_type($post->ID) == 'post' ) { ?>


									<span class="result-count"><?php echo ($post_loop_count++); ?></span>
									<?php
										$format = get_post_format();
										if ( false === $format ) { $format = 'standard'; }
										get_template_part( 'includes/post-formats/content', $format );
									?>

								<?php } else if ( get_post_type($post->ID) == 'page' ) { ?>

									<span class="result-count"><?php echo ($post_loop_count++); ?></span>
									<?php get_template_part( 'includes/search', 'result' );

								} else if ( get_post_type($post->ID) == 'portfolio' ) { ?>

									<span class="result-count"><?php echo ($post_loop_count++); ?></span>
									<?php get_template_part( 'includes/search', 'result' );

								} else if ( get_post_type($post->ID) == 'product' ) { ?>

									<span class="result-count"><?php echo ($post_loop_count++); ?></span>
									<?php get_template_part( 'includes/search', 'result' );

								} else { ?>
								
									<span class="result-count"><?php echo ($post_loop_count++); ?></span>
									<?php get_template_part( 'includes/search', 'result' );

								}

							?>

						</div>
						<!-- End Post Item -->
					
					<?php endwhile; else: ?>

						<h4 class="no-results">
							<?php echo __('Sorry, No results found.', 'zoomarts'); ?><br />
							<span><?php echo __('Please try to search again...', 'zoomarts'); ?></span>
						</h4>

					<?php endif; ?>

					<?php if ( $zoomarts_options['blog-pagination-style'] == 'standard' ) : ?>
						<?php za_pagination(); ?>
					<?php else : ?>
						<div class="page-navigation clearfix">
							<div class="nav-next"><?php next_posts_link('&#8594;') ?></div>
							<div class="nav-previous"><?php previous_posts_link('&#8592;') ?></div>
						</div>
					<?php endif; ?>

				</div>
				<!-- End Posts Container -->
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'right-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->
			
		</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>