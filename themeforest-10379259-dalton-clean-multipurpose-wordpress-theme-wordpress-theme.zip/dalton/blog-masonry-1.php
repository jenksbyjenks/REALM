<?php

	/*template name: Masonry Blog 1*/

	get_header();
	za_page_header();

	global $post;
	global $zoomarts_options;

	$blog_masonry_cols = '';
	$cols_class	= 'with-sidebar';
	$container_class = 'container';
	$default_layout = $zoomarts_options['blog-layout'];
	$blog_style = 'blog-masonry';
	$custom_layout = get_post_meta( $post->ID, 'za_page_layout', true );
	$sidebar_position = $custom_layout != '' ? $custom_layout : $default_layout;

	if ( $sidebar_position == 'fullwidth' || $zoomarts_options['blog-style'] == 'blog-masonry' ) {
		$cols_class = 'no-sidebar';
	}
	
	if ( $blog_style == 'blog-masonry' ) {
		$sidebar_position 	= 'fullwidth';
		$cols_class = 'no-sidebar';
		$blog_masonry_cols 	= 'blog-cols-2';
		if ( $blog_masonry_cols == 'blog-fullwidth-cols-4' || $blog_masonry_cols == 'blog-fullwidth-cols-5' ) {
			$container_class = 'container-fluid';
		}
	}

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="main-content <?php echo esc_attr( $container_class ).' '.esc_attr( $sidebar_position ).' '.esc_attr( $cols_class ); ?>">

			<div class="page-inner clearfix">

				<!-- Start Sidebar -->
				<?php if ( $sidebar_position == 'left-sidebar' ) { get_sidebar(); } ?>
				<!-- End Sidebar -->

				<!-- Start Posts Container -->
				<div class="blog-items by-sidebar <?php echo esc_attr( $blog_style ).' '.esc_attr( $blog_masonry_cols ); ?>">
					
					<ul class="items-list isotope">
						<?php query_posts('post_type=post&post_status=publish&paged='. get_query_var('paged')); ?>  
						<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
					
							<!-- Start Post Item -->
							<li <?php post_class(); ?> id="post-<?php the_ID(); ?>">

								<?php 
									$format = get_post_format();
									if( false === $format ) { $format = 'standard'; }
								?>

								<?php get_template_part( 'includes/post-formats/content', $format ); ?>
								
							</li>
							<!-- End Post Item -->

						<?php endwhile; ?>
						<?php wp_reset_query(); ?>
						<?php endif; ?>
					</ul>

					<div class="page-navigation clearfix">
						<div class="nav-next"><?php next_posts_link('&#8594;') ?></div>
						<div class="nav-previous"><?php previous_posts_link('&#8592;') ?></div>
					</div>
					
				</div>
				<!-- End Posts Container -->
			
				<!-- Start Sidebar -->
				<?php if ( $sidebar_position == 'right-sidebar' ) { get_sidebar(); } ?>
				<!-- End Sidebar -->

			</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>