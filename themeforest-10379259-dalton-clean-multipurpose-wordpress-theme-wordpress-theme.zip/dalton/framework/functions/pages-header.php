<?php

/*-----------------------------------------------------------------------------------*/
/*  Pages Header Function
/*-----------------------------------------------------------------------------------*/
if ( !function_exists( 'za_page_header' ) ) {
    function za_page_header() {
        
        global $post;
        global $zoomarts_options;

        $output_page_header_class = null;
        $output_page_header_style = null;
        $output_page_header_data = null;
        $page_title_class = null;
        $page_title_style = null;
        $page_subtitle_style = null;
        $page_title_data = 'data-letter-spacing="3"';
        $page_subtitle_data = 'data-letter-spacing="3"';

        if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
            if ( is_shop() || is_product_category() || is_product_tag() ) {
                $post_id = get_option( 'woocommerce_shop_page_id' );
            } elseif ( is_cart() ) {
                $post_id = get_option( 'woocommerce_cart_page_id' );
            } elseif ( is_checkout() ) {
                $post_id = get_option( 'woocommerce_checkout_page_id' );
            } elseif ( is_account_page() ) {
                $post_id = get_option( 'woocommerce_myaccount_page_id' );
            } elseif ( is_product() ) {
                $post_id = $post->ID;
            } else {
                $post_id = get_option( 'woocommerce_shop_page_id' );
            }
        } elseif (is_home() || is_archive()) {
            $post_id = get_option('page_for_posts');
        } elseif ( isset($post->ID) && !is_search() && !is_category() ) {
            $post_id = $post->ID;
        }

        $default_top_padding = esc_attr( $zoomarts_options['page_header_top_padding'] );
        $default_bottom_padding = esc_attr( $zoomarts_options['page_header_bottom_padding'] );
        $default_text_alignment = esc_attr( $zoomarts_options['page_header_text_alignment'] );
        $default_bg_color = esc_attr( $zoomarts_options['page_header_bg_color'] );


        if ( isset($post->ID) && !is_search() && !is_category() ) {
            $check_page_title = esc_attr( get_post_meta( $post_id, 'za_check_page_title', true ) );
            $page_header_title = esc_attr( get_post_meta( $post_id, 'za_page_header_title', true ) );
            $page_header_subtitle = esc_attr( get_post_meta( $post_id, 'za_page_header_subtitle', true ) );
            
            $title_font_size = esc_attr( get_post_meta( $post_id, 'za_title_font_size', true ) );
            $title_line_height = esc_attr( get_post_meta( $post_id, 'za_title_line_height', true ) );
            $title_letter_spacing = esc_attr( get_post_meta( $post_id, 'za_title_letter_spacing', true ) );
            $title_text_transform = esc_attr( get_post_meta( $post_id, 'za_title_text_transform', true ) );
            $title_font_family = esc_attr( get_post_meta( $post_id, 'za_title_font_family', true ) );
            $title_font_color = esc_attr( get_post_meta( $post_id, 'za_title_font_color', true ) );

            $subtitle_font_size = esc_attr( get_post_meta( $post_id, 'za_subtitle_font_size', true ) );
            $subtitle_line_height = esc_attr( get_post_meta( $post_id, 'za_subtitle_line_height', true ) );
            $subtitle_letter_spacing = esc_attr( get_post_meta( $post_id, 'za_subtitle_letter_spacing', true ) );
            $subtitle_text_transform = esc_attr( get_post_meta( $post_id, 'za_subtitle_text_transform', true ) );
            $subtitle_font_family = esc_attr( get_post_meta( $post_id, 'za_subtitle_font_family', true ) );
            $subtitle_font_color = esc_attr( get_post_meta( $post_id, 'za_subtitle_font_color', true ) );

            $page_header_text_alignment = esc_attr( get_post_meta( $post_id, 'za_page_header_text_alignment', true ) );
            $page_header_top_padding = esc_attr( get_post_meta( $post_id, 'za_page_header_top_padding', true ) );
            $page_header_bottom_padding = esc_attr( get_post_meta( $post_id, 'za_page_header_bottom_padding', true ) );
            $page_header_background_color = esc_attr( get_post_meta( $post_id, 'za_page_header_background_color', true ) );
            $page_header_font_color = esc_attr( get_post_meta( $post_id, 'za_page_header_font_color', true ) );
            $page_header_background_image = esc_url( get_post_meta( $post_id, 'za_page_header_background_image', true ) );
            $page_haeder_parallax = esc_attr( get_post_meta( $post_id, 'za_page_haeder_parallax', true ) );
        }
        
        if ( !empty($page_header_title) ) {
            $output_page_header_title = $page_header_title;
        } else {
            $output_page_header_title = the_title( '', '', false );
        }
        
        if ( !empty($page_header_subtitle) ) {
            $output_page_header_subtitle = $page_header_subtitle;
        }

        if ( isset($post->ID) && !is_search() && !is_category() ) {

            if ( $title_font_family !== '' ) {

                $default_title_font_class = $title_font_family;

                if ( !empty($title_font_size) ) {
                    $page_title_style .= 'font-size:'.$title_font_size.'px; ';
                } 

                if ( !empty($title_line_height) ) {
                    $page_title_style .= 'line-height:'.$title_line_height.'px; ';
                } 

                if ( !empty($title_letter_spacing) ) {
                    $page_title_style .= 'letter-spacing:'.$title_letter_spacing.'px; ';
                    $page_title_data = 'data-letter-spacing='.$title_letter_spacing.' ';
                } else {
                    $page_title_style .= 'letter-spacing:0px; ';
                    $page_title_data = 'data-letter-spacing="0" ';
                }

                if ( !empty($title_text_transform) ) {
                    $page_title_style .= 'text-transform:'.$title_text_transform.'; ';
                } 

                if ( !empty($title_font_color) ) {
                    $page_title_style .= 'color:'.$title_font_color.'; ';
                }

            } else {
                $default_title_font_class = 'default-title-font';
            }

        } else {

            $default_title_font_class = 'default-title-font';

        }

        if ( isset($post->ID) && !is_search() && !is_category()  ) {

            if ( $subtitle_font_family !== '' ) {
                
                $default_subtitle_font_class = $subtitle_font_family;

                if ( !empty($subtitle_font_size) ) {
                    $page_subtitle_style .= 'font-size:'.$subtitle_font_size.'px; ';
                }

                if ( !empty($subtitle_line_height) ) {
                    $page_subtitle_style .= 'line-height:'.$subtitle_line_height.'px; ';
                }

                if ( !empty($subtitle_letter_spacing) ) {
                    $page_subtitle_style .= 'letter-spacing:'.$subtitle_letter_spacing.'px; ';
                    $page_subtitle_data = 'data-letter-spacing='.$subtitle_letter_spacing.' ';
                } else {
                    $page_subtitle_style .= 'letter-spacing:0px; ';
                    $page_subtitle_data = 'data-letter-spacing="0" ';
                }

                if ( !empty($subtitle_text_transform) ) {
                    $page_subtitle_style .= 'text-transform:'.$subtitle_text_transform.'; ';
                }

                if ( !empty($subtitle_font_color) ) {
                    $page_subtitle_style .= 'color:'.$subtitle_font_color.'; ';
                }

            } else {
                $default_subtitle_font_class = 'default-subtitle-font';
            }

        } else {

            $default_subtitle_font_class = 'default-subtitle-font';

        }

        if ( is_search() ) {
            $check_page_title = 'enabled';
            $output_page_header_title = __('Search results for', 'zoomarts').': <span>'.get_search_query().'</span>';
        }

        if ( is_404() ) {
            $check_page_title = 'disabled';
        }

        if ( is_category() ) {
            $check_page_title = 'enabled';
            $output_page_header_title = __('Category', 'zoomarts').' <span>&#8220;'.single_cat_title( '', false ).'&#8221;</span>';
        }

        
        if ( !empty($page_header_text_alignment) ) {
            $output_page_header_class .= $page_header_text_alignment;
        } else {
            $output_page_header_class .= $default_text_alignment;
        }
        
        if ( !empty($page_header_top_padding) ) {
            $output_page_header_style .= 'padding-top:'.$page_header_top_padding.'px; ';
        } else {
            $output_page_header_style .= 'padding-top:'.$default_top_padding.'px; ';
        }
        
        if ( !empty($page_header_bottom_padding) ) {
            $output_page_header_style .= 'padding-bottom:'.$page_header_bottom_padding.'px; ';
        } else {
            $output_page_header_style .= 'padding-bottom:'.$default_bottom_padding.'px; ';
        }
        
        if ( !empty($page_header_background_color) ) {
            $output_page_header_style .= 'background-color:'.$page_header_background_color.'; ';
        }
        
        if ( !empty($page_header_background_image) ) {
            $output_page_header_style .= 'background-image:url('.$page_header_background_image.'); ';
            $output_page_header_class .= ' cover-bg';
        }

        if ( empty($page_header_background_image) && empty($page_header_background_color)) {
            $output_page_header_style .= 'background-color:'.$default_bg_color.'; ';
        }
        
        if ( isset($post->ID) && !is_search() && !is_category() ) {
            if ( $page_haeder_parallax == 'parallax_bg' ) {
                $output_page_header_class .= ' parallax-bg-header';
                $output_page_header_data = 'data-stellar-background-ratio=0.4';
            } elseif ( $page_haeder_parallax == 'parallax_content' ) {
                $output_page_header_class .= ' parallax-content';
                $output_page_header_data = 'data-stellar-background-ratio=0.4';
            }
        }
        
        if ( $check_page_title == 'enabled' ) : ?>   
            <div class="page-header <?php echo esc_attr( $output_page_header_class ); ?>" <?php echo esc_attr( $output_page_header_data ); ?> style="<?php echo esc_attr( $output_page_header_style ); ?>">
                <div class="container">
                    <div class="page_header-content">
                        <h2 class="<?php echo esc_attr( $default_title_font_class ); ?>" style="<?php echo esc_attr( $page_title_style ); ?>" <?php echo esc_attr($page_title_data ); ?> >
                                <?php echo ($output_page_header_title); ?>
                        </h2>
                        <?php if ( !empty($output_page_header_subtitle) ) : ?>
                            <h5 class="<?php echo esc_attr( $default_subtitle_font_class ); ?>" style="<?php echo esc_attr( $page_subtitle_style ); ?>" <?php echo esc_attr( $page_subtitle_data ); ?>>
                                <?php echo ($output_page_header_subtitle ); ?>
                            </h5>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif;
        
    }
}