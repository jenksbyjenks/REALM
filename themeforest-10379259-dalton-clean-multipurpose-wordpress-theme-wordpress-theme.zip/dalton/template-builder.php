<?php

	/*template name: Page Builder*/
	get_header();
    za_page_header();
    za_onepage_menu();

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="main-content">
	
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<?php the_content(); ?>
		<?php endwhile; endif; ?>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>