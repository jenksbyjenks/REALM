<?php
	global $zoomarts_options;
	za_footer_widgets();
?>

<?php if ( $zoomarts_options['loader'] == '1' ) { echo '</div>'; } ?>

<?php wp_footer(); ?>

<!-- End Wrapper -->
</div>

</body>
</html>