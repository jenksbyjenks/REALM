jQuery(document).ready(function ($){  
		
	    var acs_action = 'myprefix_autocompletesearch';  
	    //$("body").on('focus','#search-box #s',function(){
	    	
		    	$('#search-box #s').autocomplete({ 
			    	delay: 50,
			    	position: { collision: "none" },
			    	appendTo: $("#header .autocomplete-results .search-results"), 
			        source: function(req, response){  
			            $.getJSON(MyAcSearch.url+'?callback=?&action='+acs_action, req, response);  
			        },  
			        select: function(event, ui) {  
			            window.location.href=ui.item.link;  
			        },  
			        minLength: 2,  
			    }).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
					return $( "<li>" )
					.append( "<a>" + item.image + "<span class='title'>" + item.label + "</span><br/><span class='meta'>" + item.post_type + "</span> </a>" )
					.appendTo( ul );
				};
				$( ".ui-autocomplete" ).addClass('clearfix')

	    //});
    
});  