<div class="author-bio clearfix">
	<div class="author-avatar"><?php echo ( get_avatar( get_the_author_meta( 'ID' ), 60 ) ); ?></div>
	<div class="about-author">
		<div class="author-name"><h5><?php the_author(); ?></h5></div>
		<p><?php echo esc_html( get_the_author_meta('description') ); ?></p>
	</div>
</div>