<?php

	/*Template Name: WooCommerce*/ 

	get_header();
	za_page_header();

	global $post;
	global $zoomarts_options;

	$cols_class	= 'with-sidebar';

	if ( is_product() ) {
		$default_layout = $zoomarts_options['product-layout'];
		$custom_layout = get_post_meta( $post->ID, 'za_page_layout', true );
		$sidebar_position = $custom_layout != '' ? $custom_layout : $default_layout;
		if ( $sidebar_position == 'fullwidth' ) { $cols_class = 'no-sidebar'; }
	} elseif ( is_woocommerce() && !is_product() ) {
		$default_layout = $zoomarts_options['shop-layout'];
		$custom_layout = get_post_meta( get_option('woocommerce_shop_page_id'), 'za_page_layout', true );
		$sidebar_position = $custom_layout != '' ? $custom_layout : $default_layout;
		if ( $sidebar_position == 'fullwidth' ) { $cols_class = 'no-sidebar'; }
	} else if ( is_product_category() ) {
		$default_layout = $zoomarts_options['shop-layout'];
		$custom_layout = get_post_meta( get_option('woocommerce_shop_page_id'), 'za_page_layout', true );
		$sidebar_position = $custom_layout != '' ? $custom_layout : $default_layout;
		if ( $sidebar_position == 'fullwidth' ) { $cols_class = 'no-sidebar'; }
	}

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="main-content container <?php echo esc_attr( $sidebar_position ); ?>">
    
		<div class="page-inner clearfix">
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'left-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->

			<!-- Start Posts Container -->
			<div class="by-sidebar <?php echo esc_attr( $cols_class ); ?>">
		
				<!-- Start Post Item -->
				<div id="post-<?php the_ID(); ?>">
							
					<!--BEGIN .entry-content -->
					<div class="page-content columns-<?php echo esc_attr( $zoomarts_options['shop-columns'] ); ?>">
						<?php
							if ( is_product_category() )
								do_action( 'woocommerce_show_category_banner' );
							woocommerce_content();
						?>
					</div>
					<!--END .entry-content -->

				</div>
				<!-- End Post Item -->

			</div>
			<!-- End Posts Container -->
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'right-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->
			
		</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>