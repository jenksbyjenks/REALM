<?php

	get_header();
	za_page_header();

	global $post;
	global $zoomarts_options;

	$cols_class	= 'with-sidebar';
	$default_layout = $zoomarts_options['page-layout'];
	$custom_layout = get_post_meta( $post->ID, 'za_page_layout', true );
	$sidebar_position = $custom_layout != '' ? $custom_layout : $default_layout;

	if ( $sidebar_position == 'fullwidth' ) {
		$cols_class = 'no-sidebar';
	}

?>
    
    <!-- Start Main Container -->
    <div id="main-content" class="main-content container <?php echo esc_attr( $sidebar_position ).' '.esc_attr( $cols_class ); ?>">
    
		<div class="page-inner clearfix">
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'left-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->

			<!-- Start Page Content -->
			<div class="spot-wrap by-sidebar">
					
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					
					<!-- Start Post Item -->
					<div id="post-<?php the_ID(); ?>">
							
						<div class="page-content">

							<?php the_content(); ?>

							<?php wp_link_pages(array('before' => '<p><strong>'.__('Pages:', 'zoomarts').'</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>

							<?php //if ( comments_open() || get_comments_number() ) { comments_template('', true); } ?>

						</div>

					</div>
					<!-- End Post Item -->
					
				<?php endwhile; endif; ?>

			</div>
			<!-- End Posts Container -->
			
			<!-- Start Sidebar -->
			<?php if ( $sidebar_position == 'right-sidebar' ) { get_sidebar(); } ?>
			<!-- End Sidebar -->
			
		</div>

    </div>
	<!-- End Main Container -->

<?php get_footer(); ?>